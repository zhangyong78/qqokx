from __future__ import annotations

from dataclasses import dataclass, replace

STRATEGY_DYNAMIC_ID = "ema_dynamic_order"
STRATEGY_DYNAMIC_LONG_ID = "ema_dynamic_order_long"
STRATEGY_DYNAMIC_SHORT_ID = "ema_dynamic_order_short"
STRATEGY_DYNAMIC_MTF_LONG_ID = "ema_dynamic_mtf_long"
STRATEGY_DYNAMIC_MTF_SHORT_ID = "ema_dynamic_mtf_short"
# 仅兼容旧持久化 / 旧脚本，不在策略列表中展示
STRATEGY_CROSS_ID = "ema_cross_market"
STRATEGY_EMA_BREAKOUT_LONG_ID = "ema_breakout_long"
STRATEGY_EMA_BREAKDOWN_SHORT_ID = "ema_breakdown_short"
STRATEGY_EMA5_EMA8_ID = "ema5_ema8_cross_stop"
STRATEGY_ADAPTIVE_EMA_RAIL_LONG_ID = "adaptive_ema_rail_long"
STRATEGY_EMA55_SLOPE_SHORT_ID = "ema55_slope_short"
STRATEGY_BTC_EMA55_SLOPE_SHORT_ID = "btc_ema55_slope_short"
STRATEGY_BODY_RETEST_SHORT_ID = "body_retest_short"
STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID = "btc_ema15_ma50_pullback_long"
STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID = "btc_ema15_ma50_pullback_short"
STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID = "btc_daily_4h_long_short"


def is_ema_atr_breakout_strategy(strategy_id: str) -> bool:
    """EMA 突破/跌破类：参考 EMA 突破或跌破 + 小/中周期 EMA 过滤，共用 EmaAtrStrategy 与回测引擎。"""
    return strategy_id in {
        STRATEGY_EMA_BREAKOUT_LONG_ID,
        STRATEGY_EMA_BREAKDOWN_SHORT_ID,
        STRATEGY_CROSS_ID,
    }


def is_adaptive_ema_rail_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_ADAPTIVE_EMA_RAIL_LONG_ID


def is_ema55_slope_short_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_EMA55_SLOPE_SHORT_ID


def is_btc_ema55_slope_short_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_BTC_EMA55_SLOPE_SHORT_ID


def is_body_retest_short_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_BODY_RETEST_SHORT_ID


def is_btc_ema15_ma50_pullback_long_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID


def is_btc_ema15_ma50_pullback_short_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID


def is_btc_daily_4h_long_short_strategy(strategy_id: str) -> bool:
    return strategy_id == STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID


def is_dynamic_mtf_strategy_id(strategy_id: str) -> bool:
    return strategy_id in {
        STRATEGY_DYNAMIC_MTF_LONG_ID,
        STRATEGY_DYNAMIC_MTF_SHORT_ID,
    }


def supports_startup_chase_current_signal(strategy_id: str) -> bool:
    return strategy_id in {
        STRATEGY_DYNAMIC_LONG_ID,
        STRATEGY_DYNAMIC_SHORT_ID,
        STRATEGY_EMA_BREAKOUT_LONG_ID,
        STRATEGY_EMA_BREAKDOWN_SHORT_ID,
        STRATEGY_EMA55_SLOPE_SHORT_ID,
    }


@dataclass(frozen=True)
class StrategyDefinition:
    strategy_id: str
    name: str
    summary: str
    rule_description: str
    parameter_hint: str
    default_signal_label: str
    allowed_signal_labels: tuple[str, ...]
    supports_trade: bool = True
    supports_signal_only: bool = False
    supports_backtest: bool = True
    supports_batch_observe: bool = False
    supports_trader_desk: bool = False

    @property
    def default_signal_mode(self) -> str:
        """Backward-compatible signal mode value for older launcher/import paths."""
        if self.default_signal_label == "只做多":
            return "long_only"
        if self.default_signal_label == "只做空":
            return "short_only"
        return "both"


ALL_STRATEGY_DEFINITIONS: tuple[StrategyDefinition, ...] = (
    StrategyDefinition(
        strategy_id=STRATEGY_DYNAMIC_LONG_ID,
        name="EMA 动态委托做多",
        summary="顺着 EMA 趋势方向挂单做多，适合趋势延续型短中线实验。",
        rule_description=(
            "流程：先确认 EMA 小周期在趋势 EMA 上方，且已收盘 K 线收盘价仍站在趋势 EMA 上方；"
            "条件成立后，不直接追价，而是按上一根已收盘 K 线的挂单参考 EMA 挂多头限价单。"
            "若本根 K 线未成交，则下一根 K 线确认后撤掉旧单，再按最新参考 EMA 重挂；"
            "成交后转入止盈止损监控，本轮持仓结束后继续等待下一次多头信号。"
        ),
        parameter_hint=(
            "可调参数主要是 EMA 周期、ATR 止盈止损倍数、挂单参考 EMA、"
            "动态止盈与时间保本。"
        ),
        default_signal_label="只做多",
        allowed_signal_labels=("只做多",),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_DYNAMIC_SHORT_ID,
        name="EMA 动态委托做空",
        summary="顺着 EMA 趋势方向挂单做空，适合趋势延续型短中线实验。",
        rule_description=(
            "流程：先确认 EMA 小周期在趋势 EMA 下方，且已收盘 K 线收盘价仍压在趋势 EMA 下方；"
            "条件成立后，不直接追空，而是按上一根已收盘 K 线的挂单参考 EMA 挂空头限价单。"
            "若本根 K 线未成交，则下一根 K 线确认后撤掉旧单，再按最新参考 EMA 重挂；"
            "成交后转入止盈止损监控，本轮持仓结束后继续等待下一次空头信号。"
        ),
        parameter_hint=(
            "可调参数主要是 EMA 周期、ATR 止盈止损倍数、挂单参考 EMA、"
            "动态止盈与时间保本。"
        ),
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_DYNAMIC_MTF_LONG_ID,
        name="EMA 动态委托-多周期多头",
        summary="高周期 EMA 趋势只负责过滤方向，低周期继续按 EMA 动态委托做多。",
        rule_description=(
            "流程：先用高周期 EMA 快慢线确认大方向，只有高周期快线在慢线上方时，"
            "才允许低周期按 EMA 动态委托做多。低周期一旦满足多头趋势条件，"
            "就按挂单参考 EMA 挂多头限价单；若未成交，下一根 K 线确认后撤旧挂新。"
            "成交后的止盈止损、动态上移、每波最多开仓次数与继续等待下一次信号的逻辑，"
            "沿用 EMA 动态委托做多。"
        ),
        parameter_hint="关注低周期入场 EMA、ATR 风控、高周期快慢 EMA 与高周期反转处理。",
        default_signal_label="只做多",
        allowed_signal_labels=("只做多",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_DYNAMIC_MTF_SHORT_ID,
        name="EMA 动态委托-多周期空头",
        summary="高周期 EMA 趋势只负责过滤方向，低周期继续按 EMA 动态委托做空。",
        rule_description=(
            "流程：先用高周期 EMA 快慢线确认大方向，只有高周期快线在慢线下方时，"
            "才允许低周期按 EMA 动态委托做空。低周期一旦满足空头趋势条件，"
            "就按挂单参考 EMA 挂空头限价单；若未成交，下一根 K 线确认后撤旧挂新。"
            "成交后的止盈止损、动态上移、每波最多开仓次数与继续等待下一次信号的逻辑，"
            "沿用 EMA 动态委托做空。"
        ),
        parameter_hint="关注低周期入场 EMA、ATR 风控、高周期快慢 EMA 与高周期反转处理。",
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_EMA_BREAKOUT_LONG_ID,
        name="EMA 突破做多策略",
        summary="收盘价向上突破参考 EMA 时做多，且仅当 EMA(小周期) 在 EMA(中周期) 上方；ATR 止盈止损。",
        rule_description=(
            "流程：先等待最近一根已收盘 K 线收盘价向上突破参考 EMA，且 EMA 小周期仍在 EMA 中周期上方；"
            "条件成立后立即按市价开多，不走回调挂单。开仓后若为固定止盈模式，则止盈止损一并交给 OKX；"
            "若为动态止盈模式，则先只挂初始止损，后续按 2R/3R 等规则上移止损。"
            "本轮仓位结束后，本次策略线程收口，不是继续在当前会话里等待下一次信号。"
        ),
        parameter_hint="关注小/中周期 EMA、突破参考 EMA 周期、ATR 与止盈止损倍数。",
        default_signal_label="只做多",
        allowed_signal_labels=("只做多",),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_EMA_BREAKDOWN_SHORT_ID,
        name="EMA 跌破做空策略",
        summary="收盘价向下跌破参考 EMA 时做空，且仅当 EMA(小周期) 在 EMA(中周期) 下方；ATR 止盈止损。",
        rule_description=(
            "流程：先等待最近一根已收盘 K 线收盘价向下跌破参考 EMA，且 EMA 小周期仍在 EMA 中周期下方；"
            "条件成立后立即按市价开空，不走反弹挂单。开仓后若为固定止盈模式，则止盈止损一并交给 OKX；"
            "若为动态止盈模式，则先只挂初始止损，后续按 2R/3R 等规则下移止损。"
            "本轮仓位结束后，本次策略线程收口，不是继续在当前会话里等待下一次信号。"
        ),
        parameter_hint="关注小/中周期 EMA、突破参考 EMA 周期、ATR 与止盈止损倍数。",
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_CROSS_ID,
        name="EMA 突破/跌破（旧版）",
        summary="兼容旧配置；请改用「EMA 突破做多策略」或「EMA 跌破做空策略」。",
        rule_description=(
            "流程与新版突破做多 / 跌破做空一致：等待已收盘 K 线突破或跌破参考 EMA，"
            "并通过 EMA 小周期与中周期的方向过滤后，立即按市价进场；"
            "固定止盈模式会一次性挂好止盈止损，动态止盈模式则先挂初始止损再动态上移。"
            "本入口仅保留给旧持久化与旧脚本兼容使用。"
        ),
        parameter_hint="请迁移到新策略入口；本入口仅用于读取旧持久化。",
        default_signal_label="只做多",
        allowed_signal_labels=("只做多", "只做空"),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_EMA5_EMA8_ID,
        name="EMA5/8 穿越止损",
        summary="固定 4H 节奏的 EMA5/EMA8 穿越策略，带大周期过滤。",
        rule_description=(
            "流程：固定使用 4H 节奏，先看 EMA55/EMA233 的大趋势过滤方向，"
            "再用 EMA5 与 EMA8 的穿越生成入场信号。信号成立后按策略定义进场，"
            "离场不走固定止盈，而是交给动态止损规则持续跟踪，直到保护价被触发或仓位结束。"
            "本轮结束后再回到等待下一次 EMA5/8 穿越信号。"
        ),
        parameter_hint="该策略固定 4H 周期，适合做更稳一点的节奏型趋势实验。",
        default_signal_label="双向",
        allowed_signal_labels=("双向", "只做多", "只做空"),
        supports_signal_only=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_ADAPTIVE_EMA_RAIL_LONG_ID,
        name="Adaptive EMA Rail 做多",
        summary="自动寻找当前被市场尊重的支撑型 EMA，并在轨道确认后按回踩委托做多。",
        rule_description=(
            "流程：先用 EMA200 斜率与高低点结构判断大趋势，再对候选 EMA 逐条计算 Respect Score，"
            "选出当前最被市场尊重的主导轨道。只有当主导轨道完成至少两次有效反弹后，"
            "才允许按该主导 EMA 挂多头回踩委托。后续重点观察轨道是否继续有效、回踩是否成交，"
            "以及轨道失效后是否需要切换到新的主导 EMA。"
        ),
        parameter_hint="V1 固定候选 EMA 集合与 Respect Score 默认阈值，重点验证轨道识别和回测表现。",
        default_signal_label="只做多",
        allowed_signal_labels=("只做多",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_EMA55_SLOPE_SHORT_ID,
        name="均线斜率做空",
        summary="均线斜率达到负阈值时做空，搭配 2ATR 止损、nR 保本后逐级锁盈与 ATR 分位过滤。",
        rule_description=(
            "流程：按策略参数指定的 EMA 或 MA 周期计算斜率；当最新一根已收盘 K 线的均线斜率比例小于等于开空阈值时，"
            "若当前空仓则按该根 K 线收盘价开空。默认使用 2ATR 初始止损、动态逐级锁盈、nR 保本，"
            "并通过 ATR 分位过滤较高波动环境。斜率转正平仓作为可选防守条件，默认关闭。"
        ),
        parameter_hint="实盘默认：1H、均线斜率阈值 -0.0005、2ATR 止损、动态止盈、nR 保本、ATR 分位≤50%、每笔风险10U；不同币种可使用不同 EMA/MA 周期。",
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_BTC_EMA55_SLOPE_SHORT_ID,
        name="BTC EMA55 斜率做空",
        summary="BTC 专用 EMA55 斜率做空：负斜率直接开空，ATR14 以损定量，出场可选 nR 保本与斜率走平。",
        rule_description=(
            "当最新已收盘 K 线的 EMA55 单根斜率比例小于等于阈值时直接开空；"
            "仓位按 ATR14 风险定量，初始止损按 ATR 倍数设置。"
            "持仓后始终使用 ATR 止损；若开启 nR 保本，则达到首档 R 后按 n-1R 逐级上移止损，并叠加双向手续费；"
            "若开启斜率转正平仓，则 EMA55 斜率走平或转正时平仓。"
        ),
        parameter_hint="默认 1H、EMA55、ATR14、止损 1.5ATR、斜率阈值 -0.0005；止损倍数、斜率阈值和 nR 保本触发档位可调。",
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
        supports_batch_observe=True,
        supports_trader_desk=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_BODY_RETEST_SHORT_ID,
        name="Body/ATR 回抽做空",
        summary="先等阴线破位，再在限定K线内等回抽确认做空；默认配合日线弱日过滤。",
        rule_description=(
            "流程：先确认参考均线斜率转弱、ATR 分位不过热，并出现一根实体不过大的阴线向下破位；"
            "破位后不立即追空，而是在限定 K 线内等待价格回抽到均线附近、收盘仍压在均线下方且再次收阴时做空。"
            "入场后沿用 ATR 风控、2R 保本和逐级锁盈。"
        ),
        parameter_hint=(
            "核心参数：参考均线类型/周期、破位 ATR、回抽 ATR、止损缓冲 ATR、body/ATR 上限、等待K线数、"
            "ATR 分位上限、斜率阈值，以及是否启用 Weak Day 日线过滤。"
        ),
        default_signal_label="鍙仛绌?",
        allowed_signal_labels=("鍙仛绌?",),
        supports_trade=True,
        supports_signal_only=True,
        supports_backtest=True,
        supports_batch_observe=True,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID,
        name="BTC 快线/趋势均线 回踩做多",
        summary="BTC 4H 专用研究策略：快线从下向上穿越趋势均线后，等待限定窗口内首次或前几次回踩快线的收盘确认，下一根开盘做多；默认快线为 EMA15、趋势线为 MA50，均可实验调整。",
        rule_description=(
            "流程：固定 BTC-USDT-SWAP 4H；先要求快线从下向上穿越趋势均线，随后进入限定观察窗口。"
            "若窗口内出现 low 触及快线且 close 重新收回快线上方，则在该根 K 线收盘确认，下一根 K 线开盘做多。"
            "持仓后可选择固定 RR、nR 动态保护，以及快线收盘跌破后的下一根开盘离场。"
        ),
        parameter_hint=(
            "核心研究参数：快线类型/周期、趋势均线类型/周期、ATR 周期、ATR 止损倍数、Cross 后观察窗口、允许交易的第几次回踩、"
            "固定 RR、动态保护触发 R、日线过滤，以及是否叠加快线收破离场。"
        ),
        default_signal_label="只做多",
        allowed_signal_labels=("只做多",),
        supports_trade=False,
        supports_signal_only=False,
        supports_backtest=True,
        supports_batch_observe=False,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID,
        name="BTC 快线/趋势均线 回踩做空",
        summary="BTC 4H 专用研究策略：快线从上向下穿越趋势均线后，等待限定窗口内首次或前几次回抽快线的收盘确认，下一根开盘做空；默认快线为 EMA15、趋势线为 EMA55，均可实验调整。",
        rule_description=(
            "流程：固定 BTC-USDT-SWAP 4H；先要求快线从上向下穿越趋势均线，随后进入限定观察窗口。"
            "若窗口内出现 high 触及快线且 close 重新收回快线下方，则在该根 K 线收盘确认，下一根 K 线开盘做空。"
            "持仓后可选择固定 RR、nR 动态保护，以及快线收盘重新站回上方后的下一根开盘离场。"
        ),
        parameter_hint=(
            "核心研究参数：快线类型/周期、趋势均线类型/周期、ATR 周期、ATR 止损倍数、Cross 后观察窗口、允许交易的第几次回抽、"
            "固定 RR、动态保护触发 R、日线过滤，以及是否叠加快线收回离场。"
        ),
        default_signal_label="只做空",
        allowed_signal_labels=("只做空",),
        supports_trade=False,
        supports_signal_only=False,
        supports_backtest=True,
        supports_batch_observe=False,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID,
        name="BTC日线+4小时多空策略",
        summary="BTC 4H 双向回踩研究策略：4H 用 EMA15/MA50 找穿越回踩，方向固定跟随日线 close vs MA50。",
        rule_description=(
            "流程：固定 BTC-USDT-SWAP 4H；4H 先识别 EMA15 与 MA50 的方向穿越，再等回踩/反抽 EMA15 的收盘确认，下一根 K 线开盘成交；"
            "日线方向固定使用 close vs MA50，多头日只做多，空头日只做空；持仓后可按动态保护或 EMA15 收盘反向在下一根开盘离场。"
        ),
        parameter_hint=(
            "本版固定 4H EMA15/MA50 + 日线 MA50 过滤，只保留 ATR 止损、Cross 观察窗口、最大回踩序号与动态止盈参数，便于直接回测。"
        ),
        default_signal_label="双向",
        allowed_signal_labels=("双向", "只做多", "只做空"),
        supports_trade=False,
        supports_signal_only=False,
        supports_backtest=True,
        supports_batch_observe=False,
    ),
    StrategyDefinition(
        strategy_id=STRATEGY_DYNAMIC_ID,
        name="EMA 动态委托",
        summary="通用 EMA 动态委托策略入口，通常由做多/做空两个方向版本承接。",
        rule_description=(
            "通用流程与 EMA 动态委托做多 / 做空相同：先判断趋势方向是否成立，"
            "再按挂单参考 EMA 挂限价单，未成交则每根新 K 线撤旧挂新，"
            "成交后进入止盈止损监控，本轮持仓结束后继续等待下一次信号。"
            "该入口主要保留给内部通用逻辑与兼容场景使用。"
        ),
        parameter_hint="如果只是日常使用，优先直接选做多或做空版本。",
        default_signal_label="双向",
        allowed_signal_labels=("双向", "只做多", "只做空"),
        supports_signal_only=True,
        supports_backtest=False,
    ),
)


def _normalize_strategy_definition(item: StrategyDefinition) -> StrategyDefinition:
    if item.strategy_id == STRATEGY_BODY_RETEST_SHORT_ID:
        if item.default_signal_label != "只做空" or item.allowed_signal_labels != ("只做空",):
            return replace(
                item,
                default_signal_label="只做空",
                allowed_signal_labels=("只做空",),
            )
    return item


ALL_STRATEGY_DEFINITIONS = tuple(_normalize_strategy_definition(item) for item in ALL_STRATEGY_DEFINITIONS)

_STRATEGY_IDS_HIDDEN_FROM_LAUNCHER: frozenset[str] = frozenset(
    {
        STRATEGY_DYNAMIC_ID,
        STRATEGY_CROSS_ID,
        STRATEGY_ADAPTIVE_EMA_RAIL_LONG_ID,
        STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID,
        STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID,
        STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID,
    }
)
_STRATEGY_IDS_HIDDEN_FROM_BACKTEST: frozenset[str] = frozenset({STRATEGY_DYNAMIC_ID, STRATEGY_CROSS_ID})

VISIBLE_STRATEGY_DEFINITIONS: tuple[StrategyDefinition, ...] = tuple(
    item for item in ALL_STRATEGY_DEFINITIONS if item.strategy_id not in _STRATEGY_IDS_HIDDEN_FROM_LAUNCHER
)

BACKTEST_STRATEGY_DEFINITIONS: tuple[StrategyDefinition, ...] = tuple(
    item
    for item in ALL_STRATEGY_DEFINITIONS
    if item.supports_backtest and item.strategy_id not in _STRATEGY_IDS_HIDDEN_FROM_BACKTEST
)

STRATEGY_DEFINITIONS: tuple[StrategyDefinition, ...] = VISIBLE_STRATEGY_DEFINITIONS


def get_strategy_definition(strategy_id: str) -> StrategyDefinition:
    for item in ALL_STRATEGY_DEFINITIONS:
        if item.strategy_id == strategy_id:
            return item
    raise KeyError(f"未知策略：{strategy_id}")


def is_dynamic_strategy_id(strategy_id: str) -> bool:
    return strategy_id in {
        STRATEGY_DYNAMIC_ID,
        STRATEGY_DYNAMIC_LONG_ID,
        STRATEGY_DYNAMIC_SHORT_ID,
    }


def supports_signal_only(strategy_id: str) -> bool:
    return get_strategy_definition(strategy_id).supports_signal_only


def supports_trader_desk(strategy_id: str) -> bool:
    return get_strategy_definition(strategy_id).supports_trader_desk


def signal_observer_strategy_definitions() -> tuple[StrategyDefinition, ...]:
    return tuple(item for item in STRATEGY_DEFINITIONS if item.supports_signal_only and item.supports_batch_observe)


def trader_desk_strategy_definitions() -> tuple[StrategyDefinition, ...]:
    return tuple(item for item in STRATEGY_DEFINITIONS if item.supports_trader_desk)


def resolve_dynamic_signal_mode(strategy_id: str, signal_mode: str) -> str:
    if strategy_id == STRATEGY_DYNAMIC_LONG_ID:
        return "long_only"
    if strategy_id == STRATEGY_DYNAMIC_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_DYNAMIC_MTF_LONG_ID:
        return "long_only"
    if strategy_id == STRATEGY_DYNAMIC_MTF_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_EMA_BREAKOUT_LONG_ID:
        return "long_only"
    if strategy_id == STRATEGY_EMA_BREAKDOWN_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_ADAPTIVE_EMA_RAIL_LONG_ID:
        return "long_only"
    if strategy_id == STRATEGY_EMA55_SLOPE_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_BTC_EMA55_SLOPE_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_BODY_RETEST_SHORT_ID:
        return "short_only"
    if strategy_id == STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID:
        return "long_only"
    if strategy_id == STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID:
        return "short_only"
    return signal_mode
