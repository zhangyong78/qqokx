from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass, replace
from datetime import datetime
from decimal import Decimal
from typing import Callable, Literal, TypeVar

from okx_quant.daily_filters import (
    aggregate_candles_to_daily_boundary,
    build_daily_close_vs_ma_bias,
    build_daily_weak_day_flags,
)
from okx_quant.indicators import atr, ema, moving_average
from okx_quant.market_data_hub import MarketDataHub
from okx_quant.models import (
    Credentials,
    DynamicProtectionRule,
    Instrument,
    OrderPlan,
    ProtectionPlan,
    SignalDecision,
    StrategyConfig,
    build_legacy_dynamic_protection_rules,
    describe_dynamic_protection_rules,
    normalize_dynamic_protection_rules,
)
from okx_quant.notifications import EmailNotifier
from okx_quant.okx_client import (
    OkxApiError,
    OkxOrderResult,
    OkxOrderStatus,
    OkxPosition,
    OkxPositionHistoryItem,
    OkxRestClient,
    OkxTradeOrderItem,
    infer_inst_type,
)
from okx_quant.pricing import format_decimal, format_decimal_fixed, snap_to_increment
from okx_quant.protection_validation import InvalidProtectionPlanError, validate_protection_prices
from okx_quant.stop_execution import assess_stop_execution, format_stop_execution_summary
from okx_quant.engine_order_service import EngineOrderService
from okx_quant.engine_retry_policy import EngineRetryPolicy
from okx_quant.engine_session_runner import EngineSessionRunner
from okx_quant.engine_strategy_router import EngineStrategyRouter
from okx_quant.strategies.ema_atr import EmaAtrStrategy
from okx_quant.strategies.ema_cross_ema_stop import EmaCrossEmaStopStrategy
from okx_quant.strategies.ema_dynamic import EmaDynamicOrderStrategy
from okx_quant.strategies.ema_dynamic_multi_timeframe import EmaDynamicMultiTimeframeStrategy
from okx_quant.strategies.ema55_slope_short import (
    ema55_slope_short_exit_ready,
    evaluate_ema55_slope_short_signal,
)
from okx_quant.strategies.body_retest_short import (
    body_retest_short_minimum_candles,
    build_body_retest_short_protection_plan,
    evaluate_body_retest_short_signal,
)
from okx_quant.strategy_catalog import (
    STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID,
    STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID,
    STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID,
    STRATEGY_BODY_RETEST_SHORT_ID,
    STRATEGY_DYNAMIC_ID,
    STRATEGY_DYNAMIC_LONG_ID,
    STRATEGY_DYNAMIC_SHORT_ID,
    is_btc_ema55_slope_short_strategy,
    resolve_dynamic_signal_mode,
)
from okx_quant.strategy_runtime_registry import (
    get_strategy_runtime_profile,
    strategy_uses_mtf_filter,
    strategy_uses_signal_extrema,
)
from okx_quant.strategy_parameters import strategy_uses_parameter
from okx_quant.strategy_ui_schema import strategy_forces_follow_signal, strategy_supports_dynamic_take_profit


Logger = Callable[[str], None]
OKX_SINGLE_REQUEST_MAX_CANDLES = 300
_HOUR_MS = 3_600_000
EXCHANGE_DYNAMIC_STOP_MAX_CACHED_TICKER_AGE_SECONDS = 3.0


def _live_dynamic_take_profit_enabled(config: StrategyConfig) -> bool:
    """与回测一致：EMA 动态委托与 EMA 突破/跌破在 take_profit_mode=dynamic 时启用动态止盈逻辑。"""
    if str(config.take_profit_mode or "") != "dynamic":
        return False
    return strategy_supports_dynamic_take_profit(config.strategy_id)


def _live_ema55_slope_lock_profit_enabled(config: StrategyConfig) -> bool:
    if is_btc_ema55_slope_short_strategy(config.strategy_id):
        return bool(config.ema55_slope_lock_profit_enabled)
    return _live_dynamic_take_profit_enabled(config)


def _live_ema55_slope_dynamic_two_r_break_even_enabled(config: StrategyConfig) -> bool:
    if is_btc_ema55_slope_short_strategy(config.strategy_id):
        return bool(config.ema55_slope_lock_profit_enabled)
    return bool(config.dynamic_two_r_break_even)


def _live_ema55_slope_dynamic_fee_offset_enabled(config: StrategyConfig) -> bool:
    if is_btc_ema55_slope_short_strategy(config.strategy_id):
        return bool(config.ema55_slope_lock_profit_enabled)
    return bool(config.dynamic_fee_offset_enabled)


def _live_ema55_slope_lock_profit_trigger_r(config: StrategyConfig) -> int:
    return config.resolved_dynamic_trailing_start_r()


def _live_dynamic_break_even_trigger_r(config: StrategyConfig) -> int:
    if is_btc_ema55_slope_short_strategy(config.strategy_id):
        return _live_ema55_slope_lock_profit_trigger_r(config)
    return config.resolved_dynamic_break_even_trigger_r()


def _live_dynamic_separate_break_even_enabled(config: StrategyConfig) -> bool:
    return not is_btc_ema55_slope_short_strategy(config.strategy_id)


def _live_dynamic_trailing_step_r(config: StrategyConfig) -> int:
    return config.resolved_dynamic_trailing_step_r()


def _live_dynamic_first_lock_r(config: StrategyConfig) -> int:
    return config.resolved_dynamic_first_lock_r()


def _live_dynamic_protection_rules(config: StrategyConfig) -> tuple[DynamicProtectionRule, ...]:
    return config.resolved_dynamic_protection_rules()


def _live_trend_ema_close_exit_after_trigger_r_enabled(config: StrategyConfig) -> bool:
    return bool(config.trend_ema_close_exit_after_trigger_r_enabled)


def _live_trend_ema_close_exit_trigger_r(config: StrategyConfig) -> int:
    return config.resolved_trend_ema_close_exit_after_trigger_r()


def _live_dynamic_trigger_r_reached(
    *,
    direction: Literal["long", "short"],
    current_price: Decimal,
    entry_price: Decimal,
    risk_per_unit: Decimal,
    next_trigger_r: int,
    trigger_r: int,
    tick_size: Decimal,
    dynamic_fee_offset_enabled: bool,
) -> bool:
    resolved_trigger_r = max(int(trigger_r), 1)
    if next_trigger_r <= 0 or next_trigger_r > resolved_trigger_r:
        return True
    trigger_price = _dynamic_trigger_price_live(
        direction=direction,
        entry_price=entry_price,
        risk_per_unit=risk_per_unit,
        trigger_r=resolved_trigger_r,
        tick_size=tick_size,
        dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
    )
    if direction == "long":
        return current_price >= trigger_price
    return current_price <= trigger_price


def _live_dynamic_break_even_uses_trigger_r(config: StrategyConfig) -> bool:
    return _live_dynamic_take_profit_enabled(config) and strategy_uses_parameter(
        config.strategy_id,
        "ema55_slope_lock_profit_trigger_r",
    )


def _live_dynamic_break_even_summary(config: StrategyConfig) -> str:
    rules = _live_dynamic_protection_rules(config)
    if rules:
        parts = list(
            describe_dynamic_protection_rules(
                rules,
                fee_offset_enabled=bool(config.dynamic_fee_offset_enabled),
            )
        )
        if _live_dynamic_break_even_uses_trigger_r(config):
            parts.insert(0, f"首档触发R={_live_ema55_slope_lock_profit_trigger_r(config)}")
            parts.insert(1, f"nR保本={config.dynamic_two_r_break_even_label()}")
        parts.append(f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根")
        return " | ".join(parts)
    if _live_dynamic_break_even_uses_trigger_r(config):
        return (
            f"保本触发R={_live_dynamic_break_even_trigger_r(config)} | "
            f"移动止盈触发R={_live_ema55_slope_lock_profit_trigger_r(config)} | "
            f"首档触发R={_live_ema55_slope_lock_profit_trigger_r(config)} | "
            f"首档锁盈R={_live_dynamic_first_lock_r(config) or '自动'} | "
            f"移动步长R={_live_dynamic_trailing_step_r(config)} | "
            f"保本={config.dynamic_two_r_break_even_label()} | "
            f"nR保本={config.dynamic_two_r_break_even_label()}"
        )
    return f"保本触发R={_live_dynamic_break_even_trigger_r(config)} | 保本={config.dynamic_two_r_break_even_label()}"


def _live_ema55_slope_negative_entry_bars(config: StrategyConfig) -> int:
    if is_btc_ema55_slope_short_strategy(config.strategy_id):
        return max(int(config.ema55_slope_negative_entry_bars), 1)
    return 1


def live_exchange_dynamic_take_profit_template_enabled(config: StrategyConfig) -> bool:
    """主界面模板是否属于「交易所托管 + 动态止盈上移」口径（供持仓接管等入口复用）。"""
    return _live_dynamic_take_profit_enabled(config) and not bool(config.trader_virtual_stop_loss)


def _take_profit_mode_description_for_signal_email(config: StrategyConfig) -> str:
    """仅发信号邮件中附带的止盈方式说明（与当前模板配置一致）。"""
    if get_strategy_runtime_profile(config.strategy_id).family == "ema5_ema8":
        return (
            "止盈止损说明：本策略以快慢线交叉为信号、慢线 EMA 为止损参考；"
            "与 ATR 固定/动态止盈倍数无关。"
        )
    if _live_dynamic_take_profit_enabled(config):
        dynamic_two_r_break_even = _live_ema55_slope_dynamic_two_r_break_even_enabled(config)
        dynamic_fee_offset_enabled = _live_ema55_slope_dynamic_fee_offset_enabled(config)
        return (
            "止盈方式：动态止盈（若在「交易」模式下按当前模板下单，将按此规则管理出场）| "
            f"{_live_dynamic_break_even_summary(config).replace(config.dynamic_two_r_break_even_label(), '开启' if dynamic_two_r_break_even else '关闭')} | "
            f"手续费偏移={'开启' if dynamic_fee_offset_enabled else '关闭'} | "
            f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
        )
    return (
        "止盈方式：固定止盈 | "
        f"ATR 止盈倍数×{format_decimal(config.atr_take_multiplier)} | "
        f"ATR 止损倍数×{format_decimal(config.atr_stop_multiplier)}"
    )
DEFAULT_DEBUG_ATR_PERIOD = 10
LIVE_DYNAMIC_MAKER_FEE_RATE = Decimal("0.00015")
LIVE_DYNAMIC_TAKER_FEE_RATE = Decimal("0.00036")
_RUNTIME_HEARTBEAT_PREFIX = "__qqokx_runtime_heartbeat__|"


def _qqokx_env_int(name: str, default: int, *, min_value: int, max_value: int) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        parsed = int(raw, 10)
    except ValueError:
        return default
    return max(min_value, min(max_value, parsed))


def _qqokx_env_float(name: str, default: float, *, min_value: float, max_value: float) -> float:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return default
    try:
        parsed = float(raw)
    except ValueError:
        return default
    return max(min_value, min(max_value, parsed))


def get_okx_read_retry_config() -> tuple[int, float, float]:
    """OKX 读取重试：每次调用读取 os.environ，便于测试与部署后调参（弱网/VPN 可多试几次）。"""
    base = _qqokx_env_float(
        "QQOKX_READ_RETRY_BASE_DELAY_SECONDS",
        1.0,
        min_value=0.1,
        max_value=60.0,
    )
    max_delay = _qqokx_env_float(
        "QQOKX_READ_RETRY_MAX_DELAY_SECONDS",
        8.0,
        min_value=max(0.5, base),
        max_value=120.0,
    )
    attempts = _qqokx_env_int(
        "QQOKX_READ_RETRY_ATTEMPTS",
        8,
        min_value=1,
        max_value=30,
    )
    return attempts, base, max_delay


OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES = 6
# 挂单中连续若干轮找不到原算法止损后，结合持仓相对基准的缩量 / 行情与止损位推断已触发，结束接管监控（避免交易所已成交仍假死轮询）
OKX_DYNAMIC_STOP_MISSING_ALGO_MIN_POLLS = 2
OKX_DYNAMIC_STOP_MISSING_ALGO_PRICE_EXIT_POLLS = 12
OKX_DYNAMIC_STOP_MISSING_ALGO_FORCE_EXIT_POLLS = 24
OKX_WRITE_RECONCILE_ATTEMPTS = 3
OKX_WRITE_RECONCILE_BASE_DELAY_SECONDS = 1.0
OKX_WRITE_RECONCILE_MAX_DELAY_SECONDS = 3.0
IDLE_SIGNAL_MAX_WAIT_SECONDS = 60.0

T = TypeVar("T")


def _dynamic_stop_infer_triggered_algo_not_in_book(
    *,
    direction: Literal["long", "short"],
    live_abs: Decimal,
    baseline_abs: Decimal | None,
    monitored_sz: Decimal,
    current_price: Decimal,
    current_stop_loss: Decimal,
    initial_stop_loss: Decimal,
    missing_rounds: int,
    lot_size: Decimal,
) -> tuple[bool, str | None]:
    """算法止损已从挂单消失若干轮后：用持仓缩量 / OKX 查询终态 / 行情与止损带推断已触发，避免监控永不退出。"""
    if missing_rounds < OKX_DYNAMIC_STOP_MISSING_ALGO_MIN_POLLS:
        return False, None
    lot = lot_size if lot_size and lot_size > 0 else Decimal("0")
    sz = monitored_sz if monitored_sz and monitored_sz > 0 else Decimal("0")
    if sz > 0 and baseline_abs is not None and baseline_abs > 0:
        reduced = baseline_abs - live_abs
        thresh = max(sz - lot * Decimal("2"), sz * Decimal("0.65"))
        if thresh > 0 and reduced >= thresh - lot:
            return True, (
                "监控的止损算法单已不在挂单列表，且持仓张数已减少 "
                f"{format_decimal(reduced)}（基准 {format_decimal(baseline_abs)} → 当前 {format_decimal(live_abs)}），"
                "推断该止损已触发，结束 OKX 动态止损监控。"
            )
    if missing_rounds >= OKX_DYNAMIC_STOP_MISSING_ALGO_PRICE_EXIT_POLLS:
        # 多头止损上移后 current_stop_loss 常仍低于市价；用 max(初始, 当前) 作为「已上移后的有效触发带」上沿，
        # 避免「市价已高于当前止损线」导致永远不命中旧推断条件。
        if current_price and current_price > 0:
            if direction == "long":
                ref = current_stop_loss
                if initial_stop_loss and initial_stop_loss > 0:
                    ref = max(initial_stop_loss, current_stop_loss)
                if current_price <= ref:
                    return True, (
                        "止损算法单已长期不在挂单列表，且触发价已不高于有效止损带（初始/当前较高线），"
                        "推断已触发或该单已结束，停止监控。"
                    )
            else:
                ref = current_stop_loss
                if initial_stop_loss and initial_stop_loss > 0:
                    ref = min(initial_stop_loss, current_stop_loss)
                if current_price >= ref:
                    return True, (
                        "止损算法单已长期不在挂单列表，且触发价已不低于有效止损带（初始/当前较低线），"
                        "推断已触发或该单已结束，停止监控。"
                    )
    if missing_rounds >= OKX_DYNAMIC_STOP_MISSING_ALGO_FORCE_EXIT_POLLS:
        return True, (
            "止损算法单持续不在挂单列表，停止监控以免界面假死；请在交易所核对实际成交与剩余持仓。"
        )
    return False, None


@dataclass(frozen=True)
class HourlyDebugSnapshot:
    candle_ts: int
    candle_close: Decimal
    ema_value: Decimal
    ema_period: int
    atr_value: Decimal
    atr_period: int
    lookback_used: int
    confirmed_count: int
    ma_type: str = "ema"


@dataclass(frozen=True)
class AtrSnapshot:
    candle_ts: int
    candle_close: Decimal
    atr_value: Decimal
    lookback_used: int
    confirmed_count: int


@dataclass(frozen=True)
class ManagedEntryOrder:
    ord_id: str
    cl_ord_id: str | None
    candle_ts: int
    entry_reference: Decimal
    stop_loss: Decimal
    take_profit: Decimal
    stop_loss_algo_cl_ord_id: str | None
    size: Decimal
    side: Literal["buy", "sell"]
    signal: Literal["long", "short"]
    stop_loss_algo_id: str | None = None


@dataclass(frozen=True)
class FilledPosition:
    ord_id: str
    cl_ord_id: str | None
    inst_id: str
    side: Literal["buy", "sell"]
    close_side: Literal["buy", "sell"]
    pos_side: Literal["long", "short"] | None
    size: Decimal
    entry_price: Decimal
    entry_ts: int
    price_delta_multiplier: Decimal = Decimal("1")


@dataclass(frozen=True)
class CancelActiveOrderResult:
    action: Literal["canceled", "pending", "filled", "partially_filled"]
    status: OkxOrderStatus | None = None


@dataclass(frozen=True)
class LocalSignalTrigger:
    signal: Literal["long", "short"]
    entry_reference: Decimal
    atr_value: Decimal
    candle_ts: int
    signal_candle_high: Decimal | None
    signal_candle_low: Decimal | None


@dataclass(frozen=True)
class DynamicStopMonitorStepResult:
    keep_monitoring: bool
    current_stop_loss: Decimal
    next_trigger_r: int
    amend_failures: int
    missing_algo_strikes: int = 0
    seed_baseline_abs: Decimal | None = None
    trend_ema_close_exit_armed: bool = False
    trend_ema_close_exit_last_candle_ts: int | None = None


class OrderSizeTooSmallError(RuntimeError):
    pass


@dataclass
class StartupSignalGateState:
    started_at_ms: int
    chase_window_seconds: int
    chase_current_signal: bool = False
    blocked_signal: Literal["long", "short"] | None = None


@dataclass(frozen=True)
class ManualTradeControlState:
    management_mode: Literal["auto", "manual"] = "auto"
    manual_reason: str = ""
    stop_loss: Decimal | None = None
    updated_at_ms: int = 0


class StrategyEngine:
    def __init__(
        self,
        client: OkxRestClient,
        logger: Logger,
        *,
        market_data_hub: MarketDataHub | None = None,
        notifier: EmailNotifier | None = None,
        strategy_name: str = "Strategy",
        session_id: str = "",
        direction_label: str = "",
        run_mode_label: str = "",
        trader_id: str = "",
        api_name: str = "",
        trade_settlement_waiter: Callable[[threading.Event], bool] | None = None,
    ) -> None:
        self._client = client
        self._logger = logger
        self._market_data_hub = market_data_hub
        self._notifier = notifier
        self._strategy_name = strategy_name
        self._session_id = session_id
        self._direction_label = direction_label.strip()
        self._run_mode_label = run_mode_label.strip()
        self._trader_id = trader_id.strip()
        self._api_name = api_name.strip()
        self._trade_settlement_waiter = trade_settlement_waiter
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        self._order_ref_counter = 0
        self._manual_trade_control = ManualTradeControlState()
        self._ema55_slope_same_bar_reentry_block_ts: dict[tuple[str, str, str, str], int] = {}
        self._session_runner = EngineSessionRunner(self)
        self._strategy_router = EngineStrategyRouter(self)
        self._retry_policy = EngineRetryPolicy(self)
        self._order_service = EngineOrderService(self)

    def set_notifier(self, notifier: EmailNotifier | None) -> None:
        """Replace the email notifier without restarting the strategy engine."""
        with self._lock:
            self._notifier = notifier

    @property
    def is_running(self) -> bool:
        return self._session_runner.is_running

    @staticmethod
    def _runtime_heartbeat_message(label: str) -> str:
        normalized = str(label or "").strip() or "持仓监控"
        return f"{_RUNTIME_HEARTBEAT_PREFIX}{normalized}"

    def _emit_runtime_heartbeat(self, label: str) -> None:
        self._logger(self._runtime_heartbeat_message(label))

    def start(self, credentials: Credentials, config: StrategyConfig) -> None:
        self._session_runner.start(credentials, config)

    def start_custom(self, target: Callable[[], None], *, thread_name: str) -> None:
        self._session_runner.start_custom(target, thread_name=thread_name)

    def stop(self) -> None:
        self._session_runner.stop()

    def _wait_for_trade_settlement(self) -> bool:
        waiter = self._trade_settlement_waiter
        if waiter is None:
            return True
        while not self._stop_event.is_set():
            try:
                settled = waiter(self._stop_event)
            except Exception as exc:
                settled = False
                self._logger(f"本轮结算协调异常，开仓门禁保持关闭 | {exc}")
            if settled:
                self._logger("本轮结算完成，开仓门禁已释放。")
                return True
            if self._stop_event.is_set():
                break
            self._logger("本轮结算尚未完成，开仓门禁保持关闭，5秒后重试。")
            self._stop_event.wait(5)
        return False

    def wait_stopped(self, timeout: float | None = None) -> bool:
        return self._session_runner.wait_stopped(timeout=timeout)

    def get_manual_trade_control(self) -> ManualTradeControlState:
        with self._lock:
            return self._manual_trade_control

    def set_manual_stop_loss_override(self, stop_loss: Decimal, *, reason: str = "manual_stop_loss") -> ManualTradeControlState:
        state = ManualTradeControlState(
            management_mode="manual",
            manual_reason=str(reason or "manual_stop_loss").strip() or "manual_stop_loss",
            stop_loss=stop_loss,
            updated_at_ms=int(time.time() * 1000),
        )
        with self._lock:
            self._manual_trade_control = state
        return state

    def mark_manual_flatten(self) -> ManualTradeControlState:
        state = ManualTradeControlState(
            management_mode="manual",
            manual_reason="manual_flatten",
            stop_loss=None,
            updated_at_ms=int(time.time() * 1000),
        )
        with self._lock:
            self._manual_trade_control = state
        return state

    def resume_automatic_trade_management(self) -> ManualTradeControlState:
        state = ManualTradeControlState(updated_at_ms=int(time.time() * 1000))
        with self._lock:
            self._manual_trade_control = state
        return state

    def _ema55_slope_same_bar_reentry_key(self, credentials: Credentials, config: StrategyConfig) -> tuple[str, str, str, str]:
        return (
            str(credentials.profile_name or "").strip(),
            str(config.environment or "").strip(),
            str(config.strategy_id or "").strip(),
            str(config.inst_id or "").strip(),
        )

    def _get_ema55_slope_same_bar_reentry_block_ts(self, credentials: Credentials, config: StrategyConfig) -> int | None:
        key = self._ema55_slope_same_bar_reentry_key(credentials, config)
        with self._lock:
            return self._ema55_slope_same_bar_reentry_block_ts.get(key)

    def _mark_ema55_slope_same_bar_reentry_block(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        candle_ts: int | None,
    ) -> None:
        if not config.ema55_slope_same_bar_reentry_block or candle_ts is None:
            return
        key = self._ema55_slope_same_bar_reentry_key(credentials, config)
        with self._lock:
            self._ema55_slope_same_bar_reentry_block_ts[key] = candle_ts
        self._logger(f"已记录同K线禁重开门禁 | K线时间={_fmt_ts(candle_ts)}")

    def _clear_ema55_slope_same_bar_reentry_block_if_advanced(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        candle_ts: int | None,
    ) -> None:
        if candle_ts is None:
            return
        key = self._ema55_slope_same_bar_reentry_key(credentials, config)
        with self._lock:
            blocked_ts = self._ema55_slope_same_bar_reentry_block_ts.get(key)
            if blocked_ts is not None and candle_ts > blocked_ts:
                self._ema55_slope_same_bar_reentry_block_ts.pop(key, None)

    def amend_exchange_manual_stop_loss(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        algo_id: str | None,
        algo_cl_ord_id: str | None,
        stop_loss: Decimal,
    ) -> None:
        self._amend_algo_order_with_recovery(
            credentials,
            config,
            trade_instrument=trade_instrument,
            algo_id=algo_id,
            algo_cl_ord_id=algo_cl_ord_id,
            req_id=self._next_client_order_id(role="msl"),
            new_stop_loss_trigger_price=stop_loss,
            new_stop_loss_trigger_price_type=config.tp_sl_trigger_type,
            recover_algo_id=algo_id,
            recover_algo_cl_ord_id=algo_cl_ord_id,
        )
        self.set_manual_stop_loss_override(stop_loss)

    def _run(self, credentials: Credentials, config: StrategyConfig) -> None:
        self._strategy_router.run(credentials, config)

    def _load_mtf_filter_confirmed_candles(self, config: StrategyConfig) -> list:
        lookback = recommended_indicator_lookback(
            int(config.mtf_filter_fast_ema_period),
            int(config.mtf_filter_slow_ema_period),
        )
        candles = self._get_candles_with_retry(
            config.resolved_mtf_filter_inst_id(),
            config.resolved_mtf_filter_bar(),
            limit=lookback,
        )
        return [candle for candle in candles if candle.confirmed]

    def _get_candles_history_range_with_retry(
        self,
        inst_id: str,
        bar: str,
        *,
        start_ts: int,
        end_ts: int,
        preload_count: int = 0,
    ) -> list:
        return self._retry_policy.call_okx_read_with_retry(
            f"读取历史K线 {inst_id} {bar}",
            lambda: self._client.get_candles_history_range(
                inst_id,
                bar,
                start_ts=start_ts,
                end_ts=end_ts,
                limit=0,
                preload_count=preload_count,
            ),
        )

    def _load_daily_filter_confirmed_candles(
        self,
        config: StrategyConfig,
        entry_candles: list,
    ) -> list:
        if not config.uses_daily_filter() or not entry_candles:
            return []
        inst_id = config.resolved_daily_filter_inst_id()
        boundary = str(config.daily_filter_boundary or "exchange").strip().lower()
        period = max(int(config.daily_filter_period), 1)
        daily_lookback = max(recommended_indicator_lookback(period), period + 5)
        if boundary == "exchange":
            candles = self._get_candles_with_retry(
                inst_id,
                config.resolved_daily_filter_bar(),
                limit=daily_lookback,
            )
            return [candle for candle in candles if candle.confirmed]

        end_ts = int(entry_candles[-1].ts)
        hourly_lookback = max((daily_lookback + 2) * 24, 72)
        start_ts = end_ts - (hourly_lookback - 1) * _HOUR_MS
        hourly_candles = self._get_candles_history_range_with_retry(
            inst_id,
            "1H",
            start_ts=start_ts,
            end_ts=end_ts,
        )
        confirmed_hourly = [candle for candle in hourly_candles if candle.confirmed]
        daily_candles, _audits = aggregate_candles_to_daily_boundary(
            confirmed_hourly,
            boundary=boundary,
        )
        return daily_candles

    def _expand_daily_filter_bias_scope(self, base_bias: list[str], scope: str) -> list[str]:
        normalized_scope = str(scope or "both").strip().lower()
        expanded: list[str] = []
        for bias in base_bias:
            if normalized_scope == "long_only":
                expanded.append("both" if bias == "long" else "short")
            elif normalized_scope == "short_only":
                expanded.append("both" if bias == "short" else "long")
            else:
                expanded.append(bias)
        return expanded

    def _build_live_daily_direction_filter_bias(
        self,
        entry_candles: list,
        config: StrategyConfig,
    ) -> list[str]:
        if not entry_candles:
            return []
        mode = str(config.daily_filter_mode or "disabled").strip().lower()
        if mode == "disabled":
            return ["neutral"] * len(entry_candles)
        daily_candles = self._load_daily_filter_confirmed_candles(config, entry_candles)
        if not daily_candles:
            return ["neutral"] * len(entry_candles)
        if mode == "weak_day":
            weak_day_flags = build_daily_weak_day_flags(entry_candles, daily_candles)
            base_bias = ["short" if is_weak else "long" for is_weak in weak_day_flags]
        else:
            base_bias = build_daily_close_vs_ma_bias(
                entry_candles,
                daily_candles,
                ma_type=str(config.daily_filter_ma_type or "ema").strip().lower(),
                period=max(int(config.daily_filter_period), 1),
            )
        return self._expand_daily_filter_bias_scope(base_bias, config.daily_filter_scope)

    @staticmethod
    def _daily_filter_allows_signal(direction_filter_bias: str | None, signal: str | None) -> bool:
        if signal is None:
            return True
        if direction_filter_bias == "both":
            return True
        if signal == "long":
            return direction_filter_bias == "long"
        if signal == "short":
            return direction_filter_bias == "short"
        return True

    def _apply_live_daily_filter_to_decision(
        self,
        entry_candles: list,
        config: StrategyConfig,
        decision: SignalDecision,
    ) -> SignalDecision:
        if not config.uses_daily_filter() or decision.signal is None:
            return decision
        bias = self._build_live_daily_direction_filter_bias(entry_candles, config)
        latest_bias = bias[-1] if bias else "neutral"
        if self._daily_filter_allows_signal(latest_bias, decision.signal):
            return decision
        return replace(
            decision,
            signal=None,
            reason=f"{decision.reason} | 日线过滤未放行（{config.daily_filter_summary()} | 当前={latest_bias}）",
        )

    def _evaluate_dynamic_signal_decision(
        self,
        confirmed: list,
        config: StrategyConfig,
        *,
        effective_signal_mode: str,
        price_increment: Decimal | None,
    ) -> SignalDecision:
        eval_config = replace(config, signal_mode=effective_signal_mode)
        if strategy_uses_mtf_filter(config.strategy_id):
            decision = EmaDynamicMultiTimeframeStrategy().evaluate(
                confirmed,
                self._load_mtf_filter_confirmed_candles(config),
                eval_config,
                price_increment=price_increment,
            )
            return self._apply_live_daily_filter_to_decision(confirmed, config, decision)
        decision = EmaDynamicOrderStrategy().evaluate(
            confirmed,
            eval_config,
            price_increment=price_increment,
        )
        return self._apply_live_daily_filter_to_decision(confirmed, config, decision)

    def _log_entry_order_tracking(
        self,
        candle_ts: int,
        *,
        cl_ord_id: str | None,
        entry_reference: Decimal,
        price_label: str = "挂单价",
    ) -> None:
        self._logger(
            f"{_fmt_ts(candle_ts)} | 委托追踪 | clOrdId={cl_ord_id or '-'} | "
            f"{price_label}={format_decimal(entry_reference)}"
        )

    def _log_dynamic_position_closed(self, active_order: ManagedEntryOrder) -> None:
        self._logger(
            "仓位关闭已确认"
            f" | 原开仓ordId={active_order.ord_id or '-'}"
            f" | clOrdId={active_order.cl_ord_id or '-'}"
            " | 开仓门禁保持关闭 | 开始结算归因"
        )
        self._wait_for_trade_settlement()

    def _append_dynamic_mtf_mode_parts(self, config: StrategyConfig, mode_parts: list[str]) -> None:
        if not strategy_uses_mtf_filter(config.strategy_id):
            return
        reversal_text = "停止新增仓位" if config.mtf_reversal_mode == "block_new_entries" else "不处理"
        mode_parts.append(
            f"高周期过滤={config.resolved_mtf_filter_inst_id()}/{config.resolved_mtf_filter_bar()} "
            f"EMA{config.mtf_filter_fast_ema_period}/EMA{config.mtf_filter_slow_ema_period}"
        )
        mode_parts.append(f"高周期反转={reversal_text}")

    @staticmethod
    def _append_daily_filter_mode_parts(config: StrategyConfig, mode_parts: list[str]) -> None:
        if not config.uses_daily_filter():
            return
        mode_parts.append(config.daily_filter_summary())

    def _refresh_dynamic_entry_candle_baseline(
        self,
        config: StrategyConfig,
        *,
        lookback: int,
        fallback_ts: int,
    ) -> int:
        candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
        confirmed = [candle for candle in candles if candle.confirmed]
        return confirmed[-1].ts if confirmed else fallback_ts

    def _run_dynamic_exchange_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        effective_signal_mode = resolve_dynamic_signal_mode(config.strategy_id, config.signal_mode)
        if effective_signal_mode == "both":
            raise RuntimeError("EMA 动态委托策略不支持双向，请选择只做多或只做空")
        has_risk_amount = config.risk_amount is not None and config.risk_amount > 0
        has_fixed_size = config.order_size > 0
        if not has_risk_amount and not has_fixed_size:
            raise RuntimeError("风险金必须大于 0，或固定数量必须大于 0")

        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        active_order: ManagedEntryOrder | None = None
        idle_signal_candle_ts: int | None = None
        dynamic_stop_only = config.take_profit_mode == "dynamic"
        trader_virtual_stop_loss_enabled = config.trader_virtual_stop_loss
        current_wave_signal: Literal["long", "short"] | None = None
        entries_in_current_wave = 0
        current_wave_index = 0
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._log_strategy_start(config, instrument, instrument)
        if trader_virtual_stop_loss_enabled:
            self._logger("交易员模式：止损价只做触发参考，不向 OKX 挂真实止损；只有止盈或人工平仓才释放额度。")
            self._logger("运行模式：同标的永续下单，交易员虚拟止损只记触发，不向 OKX 挂真实止损。")
        else:
            self._logger("运行模式：同标的永续下单，止盈止损交给 OKX 托管")
        self._logger(
            f"策略规则：以上一根已收盘 K 线的 {_dynamic_entry_reference_ema_text(config)} 作为开仓价直接挂限价单。"
            f"每根新 K 线确认后，撤掉旧单，再按最新上一根 {_dynamic_entry_reference_ema_text(config)} 重新挂单。"
        )
        mode_parts = [
            f"方向={_format_signal_mode(config.signal_mode)}",
            (
                f"风险金={format_decimal(config.risk_amount)}"
                if has_risk_amount
                else f"固定数量={_format_size_with_contract_equivalent(instrument, config.order_size)}"
            ),
            f"止损ATR倍数={format_decimal(config.atr_stop_multiplier)}",
            f"止盈ATR倍数={format_decimal(config.atr_take_multiplier)}",
            f"每波最多开仓次数={config.max_entries_per_trend or 0}",
            f"启动追单窗口={config.startup_chase_window_label()}",
            f"启动追当前信号={'开启' if config.startup_chase_current_signal else '关闭'}",
        ]
        if config.uses_reentry_confirmation():
            mode_parts.append(config.reentry_confirmation_summary())
        self._append_dynamic_mtf_mode_parts(config, mode_parts)
        self._append_daily_filter_mode_parts(config, mode_parts)
        self._logger(" | ".join(mode_parts))
        if dynamic_stop_only and trader_virtual_stop_loss_enabled:
            self._logger(
                f"动态止盈已启用 | {_live_dynamic_break_even_summary(config)} | "
                f"手续费偏移={config.dynamic_fee_offset_enabled_label()} | "
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根 | "
                "交易员模式：止损价只做触发参考，不会直接平仓。"
            )
        elif dynamic_stop_only:
            self._logger(
                f"动态止盈已启用 | {_live_dynamic_break_even_summary(config)} | "
                f"手续费偏移={config.dynamic_fee_offset_enabled_label()} | "
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根 | "
                "初始仅在 OKX 挂止损"
            )
        self._logger(f"指标回看数量：{lookback} 根 K 线")

        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            entry_reference_ema_period=entry_reference_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts

            if active_order is not None:
                status = self._get_order_with_retry(
                    credentials,
                    config,
                    inst_id=config.inst_id,
                    ord_id=active_order.ord_id,
                )
                state = status.state.lower()
                if state == "filled":
                    filled_price = status.avg_price or status.price or active_order.entry_reference
                    entries_in_current_wave += 1
                    self._manage_filled_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    # After a round-trip closes on the current confirmed candle,
                    # do not immediately re-place another entry from the same
                    # candle's reference price. Wait for the next confirmed bar.
                    if self._stop_event.is_set():
                        return
                    self._log_dynamic_position_closed(active_order)
                    active_order = None
                    idle_signal_candle_ts = self._refresh_dynamic_entry_candle_baseline(
                        config,
                        lookback=lookback,
                        fallback_ts=newest_ts,
                    )
                    last_candle_ts = idle_signal_candle_ts
                    continue
                if state == "partially_filled":
                    partial_managed = self._handle_partial_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    if not partial_managed:
                        self._stop_event.wait(config.poll_seconds)
                        continue
                    entries_in_current_wave += 1
                    if self._stop_event.is_set():
                        return
                    self._log_dynamic_position_closed(active_order)
                    active_order = None
                    idle_signal_candle_ts = self._refresh_dynamic_entry_candle_baseline(
                        config,
                        lookback=lookback,
                        fallback_ts=newest_ts,
                    )
                    last_candle_ts = idle_signal_candle_ts
                    continue
                if state not in {"live"}:
                    self._logger(
                        f"{_fmt_ts(newest_ts)} | 检测到挂单状态已变更为 {status.state}，准备重新同步挂单。"
                    )
                    active_order = None
                    idle_signal_candle_ts = None

            candle_changed = newest_ts != last_candle_ts
            if active_order is not None and candle_changed:
                cancel_result = self._cancel_active_order(credentials, config, active_order, newest_ts)
                if cancel_result.action == "pending":
                    self._stop_event.wait(config.poll_seconds)
                    continue
                if cancel_result.action == "filled":
                    status = cancel_result.status
                    if status is None:
                        raise RuntimeError(f"旧挂单成交回查缺少订单状态，ordId={active_order.ord_id}")
                    entries_in_current_wave += 1
                    self._logger(
                        f"{_fmt_ts(newest_ts)} | 旧挂单在撤单前已成交，转入持仓监控 | ordId={status.ord_id or active_order.ord_id}"
                    )
                    self._manage_filled_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    if self._stop_event.is_set():
                        return
                    self._log_dynamic_position_closed(active_order)
                    active_order = None
                    idle_signal_candle_ts = self._refresh_dynamic_entry_candle_baseline(
                        config,
                        lookback=lookback,
                        fallback_ts=newest_ts,
                    )
                    last_candle_ts = idle_signal_candle_ts
                    continue
                if cancel_result.action == "partially_filled":
                    status = cancel_result.status
                    if status is None:
                        raise RuntimeError(f"旧挂单部分成交回查缺少订单状态，ordId={active_order.ord_id}")
                    partial_managed = self._handle_partial_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    if not partial_managed:
                        self._stop_event.wait(config.poll_seconds)
                        continue
                    entries_in_current_wave += 1
                    if self._stop_event.is_set():
                        return
                    self._log_dynamic_position_closed(active_order)
                    active_order = None
                    idle_signal_candle_ts = self._refresh_dynamic_entry_candle_baseline(
                        config,
                        lookback=lookback,
                        fallback_ts=newest_ts,
                    )
                    last_candle_ts = idle_signal_candle_ts
                    continue
                active_order = None

            if active_order is None and idle_signal_candle_ts == newest_ts:
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue

            should_place_order = candle_changed or active_order is None
            if not should_place_order:
                self._stop_event.wait(config.poll_seconds)
                continue

            decision = self._evaluate_dynamic_signal_decision(
                confirmed,
                config,
                effective_signal_mode=effective_signal_mode,
                price_increment=instrument.tick_size,
            )
            last_candle_ts = newest_ts
            if decision.signal is None:
                current_wave_signal = None
                entries_in_current_wave = 0
                _reset_startup_signal_gate(startup_gate)
                idle_signal_candle_ts = newest_ts
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无法生成挂单 | {decision.reason}")
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue

            if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                raise RuntimeError("策略返回的数据不完整，无法生成挂单计划")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                idle_signal_candle_ts = newest_ts
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue

            if current_wave_signal != decision.signal:
                current_wave_signal = decision.signal
                entries_in_current_wave = 0
                current_wave_index += 1
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势开始 | 方向={decision.signal.upper()}"
                )

            if config.max_entries_per_trend > 0 and entries_in_current_wave >= config.max_entries_per_trend:
                idle_signal_candle_ts = newest_ts
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势开仓次数已达上限 | "
                    f"方向={decision.signal.upper()} | 上限={config.max_entries_per_trend}"
                )
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            next_wave_entry_sequence = entries_in_current_wave + 1
            reentry_block_reason = _dynamic_reentry_confirmation_block_reason(
                config,
                confirmed,
                signal=decision.signal,
                wave_entry_sequence=next_wave_entry_sequence,
            )
            if reentry_block_reason:
                idle_signal_candle_ts = newest_ts
                self._logger(f"{_fmt_ts(decision.candle_ts)} | {reentry_block_reason}")
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue

            try:
                plan = build_order_plan(
                    instrument=instrument,
                    config=config,
                    order_size=config.order_size if config.order_size > 0 else None,
                    signal=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                idle_signal_candle_ts = newest_ts
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前无法生成挂单 | {exc}")
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            should_skip_by_stop, stop_crossed_message = self._should_skip_dynamic_entry_when_stop_crossed(
                config,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                trigger_inst_id=plan.inst_id,
                stop_loss=plan.stop_loss,
                gate_state=startup_gate if startup_gate_message else None,
            )
            if should_skip_by_stop:
                idle_signal_candle_ts = newest_ts
                if stop_crossed_message:
                    self._logger(stop_crossed_message)
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            self._logger(
                f"{_fmt_ts(plan.candle_ts)} | 准备挂单 | 方向={plan.signal.upper()} | "
                f"第{current_wave_index}波 | 本波第{entries_in_current_wave + 1}次委托 | "
                f"开仓价={format_decimal(plan.entry_reference)} | 数量={_format_size_with_contract_equivalent(instrument, plan.size)} | "
                f"止损={format_decimal(plan.stop_loss)} | "
                f"{'动态止盈=初始不挂止盈' if dynamic_stop_only else f'止盈={format_decimal(plan.take_profit)}'}"
            )
            submission = self._submit_dynamic_limit_entry_order(
                credentials,
                config,
                plan=plan,
                dynamic_stop_only=dynamic_stop_only,
                trader_virtual_stop_loss_enabled=trader_virtual_stop_loss_enabled,
            )
            if submission is None:
                idle_signal_candle_ts = newest_ts
                last_candle_ts = newest_ts
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            cl_ord_id, result, stop_loss_algo_cl_ord_id = submission
            if not result.ord_id:
                raise RuntimeError("OKX 未返回挂单 ordId，无法继续监控该委托")
            active_order = ManagedEntryOrder(
                ord_id=result.ord_id,
                cl_ord_id=result.cl_ord_id or cl_ord_id,
                candle_ts=plan.candle_ts,
                entry_reference=plan.entry_reference,
                stop_loss=plan.stop_loss,
                take_profit=plan.take_profit,
                stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                size=plan.size,
                side=plan.side,
                signal=plan.signal,
                stop_loss_algo_id=None,
            )
            idle_signal_candle_ts = None
            self._logger(
                f"{_fmt_ts(plan.candle_ts)} | 挂单已提交到 OKX | ordId={result.ord_id or '-'} | "
                f"sCode={result.s_code} | sMsg={result.s_msg or 'accepted'}"
            )
            self._log_entry_order_tracking(
                plan.candle_ts,
                cl_ord_id=active_order.cl_ord_id,
                entry_reference=active_order.entry_reference,
            )
            self._stop_event.wait(config.poll_seconds)

    def resume_dynamic_exchange_pending_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        instrument: Instrument,
        *,
        ord_id: str,
        cl_ord_id: str | None,
        candle_ts: int,
        entry_reference: Decimal,
        stop_loss: Decimal,
        take_profit: Decimal,
        size: Decimal,
        side: Literal["buy", "sell"],
        signal: Literal["long", "short"],
        stop_loss_algo_cl_ord_id: str | None = None,
        stop_loss_algo_id: str | None = None,
    ) -> None:
        active_order = ManagedEntryOrder(
            ord_id=ord_id,
            cl_ord_id=cl_ord_id,
            candle_ts=candle_ts,
            entry_reference=entry_reference,
            stop_loss=stop_loss,
            take_profit=take_profit,
            stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
            size=size,
            side=side,
            signal=signal,
            stop_loss_algo_id=stop_loss_algo_id,
        )
        self._resume_dynamic_exchange_pending_order_loop(
            credentials,
            config,
            instrument,
            active_order=active_order,
        )

    def _resume_dynamic_exchange_pending_order_loop(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        instrument: Instrument,
        *,
        active_order: ManagedEntryOrder,
    ) -> None:
        effective_signal_mode = resolve_dynamic_signal_mode(config.strategy_id, config.signal_mode)
        if effective_signal_mode == "both":
            raise RuntimeError("EMA 动态委托策略不支持双向，请选择只做多或只做空")

        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = active_order.candle_ts
        idle_signal_candle_ts: int | None = None
        dynamic_stop_only = config.take_profit_mode == "dynamic"

        self._logger(
            "恢复动态挂单接管 | "
            f"标的={instrument.inst_id} | ordId={active_order.ord_id} | "
            f"clOrdId={active_order.cl_ord_id or '-'} | 方向={active_order.signal.upper()} | "
            f"挂单价={format_decimal(active_order.entry_reference)} | 数量={_format_size_with_contract_equivalent(instrument, active_order.size)}"
        )

        while not self._stop_event.is_set():
            status = self._get_order_with_retry(
                credentials,
                config,
                inst_id=config.inst_id,
                ord_id=active_order.ord_id,
                cl_ord_id=active_order.cl_ord_id,
            )
            state = status.state.lower()
            newest_ts = int(time.time() * 1000)
            if state == "filled":
                if dynamic_stop_only and not (
                    (active_order.stop_loss_algo_cl_ord_id or "").strip()
                    or (active_order.stop_loss_algo_id or "").strip()
                ):
                    recovered_algo = self._find_latest_pending_stop_algo_order(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        signal=active_order.signal,
                    )
                    if recovered_algo is not None:
                        active_order = ManagedEntryOrder(
                            ord_id=active_order.ord_id,
                            cl_ord_id=active_order.cl_ord_id,
                            candle_ts=active_order.candle_ts,
                            entry_reference=active_order.entry_reference,
                            stop_loss=active_order.stop_loss,
                            take_profit=active_order.take_profit,
                            stop_loss_algo_cl_ord_id=(
                                (recovered_algo.algo_client_order_id or recovered_algo.client_order_id or "").strip()
                                or active_order.stop_loss_algo_cl_ord_id
                            ),
                            size=active_order.size,
                            side=active_order.side,
                            signal=active_order.signal,
                            stop_loss_algo_id=(recovered_algo.algo_id or "").strip() or active_order.stop_loss_algo_id,
                        )
                if dynamic_stop_only and not (
                    (active_order.stop_loss_algo_cl_ord_id or "").strip()
                    or (active_order.stop_loss_algo_id or "").strip()
                ):
                    filled_price = status.avg_price or status.price or active_order.entry_reference
                    filled_size = status.filled_size or status.size or active_order.size
                    recovered_pos_side = self._resolve_filled_position_pos_side(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        side=active_order.side,
                        pos_side=resolve_open_pos_side(config, active_order.side),
                    )
                    position = FilledPosition(
                        ord_id=status.ord_id or active_order.ord_id,
                        cl_ord_id=active_order.cl_ord_id,
                        inst_id=instrument.inst_id,
                        side=active_order.side,
                        close_side="sell" if active_order.side == "buy" else "buy",
                        pos_side=recovered_pos_side,
                        size=filled_size,
                        entry_price=filled_price,
                        entry_ts=int(time.time() * 1000),
                        price_delta_multiplier=_instrument_price_delta_multiplier(instrument),
                    )
                    stop_loss_algo_id, stop_loss_algo_cl_ord_id, created_after_fill = self._ensure_exchange_stop_loss_algo(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        position=position,
                        stop_loss=active_order.stop_loss,
                        stop_loss_algo_id=active_order.stop_loss_algo_id,
                        stop_loss_algo_cl_ord_id=active_order.stop_loss_algo_cl_ord_id,
                    )
                    if created_after_fill:
                        self._logger(
                            "恢复中的挂单已成交，未找到可接管的 OKX 止损算法单，已补挂新的初始止损"
                            f" | ordId={status.ord_id or active_order.ord_id} | "
                            f"algoClOrdId={stop_loss_algo_cl_ord_id or '-'} | algoId={stop_loss_algo_id or '-'}"
                        )
                    active_order = replace(
                        active_order,
                        stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                        stop_loss_algo_id=stop_loss_algo_id,
                    )
                self._manage_filled_dynamic_entry(
                    credentials,
                    config,
                    trade_instrument=instrument,
                    active_order=active_order,
                    status=status,
                    newest_ts=newest_ts,
                    dynamic_stop_only=dynamic_stop_only,
                )
                if self._stop_event.is_set():
                    return
                self._log_dynamic_position_closed(active_order)
                self.resume_automatic_trade_management()
                return
            if state == "partially_filled":
                partial_managed = self._handle_partial_dynamic_entry(
                    credentials,
                    config,
                    trade_instrument=instrument,
                    active_order=active_order,
                    status=status,
                    newest_ts=newest_ts,
                    dynamic_stop_only=dynamic_stop_only,
                )
                if partial_managed:
                    if self._stop_event.is_set():
                        return
                    self._log_dynamic_position_closed(active_order)
                    self.resume_automatic_trade_management()
                    return
                self._stop_event.wait(config.poll_seconds)
                continue
            if state != "live":
                self._logger(
                    f"{_fmt_ts(newest_ts)} | 恢复接管的挂单状态已变更为 {status.state}，结束本次挂单恢复。"
                )
                return

            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，保留现有挂单继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_candle_ts = confirmed[-1].ts
            candle_changed = newest_candle_ts != last_candle_ts
            if candle_changed:
                cancel_result = self._cancel_active_order(credentials, config, active_order, newest_candle_ts)
                if cancel_result.action == "pending":
                    self._stop_event.wait(config.poll_seconds)
                    continue
                if cancel_result.action == "filled":
                    status = cancel_result.status
                    if status is None:
                        raise RuntimeError(f"旧挂单成交回查缺少订单状态，ordId={active_order.ord_id}")
                    self._logger(
                        f"{_fmt_ts(newest_candle_ts)} | 恢复中的旧挂单在撤单前已成交，转入持仓监控 | ordId={status.ord_id or active_order.ord_id}"
                    )
                    self._manage_filled_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_candle_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    return
                if cancel_result.action == "partially_filled":
                    status = cancel_result.status
                    if status is None:
                        raise RuntimeError(f"旧挂单部分成交回查缺少订单状态，ordId={active_order.ord_id}")
                    partial_managed = self._handle_partial_dynamic_entry(
                        credentials,
                        config,
                        trade_instrument=instrument,
                        active_order=active_order,
                        status=status,
                        newest_ts=newest_candle_ts,
                        dynamic_stop_only=dynamic_stop_only,
                    )
                    if partial_managed:
                        if self._stop_event.is_set():
                            return
                        self._log_dynamic_position_closed(active_order)
                        self.resume_automatic_trade_management()
                        return
                    self._stop_event.wait(config.poll_seconds)
                    continue
                decision = self._evaluate_dynamic_signal_decision(
                    confirmed,
                    config,
                    effective_signal_mode=effective_signal_mode,
                    price_increment=instrument.tick_size,
                )
                last_candle_ts = newest_candle_ts
                if decision.signal is None:
                    idle_signal_candle_ts = newest_candle_ts
                    self._logger(f"{_fmt_ts(newest_candle_ts)} | 当前无法生成挂单 | {decision.reason}")
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue
                if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                    raise RuntimeError("策略返回的数据不完整，无法生成挂单计划")
                plan = build_order_plan(
                    instrument=instrument,
                    config=config,
                    order_size=config.order_size if config.order_size > 0 else None,
                    signal=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
                submission = self._submit_dynamic_limit_entry_order(
                    credentials,
                    config,
                    plan=plan,
                    dynamic_stop_only=dynamic_stop_only,
                    trader_virtual_stop_loss_enabled=bool(config.trader_virtual_stop_loss),
                )
                if submission is None:
                    idle_signal_candle_ts = newest_candle_ts
                    last_candle_ts = newest_candle_ts
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue
                cl_ord_id, result, stop_loss_algo_cl_ord_id = submission
                if not result.ord_id:
                    raise RuntimeError("OKX 未返回挂单 ordId，无法继续监控该委托")
                active_order = ManagedEntryOrder(
                    ord_id=result.ord_id,
                    cl_ord_id=result.cl_ord_id or cl_ord_id,
                    candle_ts=plan.candle_ts,
                    entry_reference=plan.entry_reference,
                    stop_loss=plan.stop_loss,
                    take_profit=plan.take_profit,
                    stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                    size=plan.size,
                    side=plan.side,
                    signal=plan.signal,
                    stop_loss_algo_id=None,
                )
                idle_signal_candle_ts = None
                self._logger(
                    f"{_fmt_ts(plan.candle_ts)} | 挂单已提交到 OKX | ordId={result.ord_id or '-'} | "
                    f"sCode={result.s_code} | sMsg={result.s_msg or 'accepted'}"
                )
                self._log_entry_order_tracking(
                    plan.candle_ts,
                    cl_ord_id=active_order.cl_ord_id,
                    entry_reference=active_order.entry_reference,
                )
                self._stop_event.wait(config.poll_seconds)
                continue

            if idle_signal_candle_ts == newest_candle_ts:
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            self._stop_event.wait(config.poll_seconds)

    @staticmethod
    def _recoverable_algo_order_direction(order: OkxTradeOrderItem) -> Literal["long", "short"] | None:
        pos_side = str(order.pos_side or "").strip().lower()
        if pos_side == "long":
            return "long"
        if pos_side == "short":
            return "short"
        side = str(order.side or order.actual_side or "").strip().lower()
        if side == "sell":
            return "long"
        if side == "buy":
            return "short"
        return None

    def _find_latest_pending_stop_algo_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        signal: Literal["long", "short"],
    ) -> OkxTradeOrderItem | None:
        pending_orders = self._get_pending_orders_with_retry(
            credentials,
            config,
            inst_types=(trade_instrument.inst_type,),
            limit=200,
        )
        candidates = []
        for item in pending_orders:
            if item.source_kind != "algo":
                continue
            if item.inst_id != trade_instrument.inst_id:
                continue
            if (item.stop_loss_trigger_price or item.trigger_price) is None:
                continue
            if not ((item.algo_id or "").strip() or (item.algo_client_order_id or "").strip()):
                continue
            direction = self._recoverable_algo_order_direction(item)
            if direction is not None and direction != signal:
                continue
            candidates.append(item)
        if not candidates:
            return None
        candidates.sort(key=lambda item: item.update_time or item.created_time or 0, reverse=True)
        return candidates[0]

    def _run_cross_exchange_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        strategy = EmaAtrStrategy()
        dynamic_stop_only = _live_dynamic_take_profit_enabled(config)
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.big_ema_period,
            config.atr_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None

        self._log_strategy_start(config, instrument, instrument)
        self._logger("运行模式：同标的永续下单，止盈止损交给 OKX 托管")
        self._logger(
            "策略规则：最近一根已收盘 K 线向上突破参考 EMA 做多（须 EMA 小周期>中周期），"
            "向下跌破参考 EMA 做空（须 EMA 小周期<中周期）。"
        )
        if dynamic_stop_only:
            self._logger(
                "止盈方式=动态止盈 | 初始仅挂止损，后续按 nR 逐级在 OKX 上改价上移；"
                f"{_live_dynamic_break_even_summary(config)} | "
                f"手续费偏移={config.dynamic_fee_offset_enabled_label()} | "
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        else:
            self._logger(
                f"止盈方式=固定止盈（ATR×{format_decimal(config.atr_take_multiplier)}）| 开仓时一并挂好止盈止损"
            )
        self._logger(
            f"方向={_format_signal_mode(config.signal_mode)} | 风险金={format_decimal(config.risk_amount or Decimal('0'))}"
        )
        self._logger(f"启动追单窗口：{config.startup_chase_window_label()}")
        self._logger(f"指标回看数量：{lookback} 根 K 线")

        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            big_ema_period=config.big_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period + 2,
                config.trend_ema_period + 2,
                config.big_ema_period + 2,
                config.atr_period + 2,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = strategy.evaluate(confirmed, config, price_increment=instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                raise RuntimeError("策略返回的数据不完整，无法生成下单计划")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                plan = build_order_plan(
                    instrument=instrument,
                    config=config,
                    order_size=config.order_size,
                    signal=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前无法生成挂单 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            if startup_gate_message:
                should_skip_by_stop, stop_crossed_message = self._should_skip_startup_takeover_when_stop_crossed(
                    startup_gate,
                    config,
                    signal=decision.signal,
                    candle_ts=decision.candle_ts,
                    trigger_inst_id=plan.inst_id,
                    stop_loss=plan.stop_loss,
                )
                if should_skip_by_stop:
                    if stop_crossed_message:
                        self._logger(stop_crossed_message)
                    self._stop_event.wait(config.poll_seconds)
                    continue
            self._logger(
                f"{_fmt_ts(plan.candle_ts)} | 准备市价单 | 方向={plan.signal.upper()} | "
                f"参考入场价={format_decimal(plan.entry_reference)} | 数量={_format_size_with_contract_equivalent(instrument, plan.size)} | "
                f"止损={format_decimal(plan.stop_loss)} | "
                f"{'动态止盈=初始不挂止盈' if dynamic_stop_only else f'止盈={format_decimal(plan.take_profit)}'}"
            )
            cl_ord_id = self._next_client_order_id(role="entry")
            stop_loss_algo_cl_ord_id = self._next_client_order_id(role="slg") if dynamic_stop_only else None
            result = self._submit_order_with_recovery(
                credentials,
                config,
                inst_id=plan.inst_id,
                cl_ord_id=cl_ord_id,
                label="市价附带止盈止损下单",
                submit_fn=lambda: self._client.place_market_order(
                    credentials,
                    config,
                    plan,
                    cl_ord_id=cl_ord_id,
                    include_take_profit=not dynamic_stop_only,
                    stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                ),
            )
            self._logger(
                f"订单已提交到 OKX | ordId={result.ord_id or '-'} | "
                f"sCode={result.s_code} | sMsg={result.s_msg or 'accepted'}"
            )
            self._log_entry_order_tracking(
                plan.candle_ts,
                cl_ord_id=result.cl_ord_id or cl_ord_id,
                entry_reference=plan.entry_reference,
                price_label="参考入场价",
            )
            filled = self._wait_for_order_fill(
                credentials,
                config,
                trade_instrument=instrument,
                side=plan.side,
                pos_side=plan.pos_side,
                result=result,
                estimated_entry=plan.entry_reference,
            )
            self._logger(
                f"市价单成交 | ordId={filled.ord_id} | 标的={instrument.inst_id} | "
                f"方向={filled.side.upper()} | "
                f"成交均价={_format_notify_price_by_tick_size(filled.entry_price, instrument.tick_size)} | "
                f"成交数量={_format_size_with_contract_equivalent(instrument, filled.size)}"
            )
            fill_reason = (
                "EMA 突破/跌破市价成交：初始止损已交 OKX，后续将按动态止盈规则改价上移"
                if dynamic_stop_only
                else "EMA 突破/跌破市价信号成交，止盈止损已交给 OKX 托管"
            )
            self._notify_trade_fill(
                config,
                title="开仓成交",
                symbol=instrument.inst_id,
                side=filled.side,
                size=filled.size,
                size_text=_format_notify_size_with_unit(instrument, filled.size),
                price=filled.entry_price,
                tick_size=instrument.tick_size,
                reason=fill_reason,
            )
            if dynamic_stop_only and stop_loss_algo_cl_ord_id:
                self._logger(
                    f"初始 OKX 止损已提交 | algoClOrdId={stop_loss_algo_cl_ord_id} | "
                    f"止损={format_decimal(plan.stop_loss)} | 启动动态上移监控"
                )
                self._monitor_exchange_dynamic_stop(
                    credentials,
                    config,
                    trade_instrument=instrument,
                    position=filled,
                    initial_stop_loss=plan.stop_loss,
                    stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                )
                return
            self._logger("止盈止损已交由 OKX 托管，本次策略结束。")
            return

    def _run_cross_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        strategy = EmaAtrStrategy()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.big_ema_period,
            config.atr_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._log_local_mode_summary(config, signal_instrument, trade_instrument)
        self._logger(
            "策略规则：最近一根已收盘 K 线向上突破参考 EMA 做多（须 EMA 小周期>中周期），"
            "向下跌破参考 EMA 做空（须 EMA 小周期<中周期）；信号出现后立即对下单标的开仓。"
        )
        if _live_dynamic_take_profit_enabled(config):
            self._logger(
                "止盈方式=动态止盈 | 本地监控触发价，规则与回测动态止盈一致 | "
                f"{_live_dynamic_break_even_summary(config)} | "
                f"手续费偏移={config.dynamic_fee_offset_enabled_label()} | "
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        else:
            self._logger(
                f"止盈方式=固定止盈（ATR×{format_decimal(config.atr_take_multiplier)}）| 本地按触发价监控固定止盈止损"
            )
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            big_ema_period=config.big_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period + 2,
                config.trend_ema_period + 2,
                config.big_ema_period + 2,
                config.atr_period + 2,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = strategy.evaluate(confirmed, config, price_increment=signal_instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None:
                _reset_startup_signal_gate(startup_gate)
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.candle_ts is None:
                raise RuntimeError("策略返回的信号时间缺失，无法判断启动是否追当前信号。")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                position = self._open_local_position(
                    credentials,
                    config,
                    signal_instrument=signal_instrument,
                    trade_instrument=trade_instrument,
                    signal=decision.signal,
                    signal_entry_reference=decision.entry_reference,
                    signal_atr_value=decision.atr_value,
                    signal_candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts or newest_ts)} | 当前无法下单 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            protection = self._build_local_protection_plan(
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                signal=decision.signal,
                trade_side=position.side,
                estimated_trade_entry=position.entry_price,
                signal_entry_reference=decision.entry_reference,
                signal_atr_value=decision.atr_value,
                signal_candle_ts=decision.candle_ts,
                signal_candle_high=decision.signal_candle_high,
                signal_candle_low=decision.signal_candle_low,
            )
            self._monitor_ema55_slope_short_local_exit(
                credentials,
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                position=position,
                protection=protection,
                lookback=lookback,
            )
            return

    def _run_ema55_slope_short_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        if resolve_trade_inst_id(config) != config.inst_id:
            raise RuntimeError("均线斜率做空当前只支持信号标的与下单标的相同。")

        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        ) + 1
        last_candle_ts: int | None = None
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._log_local_mode_summary(config, signal_instrument, trade_instrument)
        line_label = config.ema_label()
        self._logger(
            f"策略规则：只做空；当最新已收盘K线的 {line_label} 单根斜率比例小于等于阈值时按收盘价开空，"
            f"持仓后继续监控 ATR 止损/止盈；若后续 {line_label} 斜率重新转正，则本地市价平仓。"
        )
        self._logger(
            " | ".join(
                [
                    f"开空阈值={Decimal(str(config.trend_ema_slope_filter_min_ratio)):.6f}",
                    f"止盈方式={'动态止盈' if config.take_profit_mode == 'dynamic' else '固定止盈'}",
                    f"首档触发R={_live_ema55_slope_lock_profit_trigger_r(config)}",
                    f"nR保本={config.dynamic_two_r_break_even_label()}",
                    f"手续费偏移={config.dynamic_fee_offset_enabled_label()}",
                    f"同K线禁重开={'开启' if config.ema55_slope_same_bar_reentry_block else '关闭'}",
                    (
                        f"时间保本={config.time_stop_break_even_enabled_label()}/"
                        f"{config.resolved_time_stop_break_even_bars()}根"
                    ),
                ]
            )
        )
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            ma_type=config.ema_type,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(config.ema_period, config.trend_ema_period, config.atr_period) + 1
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts
            self._clear_ema55_slope_same_bar_reentry_block_if_advanced(
                credentials,
                config,
                candle_ts=newest_ts,
            )
            if (
                config.ema55_slope_same_bar_reentry_block
                and newest_ts == self._get_ema55_slope_same_bar_reentry_block_ts(credentials, config)
            ):
                self._logger(f"{_fmt_ts(newest_ts)} | 本根K线刚平仓，禁止同K线再次开空")
                self._stop_event.wait(config.poll_seconds)
                continue

            decision = evaluate_ema55_slope_short_signal(
                confirmed,
                config,
                price_increment=signal_instrument.tick_size,
            )
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None:
                _reset_startup_signal_gate(startup_gate)
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无开空信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.candle_ts is None:
                raise RuntimeError("策略返回的信号时间缺失，无法判断启动是否追当前信号。")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                position = self._open_local_position(
                    credentials,
                    config,
                    signal_instrument=signal_instrument,
                    trade_instrument=trade_instrument,
                    signal=decision.signal,
                    signal_entry_reference=decision.entry_reference,
                    signal_atr_value=decision.atr_value,
                    signal_candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts or newest_ts)} | 当前无法下单 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue

            protection = self._build_local_protection_plan(
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                signal=decision.signal,
                trade_side=position.side,
                estimated_trade_entry=position.entry_price,
                signal_entry_reference=decision.entry_reference,
                signal_atr_value=decision.atr_value,
                signal_candle_ts=decision.candle_ts,
                signal_candle_high=decision.signal_candle_high,
                signal_candle_low=decision.signal_candle_low,
            )
            self._monitor_ema55_slope_short_local_exit(
                credentials,
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                position=position,
                protection=protection,
                lookback=lookback,
            )
            if not self._stop_event.is_set():
                self._logger("仓位关闭已确认 | 开仓门禁保持关闭 | 开始结算归因")
                if not self._wait_for_trade_settlement():
                    return
                self._logger("本轮持仓已结束，继续监控下一次信号。")

    def _run_body_retest_short_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        if resolve_trade_inst_id(config) != config.inst_id:
            raise RuntimeError("Body/ATR 回抽做空当前只支持信号标的与下单标的相同。")

        lookback = body_retest_short_minimum_candles(config) + max(int(config.body_retest_watch_bars), 1)
        last_candle_ts: int | None = None

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._log_local_mode_summary(config, signal_instrument, trade_instrument)
        self._logger(
            "策略规则：只做空；先等弱势破位阴线，再在限定K线内等待回抽确认做空；"
            "入场后按自定义初始止损、动态止盈、nR保本和逐级锁盈管理。"
        )
        self._logger(
            " | ".join(
                [
                    f"破位阈值={Decimal(str(config.body_retest_breakdown_atr_multiplier)):.2f}ATR",
                    f"回抽阈值={Decimal(str(config.body_retest_retest_atr_multiplier)):.2f}ATR",
                    f"止损缓冲={Decimal(str(config.body_retest_stop_buffer_atr_multiplier)):.2f}ATR",
                    f"body/ATR上限={Decimal(str(config.body_retest_body_atr_limit)):.2f}",
                    f"观察窗口={max(int(config.body_retest_watch_bars), 1)}根",
                    f"斜率阈值={Decimal(str(config.trend_ema_slope_filter_min_ratio)):.6f}",
                    f"ATR分位上限={Decimal(str(config.atr_percentile_filter_max)):.2f}",
                ]
            )
        )
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = body_retest_short_minimum_candles(config)
            if len(confirmed) < minimum:
                self._logger("已收盘K线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            direction_filter_bias = (
                self._build_live_daily_direction_filter_bias(confirmed, config)
                if config.uses_daily_filter()
                else None
            )
            decision = evaluate_body_retest_short_signal(
                confirmed,
                config,
                direction_filter_bias=direction_filter_bias,
                price_increment=signal_instrument.tick_size,
            )
            if decision.signal is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无开空信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                position = self._open_local_position(
                    credentials,
                    config,
                    signal_instrument=signal_instrument,
                    trade_instrument=trade_instrument,
                    signal=decision.signal,
                    signal_entry_reference=decision.entry_reference,
                    signal_atr_value=decision.atr_value,
                    signal_candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts or newest_ts)} | 当前无法下单 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue

            protection = self._build_local_protection_plan(
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                signal=decision.signal,
                trade_side=position.side,
                estimated_trade_entry=position.entry_price,
                signal_entry_reference=decision.entry_reference,
                signal_atr_value=decision.atr_value,
                signal_candle_ts=decision.candle_ts,
                signal_candle_high=decision.signal_candle_high,
                signal_candle_low=decision.signal_candle_low,
            )
            self._monitor_local_exit(credentials, config, trade_instrument, position, protection)
            return

    def _run_dynamic_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        if config.signal_mode == "both":
            raise RuntimeError("EMA 动态委托策略不支持双向，请选择只做多或只做空")

        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        active_trigger: LocalSignalTrigger | None = None
        idle_signal_candle_ts: int | None = None

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._log_local_mode_summary(config, signal_instrument, trade_instrument)
        self._logger(
            f"策略规则：根据上一根已收盘 K 线的 {_dynamic_entry_reference_ema_text(config)} 生成动态委托价，不再直接往 OKX 挂单，"
            f"而是在本地轮询信号标的价格，触碰 {_dynamic_entry_reference_ema_text(config)} 后立即对下单标的开仓。"
        )
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            entry_reference_ema_period=entry_reference_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if active_trigger is None and idle_signal_candle_ts == newest_ts:
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            if newest_ts != last_candle_ts or active_trigger is None:
                decision = strategy.evaluate(confirmed, config, price_increment=signal_instrument.tick_size)
                decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
                last_candle_ts = newest_ts
                if decision.signal is None:
                    active_trigger = None
                    idle_signal_candle_ts = newest_ts
                    self._logger(f"{_fmt_ts(newest_ts)} | 当前无法生成动态开仓价 | {decision.reason}")
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue
                if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                    raise RuntimeError("策略返回的数据不完整，无法生成本地触发条件")
                active_trigger = LocalSignalTrigger(
                    signal=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
                idle_signal_candle_ts = None
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 动态等待中 | 信号方向={decision.signal.upper()} | "
                    f"信号标的触发价={format_decimal(decision.entry_reference)} | "
                    f"下单标的={trade_instrument.inst_id}"
                )

            current_signal_price = self._get_trigger_price_with_retry(
                config.inst_id,
                "last",
                environment=config.environment,
            )
            if not local_entry_trigger_hit(active_trigger.signal, current_signal_price, active_trigger.entry_reference):
                self._stop_event.wait(config.poll_seconds)
                continue

            self._logger(
                f"{_fmt_ts(active_trigger.candle_ts)} | 信号标的已触发动态开仓条件 | "
                f"当前价={format_decimal(current_signal_price)} | 目标价={format_decimal(active_trigger.entry_reference)}"
            )
            try:
                position = self._open_local_position(
                    credentials,
                    config,
                    signal_instrument=signal_instrument,
                    trade_instrument=trade_instrument,
                    signal=active_trigger.signal,
                    signal_entry_reference=active_trigger.entry_reference,
                    signal_atr_value=active_trigger.atr_value,
                    signal_candle_ts=active_trigger.candle_ts,
                    signal_candle_high=active_trigger.signal_candle_high,
                    signal_candle_low=active_trigger.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(active_trigger.candle_ts)} | 当前无法下单 | {exc}")
                active_trigger = None
                idle_signal_candle_ts = newest_ts
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            protection = self._build_local_protection_plan(
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                signal=active_trigger.signal,
                trade_side=position.side,
                estimated_trade_entry=position.entry_price,
                signal_entry_reference=active_trigger.entry_reference,
                signal_atr_value=active_trigger.atr_value,
                signal_candle_ts=active_trigger.candle_ts,
                signal_candle_high=active_trigger.signal_candle_high,
                signal_candle_low=active_trigger.signal_candle_low,
            )
            self._monitor_local_exit(credentials, config, trade_instrument, position, protection)
            return

    def _run_dynamic_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        if config.signal_mode == "both":
            raise RuntimeError("EMA 动态委托策略不支持双向，请选择只做多或只做空")

        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        self._logger(
            f"运行模式：只监控信号，不下单；每根新 K 线确认后，如生成新的 {_dynamic_entry_reference_ema_text(config)} 动态委托参考价，则发送邮件通知。"
        )
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            entry_reference_ema_period=entry_reference_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = strategy.evaluate(confirmed, config, price_increment=instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无动态委托信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                raise RuntimeError("策略返回的数据不完整，无法生成信号邮件")

            try:
                protection = build_protection_plan(
                    instrument=instrument,
                    config=config,
                    direction=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    trigger_inst_id=instrument.inst_id,
                )
            except InvalidProtectionPlanError as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前信号保护价非法，已跳过 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            reason = (
                "EMA 动态委托参考价已更新"
                f" | 止损={format_decimal(protection.stop_loss)}"
                f" | 止盈={format_decimal(protection.take_profit)}"
            )
            self._logger(
                f"{_fmt_ts(decision.candle_ts)} | 信号触发 | 方向={decision.signal.upper()} | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            self._stop_event.wait(config.poll_seconds)

    def _run_dynamic_local_strategy_v2(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        effective_signal_mode = resolve_dynamic_signal_mode(config.strategy_id, config.signal_mode)
        if effective_signal_mode == "both":
            raise RuntimeError("EMA 动态委托不支持双向，请选择只做多或只做空。")

        strategy = EmaDynamicOrderStrategy()
        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        active_trigger: LocalSignalTrigger | None = None
        idle_signal_candle_ts: int | None = None
        current_wave_signal: Literal["long", "short"] | None = None
        entries_in_current_wave = 0
        current_wave_index = 0
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._log_local_mode_summary(config, signal_instrument, trade_instrument)
        self._logger(
            f"策略规则：每根新 K 线确认后，上一根动态委托自动失效，再按最新 {_dynamic_entry_reference_ema_text(config)} 重新挂下一根委托。"
        )
        mode_parts = [
            f"方向={_format_signal_mode(effective_signal_mode)}",
            f"止盈方式={'动态止盈' if config.take_profit_mode == 'dynamic' else '固定止盈'}",
            f"每波最多开仓次数={config.max_entries_per_trend or 0}",
            f"挂单参考={_dynamic_entry_reference_ema_text(config)}",
            f"启动追单窗口={config.startup_chase_window_label()}",
        ]
        if config.uses_reentry_confirmation():
            mode_parts.append(config.reentry_confirmation_summary())
        self._append_dynamic_mtf_mode_parts(config, mode_parts)
        self._append_daily_filter_mode_parts(config, mode_parts)
        if config.take_profit_mode == "dynamic":
            mode_parts.append(_live_dynamic_break_even_summary(config))
            mode_parts.append(f"手续费偏移={config.dynamic_fee_offset_enabled_label()}")
            mode_parts.append(
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        self._logger(" | ".join(mode_parts))
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            entry_reference_ema_period=entry_reference_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if active_trigger is None and idle_signal_candle_ts == newest_ts:
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            if newest_ts != last_candle_ts or active_trigger is None:
                decision = self._evaluate_dynamic_signal_decision(
                    confirmed,
                    config,
                    effective_signal_mode=effective_signal_mode,
                    price_increment=signal_instrument.tick_size,
                )
                last_candle_ts = newest_ts
                if decision.signal is None:
                    active_trigger = None
                    current_wave_signal = None
                    entries_in_current_wave = 0
                    _reset_startup_signal_gate(startup_gate)
                    idle_signal_candle_ts = newest_ts
                    self._logger(f"{_fmt_ts(newest_ts)} | 当前无法生成动态开仓价 | {decision.reason}")
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue
                if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                    raise RuntimeError("策略返回的数据不完整，无法生成本地触发条件。")

                should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                    startup_gate,
                    signal=decision.signal,
                    candle_ts=decision.candle_ts,
                    bar=config.bar,
                )
                if startup_gate_message:
                    self._logger(startup_gate_message)
                if should_skip_startup_signal:
                    active_trigger = None
                    idle_signal_candle_ts = newest_ts
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue

                if current_wave_signal != decision.signal:
                    current_wave_signal = decision.signal
                    entries_in_current_wave = 0
                    current_wave_index += 1
                    self._logger(
                        f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势开始 | 方向={decision.signal.upper()}"
                    )

                if config.max_entries_per_trend > 0 and entries_in_current_wave >= config.max_entries_per_trend:
                    active_trigger = None
                    idle_signal_candle_ts = newest_ts
                    self._logger(
                        f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势开仓次数已达上限 | 方向={decision.signal.upper()} | "
                        f"上限={config.max_entries_per_trend}"
                    )
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue
                next_wave_entry_sequence = entries_in_current_wave + 1
                reentry_block_reason = _dynamic_reentry_confirmation_block_reason(
                    config,
                    confirmed,
                    signal=decision.signal,
                    wave_entry_sequence=next_wave_entry_sequence,
                )
                if reentry_block_reason:
                    active_trigger = None
                    idle_signal_candle_ts = newest_ts
                    self._logger(f"{_fmt_ts(decision.candle_ts)} | {reentry_block_reason}")
                    self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                    continue

                active_trigger = LocalSignalTrigger(
                    signal=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
                idle_signal_candle_ts = None
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 动态等待中 | 信号方向={decision.signal.upper()} | "
                    f"第{current_wave_index}波 | 本波第{entries_in_current_wave + 1}次委托 | 触发价={format_decimal(decision.entry_reference)} | "
                    f"下单标的={trade_instrument.inst_id}"
                )

            if active_trigger is None:
                self._stop_event.wait(config.poll_seconds)
                continue

            current_signal_price = self._get_trigger_price_with_retry(
                config.inst_id,
                "last",
                environment=config.environment,
            )
            if not local_entry_trigger_hit(active_trigger.signal, current_signal_price, active_trigger.entry_reference):
                self._stop_event.wait(config.poll_seconds)
                continue

            self._logger(
                f"{_fmt_ts(active_trigger.candle_ts)} | 信号标的已触发动态开仓条件 | 当前价={format_decimal(current_signal_price)} | "
                f"目标价={format_decimal(active_trigger.entry_reference)}"
            )
            try:
                position = self._open_local_position(
                    credentials,
                    config,
                    signal_instrument=signal_instrument,
                    trade_instrument=trade_instrument,
                    signal=active_trigger.signal,
                    signal_entry_reference=active_trigger.entry_reference,
                    signal_atr_value=active_trigger.atr_value,
                    signal_candle_ts=active_trigger.candle_ts,
                    signal_candle_high=active_trigger.signal_candle_high,
                    signal_candle_low=active_trigger.signal_candle_low,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(active_trigger.candle_ts)} | ?????? | {exc}")
                active_trigger = None
                idle_signal_candle_ts = newest_ts
                self._stop_event.wait(_idle_signal_wait_seconds(config.bar, config.poll_seconds))
                continue
            protection = self._build_local_protection_plan(
                config,
                signal_instrument=signal_instrument,
                trade_instrument=trade_instrument,
                signal=active_trigger.signal,
                trade_side=position.side,
                estimated_trade_entry=position.entry_price,
                signal_entry_reference=active_trigger.entry_reference,
                signal_atr_value=active_trigger.atr_value,
                signal_candle_ts=active_trigger.candle_ts,
                signal_candle_high=active_trigger.signal_candle_high,
                signal_candle_low=active_trigger.signal_candle_low,
            )
            entries_in_current_wave += 1
            active_trigger = None
            self._monitor_local_exit_v2(credentials, config, trade_instrument, position, protection)
            if not self._stop_event.is_set():
                idle_signal_candle_ts = newest_ts
                self._logger("仓位关闭已确认 | 开仓门禁保持关闭 | 开始结算归因")
                if not self._wait_for_trade_settlement():
                    return
                self._logger("本轮持仓已结束，继续监控下一次信号。")

    def _run_dynamic_signal_only_v2(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        effective_signal_mode = resolve_dynamic_signal_mode(config.strategy_id, config.signal_mode)
        if effective_signal_mode == "both":
            raise RuntimeError("EMA 动态委托不支持双向，请选择只做多或只做空。")

        strategy = EmaDynamicOrderStrategy()
        entry_reference_ema_period = config.resolved_entry_reference_ema_period()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            entry_reference_ema_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None
        current_wave_signal: Literal["long", "short"] | None = None
        entries_in_current_wave = 0
        current_wave_index = 0
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        mode_parts = [
            "运行模式：只监控信号，不下单",
            f"方向={_format_signal_mode(effective_signal_mode)}",
            f"止盈方式={'动态止盈' if config.take_profit_mode == 'dynamic' else '固定止盈'}",
            f"每波最多开仓次数={config.max_entries_per_trend or 0}",
            f"挂单参考={_dynamic_entry_reference_ema_text(config)}",
            f"启动追单窗口={config.startup_chase_window_label()}",
        ]
        self._append_dynamic_mtf_mode_parts(config, mode_parts)
        self._append_daily_filter_mode_parts(config, mode_parts)
        if config.take_profit_mode == "dynamic":
            mode_parts.append(_live_dynamic_break_even_summary(config))
            mode_parts.append(f"手续费偏移={config.dynamic_fee_offset_enabled_label()}")
            mode_parts.append(
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        self._logger(" | ".join(mode_parts))
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            entry_reference_ema_period=entry_reference_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period,
                config.trend_ema_period,
                config.atr_period,
                entry_reference_ema_period,
                config.resolved_reentry_confirmation_ma_period() if config.uses_reentry_confirmation() else 0,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = self._evaluate_dynamic_signal_decision(
                confirmed,
                config,
                effective_signal_mode=effective_signal_mode,
                price_increment=instrument.tick_size,
            )
            if decision.signal is None:
                current_wave_signal = None
                entries_in_current_wave = 0
                _reset_startup_signal_gate(startup_gate)
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无动态委托信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                raise RuntimeError("策略返回的数据不完整，无法生成信号提醒。")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            if current_wave_signal != decision.signal:
                current_wave_signal = decision.signal
                entries_in_current_wave = 0
                current_wave_index += 1
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势开始 | 方向={decision.signal.upper()}"
                )

            if config.max_entries_per_trend > 0 and entries_in_current_wave >= config.max_entries_per_trend:
                self._logger(
                    f"{_fmt_ts(decision.candle_ts)} | 第{current_wave_index}波趋势信号次数已达上限 | 方向={decision.signal.upper()} | "
                    f"上限={config.max_entries_per_trend}"
                )
                self._stop_event.wait(config.poll_seconds)
                continue
            next_wave_entry_sequence = entries_in_current_wave + 1
            reentry_block_reason = _dynamic_reentry_confirmation_block_reason(
                config,
                confirmed,
                signal=decision.signal,
                wave_entry_sequence=next_wave_entry_sequence,
            )
            if reentry_block_reason:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | {reentry_block_reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                protection = build_protection_plan(
                    instrument=instrument,
                    config=config,
                    direction=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    trigger_inst_id=instrument.inst_id,
                )
            except InvalidProtectionPlanError as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前信号保护价非法，已跳过 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            if config.take_profit_mode == "dynamic":
                reason = f"EMA 动态委托参考价已更新 | 止损={format_decimal(protection.stop_loss)} | 止盈方式=动态止盈"
            else:
                reason = (
                    f"EMA 动态委托参考价已更新 | 止损={format_decimal(protection.stop_loss)} | "
                    f"止盈={format_decimal(protection.take_profit)}"
                )
            self._logger(
                f"{_fmt_ts(decision.candle_ts)} | 信号触发 | 方向={decision.signal.upper()} | "
                f"第{current_wave_index}波 | 本波第{entries_in_current_wave + 1}次信号 | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            entries_in_current_wave += 1
            self._stop_event.wait(config.poll_seconds)

    def _run_cross_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        strategy = EmaAtrStrategy()
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.big_ema_period,
            config.atr_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        last_candle_ts: int | None = None

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        self._logger("运行模式：只监控信号，不下单；当 EMA 突破/跌破信号出现时发送邮件通知。")
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
            big_ema_period=config.big_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(
                config.ema_period + 2,
                config.trend_ema_period + 2,
                config.big_ema_period + 2,
                config.atr_period + 2,
            )
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = strategy.evaluate(confirmed, config, price_increment=instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None:
                _reset_startup_signal_gate(startup_gate)
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            if decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                raise RuntimeError("策略返回的数据不完整，无法生成信号邮件")

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                protection = build_protection_plan(
                    instrument=instrument,
                    config=config,
                    direction=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    trigger_inst_id=instrument.inst_id,
                    use_signal_extrema=True,
                    signal_candle_high=decision.signal_candle_high,
                    signal_candle_low=decision.signal_candle_low,
                )
            except InvalidProtectionPlanError as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前信号保护价非法，已跳过 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            reason = (
                "EMA 突破/跌破信号已确认"
                f" | 止损={format_decimal(protection.stop_loss)}"
                f" | 止盈={format_decimal(protection.take_profit)}"
            )
            self._logger(
                f"{_fmt_ts(decision.candle_ts)} | 信号触发 | 方向={decision.signal.upper()} | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            self._stop_event.wait(config.poll_seconds)

    def _run_ema55_slope_short_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            DEFAULT_DEBUG_ATR_PERIOD,
        ) + 1
        last_candle_ts: int | None = None
        startup_gate = StartupSignalGateState(
            started_at_ms=int(time.time() * 1000),
            chase_window_seconds=config.resolved_startup_chase_window_seconds(),
            chase_current_signal=config.startup_chase_current_signal,
        )

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        line_label = config.ema_label()
        self._logger(f"运行模式：只监控信号，不下单；当 {line_label} 单根斜率比例达到开空阈值时发送做空提示。")
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(config.ema_period, config.trend_ema_period, config.atr_period) + 1
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = evaluate_ema55_slope_short_signal(
                confirmed,
                config,
                price_increment=instrument.tick_size,
            )
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None or decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                _reset_startup_signal_gate(startup_gate)
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无开空信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            should_skip_startup_signal, startup_gate_message = _should_skip_startup_signal(
                startup_gate,
                signal=decision.signal,
                candle_ts=decision.candle_ts,
                bar=config.bar,
            )
            if startup_gate_message:
                self._logger(startup_gate_message)
            if should_skip_startup_signal:
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                protection = build_protection_plan(
                    instrument=instrument,
                    config=config,
                    direction=decision.signal,
                    entry_reference=decision.entry_reference,
                    atr_value=decision.atr_value,
                    candle_ts=decision.candle_ts,
                    trigger_inst_id=instrument.inst_id,
                )
            except InvalidProtectionPlanError as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts)} | 当前信号保护价非法，已跳过 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            if config.take_profit_mode == "dynamic":
                reason = (
                    f"{decision.reason} | 止损={format_decimal(protection.stop_loss)} | "
                    "止盈方式=动态止盈（按 nR 逐级抬止损）"
                )
            else:
                reason = (
                    f"{decision.reason} | 止损={format_decimal(protection.stop_loss)} | "
                    f"止盈={format_decimal(protection.take_profit)}"
                )
            self._logger(
                f"{_fmt_ts(decision.candle_ts)} | 信号触发 | 方向=SHORT | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            self._stop_event.wait(config.poll_seconds)

    def _run_body_retest_short_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        lookback = body_retest_short_minimum_candles(config) + max(int(config.body_retest_watch_bars), 1)
        last_candle_ts: int | None = None

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        self._logger("运行模式：只监控信号，不下单；当 body/ATR 破位回抽空头条件成立时发送做空提示。")
        self._log_hourly_debug(
            config.inst_id,
            config.ema_period,
            current_bar=config.bar,
            trend_ema_period=config.trend_ema_period,
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = body_retest_short_minimum_candles(config)
            if len(confirmed) < minimum:
                self._logger("已收盘K线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            direction_filter_bias = (
                self._build_live_daily_direction_filter_bias(confirmed, config)
                if config.uses_daily_filter()
                else None
            )
            decision = evaluate_body_retest_short_signal(
                confirmed,
                config,
                direction_filter_bias=direction_filter_bias,
                price_increment=instrument.tick_size,
            )
            if decision.signal is None or decision.entry_reference is None or decision.atr_value is None or decision.candle_ts is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无开空信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            protection = build_body_retest_short_protection_plan(
                instrument=instrument,
                config=config,
                entry_reference=decision.entry_reference,
                signal_candle_high=decision.signal_candle_high or decision.entry_reference,
                signal_candle_close=decision.entry_reference,
                atr_value=decision.atr_value,
                candle_ts=decision.candle_ts,
                trigger_inst_id=instrument.inst_id,
            )
            if config.take_profit_mode == "dynamic":
                reason = (
                    f"{decision.reason} | 止损={format_decimal(protection.stop_loss)} | "
                    "止盈方式=动态止盈（按 nR 逐级抬止损）"
                )
            else:
                reason = (
                    f"{decision.reason} | 止损={format_decimal(protection.stop_loss)} | "
                    f"止盈={format_decimal(protection.take_profit)}"
                )
            self._logger(
                f"{_fmt_ts(decision.candle_ts)} | 信号触发 | 方向=SHORT | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            self._stop_event.wait(config.poll_seconds)

    def _run_btc_ema15_ma50_pullback_long_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID} 当前仅开放研究/回测，不支持信号监控模式。"
        )

    def _run_btc_ema15_ma50_pullback_long_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_EMA15_MA50_PULLBACK_LONG_ID} 当前仅开放研究/回测，不支持本地交易模式。"
        )

    def _run_btc_ema15_ma50_pullback_short_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID} 当前仅开放研究/回测，不支持信号监控模式。"
        )

    def _run_btc_ema15_ma50_pullback_short_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_EMA15_MA50_PULLBACK_SHORT_ID} 当前仅开放研究/回测，不支持本地交易模式。"
        )

    def _run_btc_daily_4h_long_short_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID} 当前仅开放研究/回测，不支持信号监控模式。"
        )

    def _run_btc_daily_4h_long_short_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        raise RuntimeError(
            f"{STRATEGY_BTC_DAILY_4H_LONG_SHORT_ID} 当前仅开放研究/回测，不支持本地交易模式。"
        )

    def _run_ema5_ema8_signal_only(
        self,
        config: StrategyConfig,
        instrument: Instrument,
    ) -> None:
        strategy = EmaCrossEmaStopStrategy()
        lookback = recommended_indicator_lookback(config.ema_period, config.trend_ema_period)
        last_candle_ts: int | None = None

        self._logger(f"启动信号监控 | 策略={self._strategy_name} | 标的={instrument.inst_id} | K线周期={config.bar}")
        self._logger(
            f"运行模式：只监控信号，不下单，EMA{config.ema_period}/EMA{config.trend_ema_period} "
            "出现金叉死叉时发送邮件通知。"
        )

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(config.ema_period, config.trend_ema_period) + 1
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            decision = strategy.evaluate(confirmed, config, price_increment=instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None or decision.entry_reference is None or decision.ema_value is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无 EMA5/EMA8 交叉信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            reason = (
                f"EMA{config.ema_period}/EMA{config.trend_ema_period} 交叉信号 | "
                f"EMA{config.trend_ema_period}={format_decimal(decision.ema_value)}"
            )
            self._logger(
                f"{_fmt_ts(decision.candle_ts or newest_ts)} | 信号触发 | 方向={decision.signal.upper()} | "
                f"参考价={format_decimal(decision.entry_reference)} | {reason}"
            )
            self._notify_signal(
                config,
                signal=decision.signal,
                trigger_symbol=instrument.inst_id,
                entry_reference=decision.entry_reference,
                tick_size=instrument.tick_size,
                reason=reason,
            )
            self._stop_event.wait(config.poll_seconds)

    def _run_ema5_ema8_local_strategy(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        if resolve_trade_inst_id(config) != config.inst_id:
            raise RuntimeError("4H EMA5/EMA8 策略目前只支持信号标的与下单标的相同")

        strategy = EmaCrossEmaStopStrategy()
        lookback = recommended_indicator_lookback(config.ema_period, config.trend_ema_period)
        last_candle_ts: int | None = None
        active_position: FilledPosition | None = None
        active_signal: Literal["long", "short"] | None = None

        self._log_strategy_start(config, signal_instrument, trade_instrument)
        self._logger(
            f"运行模式：4H EMA{config.ema_period}/EMA{config.trend_ema_period} 交叉开仓 + EMA{config.trend_ema_period} 动态止损 "
            f"| 信号标的={signal_instrument.inst_id}"
        )
        self._logger(f"风险金={format_decimal(config.risk_amount or Decimal('100'))} | 信号方向={config.signal_mode}")

        while not self._stop_event.is_set():
            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            minimum = max(config.ema_period, config.trend_ema_period) + 1
            if len(confirmed) < minimum:
                self._logger("已收盘 K 线数量不足，继续等待更多数据...")
                self._stop_event.wait(config.poll_seconds)
                continue

            newest_ts = confirmed[-1].ts
            if newest_ts == last_candle_ts:
                self._stop_event.wait(config.poll_seconds)
                continue
            last_candle_ts = newest_ts

            current_candle, current_stop_line = strategy.latest_stop_line(confirmed, config)

            if active_position is not None and active_signal is not None:
                stop_hit, stop_candle, stop_line = strategy.stop_triggered(confirmed, config, active_signal)
                self._logger(
                    f"{_fmt_ts(stop_candle.ts)} | 持仓监控 | 方向={active_signal.upper()} | "
                    f"当前收盘价={format_decimal(stop_candle.close)} | EMA{config.trend_ema_period}={format_decimal(stop_line)}"
                )
                if stop_hit:
                    self._logger(
                        f"{_fmt_ts(stop_candle.ts)} | EMA{config.trend_ema_period} 动态止损触发 | "
                        f"当前收盘价={format_decimal(stop_candle.close)} | 动态止损线={format_decimal(stop_line)}"
                    )
                    self._close_position(credentials, config, trade_instrument, active_position, "止损")
                    active_position = None
                    active_signal = None
                self._stop_event.wait(config.poll_seconds)
                continue

            decision = strategy.evaluate(confirmed, config, price_increment=signal_instrument.tick_size)
            decision = self._apply_live_daily_filter_to_decision(confirmed, config, decision)
            if decision.signal is None or decision.entry_reference is None or decision.ema_value is None:
                self._logger(f"{_fmt_ts(newest_ts)} | 当前无 EMA5/EMA8 开仓信号 | {decision.reason}")
                self._stop_event.wait(config.poll_seconds)
                continue

            try:
                active_position = self._open_ema_stop_position(
                    credentials,
                    config,
                    trade_instrument=trade_instrument,
                    signal=decision.signal,
                    stop_loss=current_stop_line,
                    signal_candle_ts=decision.candle_ts or newest_ts,
                )
            except (OrderSizeTooSmallError, InvalidProtectionPlanError) as exc:
                self._logger(f"{_fmt_ts(decision.candle_ts or newest_ts)} | 当前无法下单 | {exc}")
                self._stop_event.wait(config.poll_seconds)
                continue
            active_signal = decision.signal
            self._logger(
                f"{_fmt_ts(decision.candle_ts or newest_ts)} | 动态 EMA 止损策略已开仓 | "
                f"方向={decision.signal.upper()} | EMA{config.trend_ema_period} 止损线={format_decimal(current_stop_line)}"
            )
            self._stop_event.wait(config.poll_seconds)

    def _open_ema_stop_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        signal: Literal["long", "short"],
        stop_loss: Decimal,
        signal_candle_ts: int,
    ) -> FilledPosition:
        trade_side: Literal["buy", "sell"] = "buy" if signal == "long" else "sell"
        pos_side = resolve_open_pos_side(config, trade_side)
        price_for_size = self._estimate_trade_entry_price_with_retry(trade_instrument, trade_side)
        stop_price = snap_to_increment(stop_loss, trade_instrument.tick_size, "nearest")
        size = determine_order_size(
            instrument=trade_instrument,
            config=config,
            entry_price=price_for_size,
            stop_loss=stop_price,
            risk_price_compatible=True,
        )
        self._logger(
            f"{_fmt_ts(signal_candle_ts)} | 准备下单 | 方向={signal.upper()} | "
            f"预估入场价={format_decimal(price_for_size)} | EMA止损线={format_decimal(stop_price)} | "
            f"下单数量={_format_size_with_contract_equivalent(trade_instrument, size)}"
        )
        result = self._place_entry_order(credentials, config, trade_instrument, trade_side, size, pos_side)
        filled = self._wait_for_order_fill(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=trade_side,
            pos_side=pos_side,
            result=result,
            estimated_entry=price_for_size,
        )
        self._logger(
            f"EMA 交叉开仓已成交 | ordId={filled.ord_id} | 标的={trade_instrument.inst_id} | "
            f"方向={trade_side.upper()} | "
            f"成交均价={_format_notify_price_by_tick_size(filled.entry_price, trade_instrument.tick_size)} | "
            f"成交数量={_format_size_with_contract_equivalent(trade_instrument, filled.size)}"
        )
        self._notify_trade_fill(
            config,
            title="开仓成交",
            symbol=trade_instrument.inst_id,
            side=trade_side,
            size=filled.size,
            size_text=_format_notify_size_with_unit(trade_instrument, filled.size),
            price=filled.entry_price,
            tick_size=trade_instrument.tick_size,
            reason=f"EMA{config.ema_period}/EMA{config.trend_ema_period} 交叉信号成交",
        )
        self._logger(f"委托追踪 | clOrdId={filled.cl_ord_id or '-'} | ordId={filled.ord_id}")
        return filled

    def _open_local_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
        signal: Literal["long", "short"],
        signal_entry_reference: Decimal | None,
        signal_atr_value: Decimal | None,
        signal_candle_ts: int | None,
        signal_candle_high: Decimal | None,
        signal_candle_low: Decimal | None,
    ) -> FilledPosition:
        trade_side = resolve_entry_side(signal, config.entry_side_mode)
        pos_side = resolve_open_pos_side(config, trade_side)
        price_for_size = self._estimate_trade_entry_price_with_retry(trade_instrument, trade_side)

        protection = self._build_local_protection_plan(
            config,
            signal_instrument=signal_instrument,
            trade_instrument=trade_instrument,
            signal=signal,
            trade_side=trade_side,
            estimated_trade_entry=price_for_size,
            signal_entry_reference=signal_entry_reference,
            signal_atr_value=signal_atr_value,
            signal_candle_ts=signal_candle_ts,
            signal_candle_high=signal_candle_high,
            signal_candle_low=signal_candle_low,
        )
        size = determine_order_size(
            instrument=trade_instrument,
            config=config,
            entry_price=price_for_size,
            stop_loss=protection.stop_loss,
            risk_price_compatible=protection.trigger_inst_id == trade_instrument.inst_id,
        )
        self._logger(
            f"{_fmt_ts(signal_candle_ts or int(datetime.now().timestamp() * 1000))} | 准备本地下单 | "
            f"信号方向={signal.upper()} | 实际下单方向={trade_side.upper()} | 下单标的={trade_instrument.inst_id} | "
            f"预估入场价={format_decimal(price_for_size)} | 数量={_format_size_with_contract_equivalent(trade_instrument, size)}"
        )

        result = self._place_entry_order(credentials, config, trade_instrument, trade_side, size, pos_side)
        filled = self._wait_for_order_fill(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=trade_side,
            pos_side=pos_side,
            result=result,
            estimated_entry=price_for_size,
        )
        self._logger(
            f"本地下单成交 | ordId={filled.ord_id} | 标的={trade_instrument.inst_id} | "
            f"方向={trade_side.upper()} | "
            f"成交均价={_format_notify_price_by_tick_size(filled.entry_price, trade_instrument.tick_size)} | "
            f"成交数量={_format_size_with_contract_equivalent(trade_instrument, filled.size)}"
        )
        self._notify_trade_fill(
            config,
            title="开仓成交",
            symbol=trade_instrument.inst_id,
            side=trade_side,
            size=filled.size,
            size_text=_format_notify_size_with_unit(trade_instrument, filled.size),
            price=filled.entry_price,
            tick_size=trade_instrument.tick_size,
            reason="本地下单成交",
        )
        self._logger(f"委托追踪 | clOrdId={filled.cl_ord_id or '-'} | ordId={filled.ord_id}")
        return filled

    def _build_local_protection_plan(
        self,
        config: StrategyConfig,
        *,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
        signal: Literal["long", "short"],
        trade_side: Literal["buy", "sell"],
        estimated_trade_entry: Decimal,
        signal_entry_reference: Decimal | None,
        signal_atr_value: Decimal | None,
        signal_candle_ts: int | None,
        signal_candle_high: Decimal | None,
        signal_candle_low: Decimal | None,
    ) -> ProtectionPlan:
        mode = config.tp_sl_mode
        if config.strategy_id == STRATEGY_BODY_RETEST_SHORT_ID:
            if signal_entry_reference is None or signal_atr_value is None or signal_candle_ts is None or signal_candle_high is None:
                raise RuntimeError("Body/ATR 回抽做空缺少信号K线高点、ATR或入场参考价，无法计算保护价。")
            if mode == "local_signal":
                return build_body_retest_short_protection_plan(
                    instrument=signal_instrument,
                    config=config,
                    entry_reference=signal_entry_reference,
                    signal_candle_high=signal_candle_high,
                    signal_candle_close=signal_entry_reference,
                    atr_value=signal_atr_value,
                    candle_ts=signal_candle_ts,
                    trigger_inst_id=signal_instrument.inst_id,
                )
            if mode in {"exchange", "local_trade"}:
                return build_body_retest_short_protection_plan(
                    instrument=trade_instrument,
                    config=config,
                    entry_reference=estimated_trade_entry,
                    signal_candle_high=signal_candle_high,
                    signal_candle_close=signal_entry_reference,
                    atr_value=signal_atr_value,
                    candle_ts=signal_candle_ts,
                    trigger_inst_id=trade_instrument.inst_id,
                )
        if mode == "local_signal":
            if signal_entry_reference is None or signal_atr_value is None or signal_candle_ts is None:
                raise RuntimeError("信号标的止盈止损缺少入场参考价或 ATR 数据")
            return build_protection_plan(
                instrument=signal_instrument,
                config=config,
                direction=signal,
                entry_reference=signal_entry_reference,
                atr_value=signal_atr_value,
                candle_ts=signal_candle_ts,
                trigger_inst_id=signal_instrument.inst_id,
                use_signal_extrema=strategy_uses_signal_extrema(config.strategy_id),
                signal_candle_high=signal_candle_high,
                signal_candle_low=signal_candle_low,
            )

        if mode in {"exchange", "local_trade"}:
            snapshot = self._fetch_atr_snapshot_with_retry(trade_instrument.inst_id, config.bar, config.atr_period)
            trade_direction: Literal["long", "short"] = "long" if trade_side == "buy" else "short"
            return build_protection_plan(
                instrument=trade_instrument,
                config=config,
                direction=trade_direction,
                entry_reference=estimated_trade_entry,
                atr_value=snapshot.atr_value,
                candle_ts=snapshot.candle_ts,
                trigger_inst_id=trade_instrument.inst_id,
            )

        if mode == "local_custom":
            trigger_inst_id = (config.local_tp_sl_inst_id or "").strip().upper()
            if not trigger_inst_id:
                raise RuntimeError("已选择自定义本地止盈止损，但没有填写触发标的")
            custom_instrument = self._get_instrument_with_retry(trigger_inst_id)
            snapshot = self._fetch_atr_snapshot_with_retry(custom_instrument.inst_id, config.bar, config.atr_period)
            return build_protection_plan(
                instrument=custom_instrument,
                config=config,
                direction=signal,
                entry_reference=snapshot.candle_close,
                atr_value=snapshot.atr_value,
                candle_ts=snapshot.candle_ts,
                trigger_inst_id=custom_instrument.inst_id,
            )

        raise RuntimeError("本地止盈止损模式错误")

    def _poll_trend_ema_close_exit_snapshot(
        self,
        config: StrategyConfig,
        *,
        signal_inst_id: str,
        direction: Literal["long", "short"],
        last_checked_candle_ts: int | None,
    ) -> tuple[bool, int | None, object | None, Decimal | None]:
        lookback = recommended_indicator_lookback(
            config.ema_period,
            config.trend_ema_period,
            config.atr_period,
            config.resolved_entry_reference_ema_period(),
            DEFAULT_DEBUG_ATR_PERIOD,
        )
        candles = self._get_candles_with_retry(signal_inst_id, config.bar, limit=lookback)
        confirmed = [candle for candle in candles if candle.confirmed]
        if not confirmed:
            return False, last_checked_candle_ts, None, None
        newest = confirmed[-1]
        if newest.ts == last_checked_candle_ts:
            return False, last_checked_candle_ts, None, None
        trend_ema_values = moving_average(
            [candle.close for candle in confirmed],
            config.trend_ema_period,
            config.resolved_trend_ema_type(),
        )
        trend_ema_value = trend_ema_values[-1] if trend_ema_values else None
        if trend_ema_value is None:
            return False, newest.ts, newest, None
        if direction == "long":
            exit_ready = newest.close <= trend_ema_value
        else:
            exit_ready = newest.close >= trend_ema_value
        return exit_ready, newest.ts, newest, trend_ema_value

    def _monitor_local_exit(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        trade_instrument: Instrument,
        position: FilledPosition,
        protection: ProtectionPlan,
    ) -> None:
        uses_flat_exit = is_btc_ema55_slope_short_strategy(config.strategy_id)
        dynamic_take_profit_enabled = _live_ema55_slope_lock_profit_enabled(config)
        dynamic_two_r_break_even = _live_ema55_slope_dynamic_two_r_break_even_enabled(config)
        dynamic_fee_offset_enabled = _live_ema55_slope_dynamic_fee_offset_enabled(config)
        current_stop_loss = protection.stop_loss
        current_take_profit = protection.take_profit
        next_trigger_r = _live_ema55_slope_lock_profit_trigger_r(config)
        risk_per_unit = abs(position.entry_price - protection.stop_loss)
        trend_ema_close_exit_enabled = (
            protection.direction == "long"
            and dynamic_take_profit_enabled
            and _live_trend_ema_close_exit_after_trigger_r_enabled(config)
        )
        trend_ema_close_exit_trigger_r = _live_trend_ema_close_exit_trigger_r(config)
        trend_ema_close_exit_armed = False
        trend_ema_close_exit_last_candle_ts: int | None = None
        signal_inst_id = (config.inst_id or trade_instrument.inst_id).strip().upper() or trade_instrument.inst_id
        monitor_parts = [
            f"开始本地止盈止损监控 | 触发标的={protection.trigger_inst_id}",
            f"触发价格类型={protection.trigger_price_type}",
            f"止损={format_decimal(protection.stop_loss)}",
            f"止盈={format_decimal(protection.take_profit)}",
        ]
        if dynamic_take_profit_enabled:
            monitor_parts.append(f"首档触发R={next_trigger_r}")
            monitor_parts.append(f"nR保本={'开启' if dynamic_two_r_break_even else '关闭'}")
            monitor_parts.append(f"手续费偏移={'开启' if dynamic_fee_offset_enabled else '关闭'}")
            monitor_parts.append(
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        self._logger(" | ".join(monitor_parts))
        while not self._stop_event.is_set():
            current_price = self._get_trigger_price_with_retry(
                protection.trigger_inst_id,
                protection.trigger_price_type,
                environment=config.environment,
            )
            self._emit_runtime_heartbeat("本地止盈止损")
            manual_control = self.get_manual_trade_control()
            manual_mode = manual_control.management_mode == "manual"
            if manual_mode and manual_control.stop_loss is not None:
                current_stop_loss = manual_control.stop_loss
            if dynamic_take_profit_enabled and manual_mode:
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            elif dynamic_take_profit_enabled:
                holding_bars = _holding_bars_live(position.entry_ts, int(time.time() * 1000), config.bar)
                updated_stop_loss, updated_take_profit, updated_trigger_r, moved = _advance_dynamic_stop_live(
                    direction=protection.direction,
                    current_price=current_price,
                    entry_price=position.entry_price,
                    risk_per_unit=risk_per_unit,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    tick_size=trade_instrument.tick_size,
                    two_r_break_even=dynamic_two_r_break_even,
                    break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
                    trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
                    first_lock_r=_live_dynamic_first_lock_r(config),
                    trailing_step_r=_live_dynamic_trailing_step_r(config),
                    separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
                    dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                    dynamic_protection_rules=_live_dynamic_protection_rules(config),
                    holding_bars=holding_bars,
                    time_stop_break_even_enabled=config.time_stop_break_even_enabled,
                    time_stop_break_even_bars=config.resolved_time_stop_break_even_bars(),
                )
                if moved:
                    current_stop_loss = updated_stop_loss
                    current_take_profit = updated_take_profit
                    next_trigger_r = updated_trigger_r
                    self._logger(
                        f"动态止盈上移 | 当前价={format_decimal(current_price)} | "
                        f"新止损={format_decimal(current_stop_loss)} | 下一阶段={next_trigger_r}R | "
                        f"holding_bars={holding_bars}"
                    )
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            elif uses_flat_exit:
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            else:
                stop_hit, take_hit = evaluate_local_exit(
                    direction=protection.direction,
                    current_price=current_price,
                    stop_loss=current_stop_loss,
                    take_profit=current_take_profit,
                )
            if trend_ema_close_exit_enabled:
                trend_ema_close_exit_armed = trend_ema_close_exit_armed or _live_dynamic_trigger_r_reached(
                    direction=protection.direction,
                    current_price=current_price,
                    entry_price=position.entry_price,
                    risk_per_unit=risk_per_unit,
                    next_trigger_r=next_trigger_r,
                    trigger_r=trend_ema_close_exit_trigger_r,
                    tick_size=trade_instrument.tick_size,
                    dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                )
            if stop_hit or take_hit:
                reason = "止盈"
                if stop_hit:
                    reason = (
                        _classify_live_dynamic_close_reason(
                            direction=protection.direction,
                            entry_price=position.entry_price,
                            initial_stop_loss=protection.stop_loss,
                            current_stop_loss=current_stop_loss,
                            risk_per_unit=risk_per_unit,
                            next_trigger_r=next_trigger_r,
                            tick_size=trade_instrument.tick_size,
                            two_r_break_even=dynamic_two_r_break_even,
                            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                            time_stop_break_even_enabled=config.time_stop_break_even_enabled,
                            break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
                            trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
                            first_lock_r=_live_dynamic_first_lock_r(config),
                            trailing_step_r=_live_dynamic_trailing_step_r(config),
                            separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
                            dynamic_protection_rules=_live_dynamic_protection_rules(config),
                        )
                        if dynamic_take_profit_enabled
                        else "止损"
                    )
                self._logger(
                    f"本地{reason}触发 | 触发标的={protection.trigger_inst_id} | "
                    f"当前价={format_decimal(current_price)} | "
                    f"止损={format_decimal(current_stop_loss)} | 止盈={format_decimal(current_take_profit)}"
                )
                self._close_position(credentials, config, trade_instrument, position, reason)
                self.resume_automatic_trade_management()
                return
            if trend_ema_close_exit_enabled and trend_ema_close_exit_armed:
                exit_ready, trend_ema_close_exit_last_candle_ts, exit_candle, trend_ema_value = (
                    self._poll_trend_ema_close_exit_snapshot(
                        config,
                        signal_inst_id=signal_inst_id,
                        direction=protection.direction,
                        last_checked_candle_ts=trend_ema_close_exit_last_candle_ts,
                    )
                )
                if exit_ready and exit_candle is not None and trend_ema_value is not None:
                    trend_label = config.trend_ema_label()
                    self._logger(
                        f"{_fmt_ts(exit_candle.ts)} | 达到 {trend_ema_close_exit_trigger_r}R 后收盘跌破 {trend_label} 平仓 | "
                        f"收盘={format_decimal(exit_candle.close)} | {trend_label}={format_decimal(trend_ema_value)}"
                    )
                    self._close_position(credentials, config, trade_instrument, position, f"跌破{trend_label}")
                    self.resume_automatic_trade_management()
                    return
            self._stop_event.wait(config.poll_seconds)

    def _monitor_ema55_slope_short_local_exit(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
        position: FilledPosition,
        protection: ProtectionPlan,
        lookback: int,
    ) -> None:
        uses_flat_exit = is_btc_ema55_slope_short_strategy(config.strategy_id)
        dynamic_take_profit_enabled = _live_ema55_slope_lock_profit_enabled(config)
        dynamic_two_r_break_even = _live_ema55_slope_dynamic_two_r_break_even_enabled(config)
        dynamic_fee_offset_enabled = _live_ema55_slope_dynamic_fee_offset_enabled(config)
        current_stop_loss = protection.stop_loss
        current_take_profit = protection.take_profit
        next_trigger_r = _live_ema55_slope_lock_profit_trigger_r(config)
        risk_per_unit = abs(position.entry_price - protection.stop_loss)
        last_checked_candle_ts: int | None = None
        monitor_parts = [
            f"开始本地止盈止损监控 | 触发标的={protection.trigger_inst_id}",
            f"斜率退出标的={signal_instrument.inst_id}",
            f"触发价格类型={protection.trigger_price_type}",
            f"止损={format_decimal(protection.stop_loss)}",
            f"止盈={format_decimal(protection.take_profit)}",
        ]
        if dynamic_take_profit_enabled:
            monitor_parts.append(f"首档触发R={next_trigger_r}")
            monitor_parts.append(f"nR保本={'开启' if dynamic_two_r_break_even else '关闭'}")
            monitor_parts.append(f"手续费偏移={'开启' if dynamic_fee_offset_enabled else '关闭'}")
            monitor_parts.append(
                f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根"
            )
        self._logger(" | ".join(monitor_parts))

        while not self._stop_event.is_set():
            current_price = self._get_trigger_price_with_retry(
                protection.trigger_inst_id,
                protection.trigger_price_type,
                environment=config.environment,
            )
            self._emit_runtime_heartbeat("本地止盈止损")
            manual_control = self.get_manual_trade_control()
            manual_mode = manual_control.management_mode == "manual"
            if manual_mode and manual_control.stop_loss is not None:
                current_stop_loss = manual_control.stop_loss
            if dynamic_take_profit_enabled and manual_mode:
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            elif dynamic_take_profit_enabled:
                holding_bars = _holding_bars_live(position.entry_ts, int(time.time() * 1000), config.bar)
                updated_stop_loss, updated_take_profit, updated_trigger_r, moved = _advance_dynamic_stop_live(
                    direction=protection.direction,
                    current_price=current_price,
                    entry_price=position.entry_price,
                    risk_per_unit=risk_per_unit,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    tick_size=trade_instrument.tick_size,
                    two_r_break_even=dynamic_two_r_break_even,
                    break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
                    trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
                    first_lock_r=_live_dynamic_first_lock_r(config),
                    trailing_step_r=_live_dynamic_trailing_step_r(config),
                    separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
                    dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                    dynamic_protection_rules=_live_dynamic_protection_rules(config),
                    holding_bars=holding_bars,
                    time_stop_break_even_enabled=config.time_stop_break_even_enabled,
                    time_stop_break_even_bars=config.resolved_time_stop_break_even_bars(),
                )
                if moved:
                    current_stop_loss = updated_stop_loss
                    current_take_profit = updated_take_profit
                    next_trigger_r = updated_trigger_r
                    self._logger(
                        f"动态止盈上移 | 当前价={format_decimal(current_price)} | "
                        f"新止损={format_decimal(current_stop_loss)} | 下一阶段={next_trigger_r}R | "
                        f"holding_bars={holding_bars}"
                    )
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            elif uses_flat_exit:
                stop_hit = current_price <= current_stop_loss if protection.direction == "long" else current_price >= current_stop_loss
                take_hit = False
            else:
                stop_hit, take_hit = evaluate_local_exit(
                    direction=protection.direction,
                    current_price=current_price,
                    stop_loss=current_stop_loss,
                    take_profit=current_take_profit,
                )
            if stop_hit or take_hit:
                reason = "止盈"
                if stop_hit:
                    reason = (
                        _classify_live_dynamic_close_reason(
                            direction=protection.direction,
                            entry_price=position.entry_price,
                            initial_stop_loss=protection.stop_loss,
                            current_stop_loss=current_stop_loss,
                            risk_per_unit=risk_per_unit,
                            next_trigger_r=next_trigger_r,
                            tick_size=trade_instrument.tick_size,
                            two_r_break_even=dynamic_two_r_break_even,
                            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                            time_stop_break_even_enabled=config.time_stop_break_even_enabled,
                            break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
                            trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
                            first_lock_r=_live_dynamic_first_lock_r(config),
                            trailing_step_r=_live_dynamic_trailing_step_r(config),
                            separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
                            dynamic_protection_rules=_live_dynamic_protection_rules(config),
                        )
                        if dynamic_take_profit_enabled
                        else "止损"
                    )
                self._logger(
                    f"本地{reason}触发 | 触发标的={protection.trigger_inst_id} | "
                    f"当前价={format_decimal(current_price)} | "
                    f"止损={format_decimal(current_stop_loss)} | 止盈={format_decimal(current_take_profit)}"
                )
                self._mark_ema55_slope_same_bar_reentry_block(
                    credentials,
                    config,
                    candle_ts=last_checked_candle_ts or protection.candle_ts,
                )
                self._close_position(credentials, config, trade_instrument, position, reason)
                self.resume_automatic_trade_management()
                return

            candles = self._get_candles_with_retry(config.inst_id, config.bar, limit=lookback)
            confirmed = [candle for candle in candles if candle.confirmed]
            if confirmed:
                newest_ts = confirmed[-1].ts
                if newest_ts != last_checked_candle_ts:
                    last_checked_candle_ts = newest_ts
                    exit_ready, exit_candle, _ema_value, slope_ratio = ema55_slope_short_exit_ready(confirmed, config)
                    if exit_ready and exit_candle is not None:
                        slope_text = f"{slope_ratio:.6f}" if slope_ratio is not None else "-"
                        line_label = config.ema_label()
                        self._logger(
                            f"{_fmt_ts(exit_candle.ts)} | {line_label} 斜率转正平仓 | 斜率比例={slope_text}"
                        )
                        self._mark_ema55_slope_same_bar_reentry_block(
                            credentials,
                            config,
                            candle_ts=exit_candle.ts,
                        )
                        self._close_position(credentials, config, trade_instrument, position, "斜率转正")
                        self.resume_automatic_trade_management()
                        return

            self._stop_event.wait(config.poll_seconds)

    def _close_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        trade_instrument: Instrument,
        position: FilledPosition,
        reason: str,
    ) -> None:
        remaining = position.size
        lot = trade_instrument.lot_size
        effective_pos_side = self._resolve_filled_position_pos_side(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=position.side,
            pos_side=position.pos_side,
        )
        for _ in range(3):
            if remaining <= 0:
                break

            size = snap_to_increment(remaining, lot, "down")
            if size < trade_instrument.min_size:
                self._logger(
                    f"{reason}后剩余未平数量 {format_decimal(remaining)} 小于最小下单量 "
                    f"{format_decimal(trade_instrument.min_size)}，请手动处理。"
                )
                return

            result = self._place_exit_order(
                credentials,
                config,
                trade_instrument=trade_instrument,
                side=position.close_side,
                size=size,
                pos_side=effective_pos_side,
            )
            filled = self._wait_for_order_fill(
                credentials,
                config,
                trade_instrument=trade_instrument,
                side=position.close_side,
                pos_side=effective_pos_side,
                result=result,
                estimated_entry=self._estimate_trade_entry_price_with_retry(trade_instrument, position.close_side),
            )
            remaining -= filled.size
            trade_pnl = StrategyEngine._trade_fill_pnl_text_for_close(
                position,
                fill_size=filled.size,
                fill_price=filled.entry_price,
                trade_instrument=trade_instrument,
            )
            closed_position = replace(position, size=filled.size)
            history_item = self._lookup_recent_position_close_history(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=closed_position,
                exit_price=filled.entry_price,
                close_ms=filled.entry_ts,
            )
            close_trade_pnl = self._position_history_total_net_pnl_text(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=closed_position,
                history_item=history_item,
            )
            if close_trade_pnl:
                trade_pnl = close_trade_pnl
            self._logger(
                f"本地{reason}平仓已成交 | ordId={filled.ord_id} | 标的={trade_instrument.inst_id} | "
                f"方向={position.close_side.upper()} | "
                f"成交均价={_format_notify_price_by_tick_size(filled.entry_price, trade_instrument.tick_size)} | "
                f"成交数量={_format_size_with_contract_equivalent(trade_instrument, filled.size)} | 剩余={_format_size_with_contract_equivalent(trade_instrument, max(remaining, Decimal('0')))}"
            )
            self._notify_trade_close(
                config,
                symbol=trade_instrument.inst_id,
                side=position.close_side,
                size=filled.size,
                size_text=_format_notify_size_with_unit(trade_instrument, filled.size),
                entry_price=position.entry_price,
                exit_price=filled.entry_price,
                tick_size=trade_instrument.tick_size,
                trigger_reason=reason,
                detail=f"本地{reason}触发后平仓成交",
                trade_pnl=trade_pnl,
            )

        if remaining > 0:
            raise RuntimeError(f"本地{reason}平仓后仍有剩余仓位 {format_decimal(remaining)}，请手动检查")

        self._logger("本次本地止盈止损流程已结束。")

    def _monitor_local_exit_v2(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        trade_instrument: Instrument,
        position: FilledPosition,
        protection: ProtectionPlan,
    ) -> None:
        self._monitor_local_exit(credentials, config, trade_instrument, position, protection)

    def _monitor_exchange_dynamic_stop(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        initial_stop_loss: Decimal,
        stop_loss_algo_cl_ord_id: str | None,
        stop_loss_algo_id: str | None = None,
    ) -> None:
        algo_id_norm = (stop_loss_algo_id or "").strip()
        algo_cl_norm = (stop_loss_algo_cl_ord_id or "").strip()
        if not algo_id_norm and not algo_cl_norm:
            raise RuntimeError("动态止盈模式缺少 OKX 止损委托标识（algoId 或 algoClOrdId），无法继续动态上移。")

        current_stop_loss = initial_stop_loss
        next_trigger_r = _live_dynamic_initial_trigger_r(config)
        amend_failures = 0
        consecutive_read_failures = 0
        risk_per_unit = abs(position.entry_price - initial_stop_loss)
        direction: Literal["long", "short"] = "long" if position.side == "buy" else "short"
        next_trigger_price_text = _dynamic_next_trigger_price_text(
            direction=direction,
            entry_price=position.entry_price,
            risk_per_unit=risk_per_unit,
            next_trigger_r=next_trigger_r,
            tick_size=trade_instrument.tick_size,
            dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
        )
        ref_parts: list[str] = []
        if algo_cl_norm:
            ref_parts.append(f"algoClOrdId={algo_cl_norm}")
        if algo_id_norm:
            ref_parts.append(f"algoId={algo_id_norm}")
        ref_label = " | ".join(ref_parts) if ref_parts else "-"
        pos_side_txt = (position.pos_side or "").strip()
        api_txt = (self._api_name or "").strip() or "-"
        pos_bits = [
            f"开始监控 OKX 动态止损 | API={api_txt} | 标的={trade_instrument.inst_id}",
            f"持仓方向={position.side.upper()}"
            + (f" | posSide={pos_side_txt}" if pos_side_txt else ""),
            f"开仓价={format_decimal(position.entry_price)}",
            f"数量={_format_size_with_contract_equivalent(trade_instrument, position.size)}",
            f"R价差(开仓-初始止损)={format_decimal(risk_per_unit)}",
            ref_label,
            f"触发价格类型={config.tp_sl_trigger_type}",
            f"初始止损={format_decimal(initial_stop_loss)}",
            _live_dynamic_break_even_summary(config),
            f"下一次上移阶段={next_trigger_r}R",
            f"下一次上移触发价={next_trigger_price_text}",
            f"手续费偏移={config.dynamic_fee_offset_enabled_label()}",
            f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根",
        ]
        self._logger(" | ".join(pos_bits))

        baseline_abs: Decimal | None = None
        missing_algo_strikes = 0
        trend_ema_close_exit_armed = False
        trend_ema_close_exit_last_candle_ts: int | None = None

        while not self._stop_event.is_set():
            try:
                should_continue = self._monitor_exchange_dynamic_stop_once(
                    credentials,
                    config,
                    trade_instrument=trade_instrument,
                    position=position,
                    stop_loss_algo_cl_ord_id=algo_cl_norm or None,
                    stop_loss_algo_id=algo_id_norm or None,
                    current_stop_loss=current_stop_loss,
                    initial_stop_loss=initial_stop_loss,
                    next_trigger_r=next_trigger_r,
                    risk_per_unit=risk_per_unit,
                    amend_failures=amend_failures,
                    missing_algo_strikes=missing_algo_strikes,
                    baseline_abs_position=baseline_abs,
                    trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                    trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                )
            except Exception as exc:
                if self._stop_event.is_set():
                    break
                retryable_exc = _coerce_okx_read_exception(exc)
                if retryable_exc is None or not _is_transient_okx_error(retryable_exc):
                    raise
                consecutive_read_failures += 1
                detail = str(retryable_exc).strip() or f"code={retryable_exc.code or '-'}"
                if consecutive_read_failures < OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES:
                    self._logger(
                        " | ".join(
                            [
                                "OKX 动态止损监控读取异常，保留当前止损并继续重试",
                                f"连续失败={consecutive_read_failures}/{OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES}",
                                detail,
                            ]
                        )
                    )
                    self._stop_event.wait(max(config.poll_seconds, 1.0))
                    continue
                raise RuntimeError(
                    f"OKX 动态止损监控连续读取失败 {consecutive_read_failures} 次：{detail} | 已保留当前 OKX 止损，请人工检查"
                ) from exc
            else:
                consecutive_read_failures = 0
                self._emit_runtime_heartbeat("OKX动态止损")
                current_stop_loss = should_continue.current_stop_loss
                next_trigger_r = should_continue.next_trigger_r
                amend_failures = should_continue.amend_failures
                missing_algo_strikes = should_continue.missing_algo_strikes
                if should_continue.seed_baseline_abs is not None:
                    baseline_abs = should_continue.seed_baseline_abs
                trend_ema_close_exit_armed = should_continue.trend_ema_close_exit_armed
                trend_ema_close_exit_last_candle_ts = should_continue.trend_ema_close_exit_last_candle_ts
                if not should_continue.keep_monitoring:
                    self.resume_automatic_trade_management()
                    return
                self._stop_event.wait(config.poll_seconds)
                continue

        self._logger("策略已停止，保留当前 OKX 动态止损。")

    def run_takeover_exchange_dynamic_stop(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        initial_stop_loss: Decimal,
        stop_loss_algo_id: str | None,
        stop_loss_algo_cl_ord_id: str | None,
    ) -> None:
        """持仓大窗「接管」：沿用已有 OKX 止损算法单，按模板动态止盈规则改价上移。"""
        if not _live_dynamic_take_profit_enabled(config):
            raise RuntimeError("当前策略模板未启用动态止盈，无法接管。")
        if config.trader_virtual_stop_loss:
            raise RuntimeError("交易员虚拟止损模式下不存在可接管的交易所止损单。")
        if not (stop_loss_algo_id or "").strip() and not (stop_loss_algo_cl_ord_id or "").strip():
            raise RuntimeError("缺少止损算法单 algoId / algoClOrdId。")
        self._monitor_exchange_dynamic_stop(
            credentials,
            config,
            trade_instrument=trade_instrument,
            position=position,
            initial_stop_loss=initial_stop_loss,
            stop_loss_algo_cl_ord_id=(stop_loss_algo_cl_ord_id or "").strip() or None,
            stop_loss_algo_id=(stop_loss_algo_id or "").strip() or None,
        )

    def interrupt_takeover_monitor(self) -> None:
        """中断由 run_takeover_exchange_dynamic_stop 或独立引擎实例触发的动态止损轮询。"""
        self._stop_event.set()

    def _resolve_algo_terminated_after_missing(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        algo_id: str | None,
        algo_cl_ord_id: str | None,
    ) -> tuple[bool, str | None]:
        """挂单列表中已找不到该算法止损时，向 OKX 查询单笔委托：终态或不存在则结束监控。"""
        aid = (algo_id or "").strip()
        acl = (algo_cl_ord_id or "").strip()
        if not aid and not acl:
            return False, None
        try:
            row = self._client.get_order_algo(
                credentials,
                environment=config.environment,
                inst_id=inst_id.strip().upper(),
                algo_id=aid or None,
                algo_cl_ord_id=acl or None,
            )
        except OkxApiError as exc:
            text = str(exc).strip()
            code = str(getattr(exc, "code", None) or "").strip()
            low = text.lower()
            if code in {"51620", "51621", "51400"} or "does not exist" in low or "不存在" in text:
                return True, (
                    f"OKX 查询算法止损不存在或已失效（code={code or '-'}），推断已触发或已撤单，结束动态止损监控：{text}"
                )
            return False, None
        if row is None:
            return True, "OKX 查询算法止损返回空记录，推断该委托已从账户移除，结束动态止损监控。"
        state = (row.get("state") or "").strip().lower()
        if state in {"canceled", "order_failed", "partially_failed"}:
            return True, (
                f"OKX 算法止损 state={state}（algoId={row.get('algoId') or '-'}），结束动态止损监控。"
            )
        return False, None

    def _monitor_exchange_dynamic_stop_once(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        stop_loss_algo_cl_ord_id: str | None,
        stop_loss_algo_id: str | None,
        current_stop_loss: Decimal,
        initial_stop_loss: Decimal,
        next_trigger_r: int,
        risk_per_unit: Decimal,
        amend_failures: int,
        missing_algo_strikes: int = 0,
        baseline_abs_position: Decimal | None = None,
        trend_ema_close_exit_armed: bool = False,
        trend_ema_close_exit_last_candle_ts: int | None = None,
    ) -> DynamicStopMonitorStepResult:
        algo_ref = (
            f"algoClOrdId={stop_loss_algo_cl_ord_id}"
            if (stop_loss_algo_cl_ord_id or "").strip()
            else f"algoId={stop_loss_algo_id or '-'}"
        )
        live_position = self._find_managed_position(credentials, config, trade_instrument, position)
        if live_position is None:
            self._logger("未检测到策略持仓，OKX 动态止损监控结束。")
            self._notify_exchange_dynamic_stop_close(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                initial_stop_loss=initial_stop_loss,
                current_stop_loss=current_stop_loss,
                risk_per_unit=risk_per_unit,
                next_trigger_r=next_trigger_r,
                detail="未检测到策略持仓，推断 OKX 动态止损已完成平仓。",
            )
            return DynamicStopMonitorStepResult(
                keep_monitoring=False,
                current_stop_loss=current_stop_loss,
                next_trigger_r=next_trigger_r,
                amend_failures=amend_failures,
                missing_algo_strikes=0,
                seed_baseline_abs=None,
                trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
            )

        seed_snap: Decimal | None = None
        if baseline_abs_position is None:
            seed_snap = abs(live_position.position)

        manual_control = self.get_manual_trade_control()
        if manual_control.management_mode == "manual":
            manual_stop_loss = manual_control.stop_loss
            return DynamicStopMonitorStepResult(
                keep_monitoring=True,
                current_stop_loss=manual_stop_loss if manual_stop_loss is not None else current_stop_loss,
                next_trigger_r=next_trigger_r,
                amend_failures=0,
                missing_algo_strikes=0,
                seed_baseline_abs=seed_snap,
                trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
            )

        direction: Literal["long", "short"] = "long" if position.side == "buy" else "short"
        pending_tracked = self._find_pending_algo_order_for_dynamic_stop(
            credentials,
            config,
            trade_instrument=trade_instrument,
            algo_cl_ord_id=stop_loss_algo_cl_ord_id,
            algo_id=stop_loss_algo_id,
        )
        next_missing = 0 if pending_tracked is not None else missing_algo_strikes + 1
        live_abs = abs(live_position.position)
        # 止损算法单已从挂单消失时，必须先尝试「推断已触发 / 强制收口」，再读触发价做上移逻辑。
        # 否则 _get_trigger_price 一旦连续失败，推断分支永远走不到，界面会长期显示监控中。
        if pending_tracked is None:
            if next_missing >= OKX_DYNAMIC_STOP_MISSING_ALGO_MIN_POLLS:
                term, term_msg = self._resolve_algo_terminated_after_missing(
                    credentials,
                    config,
                    inst_id=trade_instrument.inst_id,
                    algo_id=stop_loss_algo_id,
                    algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                )
                if term:
                    if term_msg:
                        self._logger(term_msg)
                    self._notify_exchange_dynamic_stop_close(
                        credentials,
                        config,
                        trade_instrument=trade_instrument,
                        position=position,
                        initial_stop_loss=initial_stop_loss,
                        current_stop_loss=current_stop_loss,
                        risk_per_unit=risk_per_unit,
                        next_trigger_r=next_trigger_r,
                        detail=term_msg or "OKX 动态止损委托已结束，推断持仓已平仓。",
                    )
                    return DynamicStopMonitorStepResult(
                        keep_monitoring=False,
                        current_stop_loss=current_stop_loss,
                        next_trigger_r=next_trigger_r,
                        amend_failures=amend_failures,
                        missing_algo_strikes=0,
                        seed_baseline_abs=seed_snap,
                        trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                        trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                    )
            infer_price = Decimal("0")
            if next_missing >= OKX_DYNAMIC_STOP_MISSING_ALGO_PRICE_EXIT_POLLS:
                try:
                    infer_price = self._get_trigger_price_with_retry(
                        trade_instrument.inst_id,
                        config.tp_sl_trigger_type,
                        environment=config.environment,
                        max_cached_age_seconds=EXCHANGE_DYNAMIC_STOP_MAX_CACHED_TICKER_AGE_SECONDS,
                    )
                except Exception:
                    infer_price = Decimal("0")
            should_end, why = _dynamic_stop_infer_triggered_algo_not_in_book(
                direction=direction,
                live_abs=live_abs,
                baseline_abs=baseline_abs_position,
                monitored_sz=position.size,
                current_price=infer_price,
                current_stop_loss=current_stop_loss,
                initial_stop_loss=initial_stop_loss,
                missing_rounds=next_missing,
                lot_size=trade_instrument.lot_size,
            )
            if should_end:
                if why:
                    self._logger(why)
                self._notify_exchange_dynamic_stop_close(
                    credentials,
                    config,
                    trade_instrument=trade_instrument,
                    position=position,
                    initial_stop_loss=initial_stop_loss,
                    current_stop_loss=current_stop_loss,
                    risk_per_unit=risk_per_unit,
                    next_trigger_r=next_trigger_r,
                    detail=why or "OKX 动态止损委托已不在挂单列表，推断持仓已平仓。",
                )
                return DynamicStopMonitorStepResult(
                    keep_monitoring=False,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    amend_failures=amend_failures,
                    missing_algo_strikes=0,
                    seed_baseline_abs=seed_snap,
                    trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                    trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                )

        current_price = self._get_trigger_price_with_retry(
            trade_instrument.inst_id,
            config.tp_sl_trigger_type,
            environment=config.environment,
            max_cached_age_seconds=EXCHANGE_DYNAMIC_STOP_MAX_CACHED_TICKER_AGE_SECONDS,
        )
        holding_bars = _holding_bars_live(position.entry_ts, int(time.time() * 1000), config.bar)
        updated_stop_loss, next_trigger_price, updated_trigger_r, moved = _advance_dynamic_stop_live(
            direction=direction,
            current_price=current_price,
            entry_price=position.entry_price,
            risk_per_unit=risk_per_unit,
            current_stop_loss=current_stop_loss,
            next_trigger_r=next_trigger_r,
            tick_size=trade_instrument.tick_size,
            two_r_break_even=_live_ema55_slope_dynamic_two_r_break_even_enabled(config),
            break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
            trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
            first_lock_r=_live_dynamic_first_lock_r(config),
            trailing_step_r=_live_dynamic_trailing_step_r(config),
            separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
            dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
            dynamic_protection_rules=_live_dynamic_protection_rules(config),
            holding_bars=holding_bars,
            time_stop_break_even_enabled=config.time_stop_break_even_enabled,
            time_stop_break_even_bars=config.resolved_time_stop_break_even_bars(),
        )
        if direction == "long" and _live_trend_ema_close_exit_after_trigger_r_enabled(config):
            trend_ema_close_exit_armed = trend_ema_close_exit_armed or _live_dynamic_trigger_r_reached(
                direction=direction,
                current_price=current_price,
                entry_price=position.entry_price,
                risk_per_unit=risk_per_unit,
                next_trigger_r=updated_trigger_r,
                trigger_r=_live_trend_ema_close_exit_trigger_r(config),
                tick_size=trade_instrument.tick_size,
                dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
            )
            if trend_ema_close_exit_armed:
                signal_inst_id = (config.inst_id or trade_instrument.inst_id).strip().upper() or trade_instrument.inst_id
                exit_ready, trend_ema_close_exit_last_candle_ts, exit_candle, trend_ema_value = (
                    self._poll_trend_ema_close_exit_snapshot(
                        config,
                        signal_inst_id=signal_inst_id,
                        direction=direction,
                        last_checked_candle_ts=trend_ema_close_exit_last_candle_ts,
                    )
                )
                if exit_ready and exit_candle is not None and trend_ema_value is not None:
                    trend_label = config.trend_ema_label()
                    self._logger(
                        f"{_fmt_ts(exit_candle.ts)} | 达到 {_live_trend_ema_close_exit_trigger_r(config)}R 后收盘跌破 {trend_label} 平仓 | "
                        f"收盘={format_decimal(exit_candle.close)} | {trend_label}={format_decimal(trend_ema_value)}"
                    )
                    self._close_position(credentials, config, trade_instrument, position, f"跌破{trend_label}")
                    return DynamicStopMonitorStepResult(
                        keep_monitoring=False,
                        current_stop_loss=updated_stop_loss,
                        next_trigger_r=updated_trigger_r,
                        amend_failures=0,
                        missing_algo_strikes=next_missing,
                        seed_baseline_abs=seed_snap,
                        trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                        trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                    )
        should_amend = moved and (
            updated_stop_loss > current_stop_loss if position.side == "buy" else updated_stop_loss < current_stop_loss
        )
        if not should_amend:
            return DynamicStopMonitorStepResult(
                keep_monitoring=True,
                current_stop_loss=current_stop_loss,
                next_trigger_r=next_trigger_r,
                amend_failures=0,
                missing_algo_strikes=next_missing,
                seed_baseline_abs=seed_snap,
                trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
            )

        fresh_price = self._get_trigger_price_with_retry(
            trade_instrument.inst_id,
            config.tp_sl_trigger_type,
            environment=config.environment,
            max_cached_age_seconds=EXCHANGE_DYNAMIC_STOP_MAX_CACHED_TICKER_AGE_SECONDS,
        )
        if not _is_exchange_dynamic_stop_candidate_valid(
            direction=direction,
            current_price=fresh_price,
            candidate_stop_loss=updated_stop_loss,
        ):
            self._logger(
                " | ".join(
                    [
                        "OKX 动态止损候选价已过期，跳过本次上移",
                        f"当前价={format_decimal(fresh_price)}",
                        f"当前止损={format_decimal(current_stop_loss)}",
                        f"候选止损={format_decimal(updated_stop_loss)}",
                        f"下一触发价={format_decimal(next_trigger_price)}",
                        algo_ref,
                    ]
                )
            )
            self._stop_event.wait(max(config.poll_seconds / 2, 0.5))
            return DynamicStopMonitorStepResult(
                keep_monitoring=True,
                current_stop_loss=current_stop_loss,
                next_trigger_r=next_trigger_r,
                amend_failures=amend_failures,
                missing_algo_strikes=next_missing,
                seed_baseline_abs=seed_snap,
                trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
            )

        algo_order = pending_tracked
        if algo_order is None:
            self._logger(
                " | ".join(
                    [
                        "OKX 动态止损委托暂未出现在挂单列表，稍后重试",
                        f"候选止损={format_decimal(updated_stop_loss)}",
                        algo_ref,
                    ]
                )
            )
            self._stop_event.wait(max(config.poll_seconds / 2, 0.5))
            return DynamicStopMonitorStepResult(
                keep_monitoring=True,
                current_stop_loss=current_stop_loss,
                next_trigger_r=next_trigger_r,
                amend_failures=amend_failures,
                missing_algo_strikes=next_missing,
                seed_baseline_abs=seed_snap,
                trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
            )

        amend_cl_ord = (algo_order.algo_client_order_id or stop_loss_algo_cl_ord_id or "").strip() or None
        try:
            self._amend_algo_order_with_recovery(
                credentials,
                config,
                trade_instrument=trade_instrument,
                algo_id=algo_order.algo_id,
                algo_cl_ord_id=amend_cl_ord,
                req_id=self._next_client_order_id(role="amd"),
                new_stop_loss_trigger_price=updated_stop_loss,
                new_stop_loss_trigger_price_type=config.tp_sl_trigger_type,
                recover_algo_id=(stop_loss_algo_id or "").strip() or None,
                recover_algo_cl_ord_id=(stop_loss_algo_cl_ord_id or "").strip() or None,
            )
        except OkxApiError as exc:
            live_position = self._find_managed_position(credentials, config, trade_instrument, position)
            if live_position is None:
                self._logger("检测到持仓已关闭，停止 OKX 动态止损监控。")
                self._notify_exchange_dynamic_stop_close(
                    credentials,
                    config,
                    trade_instrument=trade_instrument,
                    position=position,
                    initial_stop_loss=initial_stop_loss,
                    current_stop_loss=current_stop_loss,
                    risk_per_unit=risk_per_unit,
                    next_trigger_r=next_trigger_r,
                    detail="改单异常后检测到持仓已关闭，推断 OKX 动态止损已完成平仓。",
                )
                return DynamicStopMonitorStepResult(
                    keep_monitoring=False,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    amend_failures=amend_failures,
                    missing_algo_strikes=0,
                    seed_baseline_abs=seed_snap,
                    trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                    trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                )
            latest_price = self._get_trigger_price_with_retry(
                trade_instrument.inst_id,
                config.tp_sl_trigger_type,
                environment=config.environment,
                max_cached_age_seconds=EXCHANGE_DYNAMIC_STOP_MAX_CACHED_TICKER_AGE_SECONDS,
            )
            detail = str(exc).strip() or f"code={exc.code or '-'}"
            if not _is_exchange_dynamic_stop_candidate_valid(
                direction=direction,
                current_price=latest_price,
                candidate_stop_loss=updated_stop_loss,
            ):
                self._logger(
                    " | ".join(
                        [
                            "OKX 动态止损上移遇到快速回抽，本次改价已放弃",
                            f"当前价={format_decimal(latest_price)}",
                            f"候选止损={format_decimal(updated_stop_loss)}",
                            algo_ref,
                            detail,
                        ]
                    )
                )
                self._stop_event.wait(max(config.poll_seconds / 2, 0.5))
                return DynamicStopMonitorStepResult(
                    keep_monitoring=True,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    amend_failures=amend_failures,
                    missing_algo_strikes=next_missing,
                    seed_baseline_abs=seed_snap,
                    trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                    trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                )

            next_amend_failures = amend_failures + 1
            if next_amend_failures < 4:
                self._logger(
                    " | ".join(
                        [
                            "OKX 动态止损上移失败，稍后重试",
                            f"当前价={format_decimal(latest_price)}",
                            f"候选止损={format_decimal(updated_stop_loss)}",
                            algo_ref,
                            detail,
                        ]
                    )
                )
                self._stop_event.wait(max(config.poll_seconds / 2, 0.5))
                return DynamicStopMonitorStepResult(
                    keep_monitoring=True,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    amend_failures=next_amend_failures,
                    missing_algo_strikes=next_missing,
                    seed_baseline_abs=seed_snap,
                    trend_ema_close_exit_armed=trend_ema_close_exit_armed,
                    trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
                )
            raise RuntimeError(f"OKX 动态止损上移失败：{detail}") from exc

        self._logger(
            f"OKX 动态止损已上移 | 当前价={format_decimal(fresh_price)} | "
            f"新止损={format_decimal(updated_stop_loss)} | 下一阶段={updated_trigger_r}R | "
            f"下一次上移触发价={_dynamic_next_trigger_price_text(direction=direction, entry_price=position.entry_price, risk_per_unit=risk_per_unit, next_trigger_r=updated_trigger_r, tick_size=trade_instrument.tick_size, dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config))} | "
            f"{algo_ref} | holding_bars={holding_bars}"
        )
        return DynamicStopMonitorStepResult(
            keep_monitoring=True,
            current_stop_loss=updated_stop_loss,
            next_trigger_r=updated_trigger_r,
            amend_failures=0,
            missing_algo_strikes=0,
            seed_baseline_abs=seed_snap,
            trend_ema_close_exit_armed=trend_ema_close_exit_armed,
            trend_ema_close_exit_last_candle_ts=trend_ema_close_exit_last_candle_ts,
        )

    def _monitor_exchange_managed_position_until_closed(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
    ) -> None:
        consecutive_read_failures = 0
        saw_live_position = False
        while not self._stop_event.is_set():
            try:
                live_position = self._find_managed_position(credentials, config, trade_instrument, position)
            except OkxApiError as exc:
                consecutive_read_failures += 1
                detail = str(exc).strip() or f"code={exc.code or '-'}"
                if consecutive_read_failures < OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES:
                    self._logger(
                        " | ".join(
                            [
                                "OKX 托管持仓读取异常，保留当前 OKX 止盈止损，稍后重试",
                                f"第{consecutive_read_failures}/{OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES}次",
                                detail,
                            ]
                        )
                    )
                    self._stop_event.wait(max(config.poll_seconds, 1.0))
                    continue
                raise RuntimeError(
                    "OKX 托管持仓连续读取失败 "
                    f"{OKX_DYNAMIC_STOP_MONITOR_MAX_READ_FAILURES} 次：{detail} | 已保留当前 OKX 止盈止损，请人工检查"
                ) from exc

            consecutive_read_failures = 0
            if live_position is None:
                if saw_live_position:
                    self._logger("检测到 OKX 托管持仓已结束。")
                else:
                    self._logger("未再检测到策略持仓，视为本轮 OKX 托管持仓已结束。")
                self._notify_trade_close(
                    config,
                    symbol=trade_instrument.inst_id,
                    side=position.close_side,
                    size=position.size,
                    size_text=_format_notify_size_with_unit(trade_instrument, position.size),
                    entry_price=position.entry_price,
                    tick_size=trade_instrument.tick_size,
                    trigger_reason="OKX托管平仓（原因待确认）",
                    detail="OKX 托管止盈止损持仓已结束；当前监控链路无法区分具体由止盈还是止损触发，请以 OKX 成交明细为准。",
                    trade_pnl=self._position_history_total_net_pnl_text(
                        credentials,
                        config,
                        trade_instrument=trade_instrument,
                        position=position,
                        history_item=self._lookup_recent_position_close_history(
                            credentials,
                            config,
                            trade_instrument=trade_instrument,
                            position=position,
                            close_ms=int(time.time() * 1000),
                        ),
                    ),
                )
                return

            saw_live_position = True
            self._emit_runtime_heartbeat("OKX托管持仓")
            self._stop_event.wait(config.poll_seconds)

        self._logger("策略已停止，保留当前 OKX 托管止盈止损。")

    def _find_pending_algo_order_for_dynamic_stop(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        algo_cl_ord_id: str | None,
        algo_id: str | None,
    ) -> OkxTradeOrderItem | None:
        aid = (algo_id or "").strip()
        acid = (algo_cl_ord_id or "").strip()
        if not aid and not acid:
            return None
        pending_orders = self._get_pending_orders_with_retry(
            credentials,
            config,
            inst_types=(trade_instrument.inst_type,),
            limit=100,
        )
        for item in pending_orders:
            if item.source_kind != "algo":
                continue
            if item.inst_id != trade_instrument.inst_id:
                continue
            if aid and (item.algo_id or "").strip() == aid:
                return item
            if not aid and acid and (item.algo_client_order_id or "").strip() == acid:
                return item
        if aid and acid:
            for item in pending_orders:
                if item.source_kind != "algo":
                    continue
                if item.inst_id != trade_instrument.inst_id:
                    continue
                if (item.algo_client_order_id or "").strip() == acid:
                    return item
        return None

    def _find_pending_algo_order_by_client_id(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        algo_cl_ord_id: str,
    ) -> OkxTradeOrderItem | None:
        return self._find_pending_algo_order_for_dynamic_stop(
            credentials,
            config,
            trade_instrument=trade_instrument,
            algo_cl_ord_id=algo_cl_ord_id,
            algo_id=None,
        )

    def _find_pending_entry_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        ord_id: str | None,
        cl_ord_id: str | None,
    ) -> OkxTradeOrderItem | None:
        pending_orders = self._get_pending_orders_with_retry(
            credentials,
            config,
            inst_types=(infer_inst_type(inst_id),),
            limit=100,
        )
        normalized_ord_id = (ord_id or "").strip()
        normalized_cl_ord_id = (cl_ord_id or "").strip()
        for item in pending_orders:
            if item.source_kind != "normal":
                continue
            if item.inst_id != inst_id:
                continue
            if normalized_ord_id and (item.order_id or "").strip() == normalized_ord_id:
                return item
            if normalized_cl_ord_id and (item.client_order_id or "").strip() == normalized_cl_ord_id:
                return item
        return None

    def _find_managed_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        trade_instrument: Instrument,
        position: FilledPosition,
    ) -> OkxPosition | None:
        positions = self._get_positions_with_retry(
            credentials,
            config,
            inst_type=trade_instrument.inst_type,
        )
        candidates = [
            item
            for item in positions
            if item.inst_id == trade_instrument.inst_id
            and (item.avail_position if item.avail_position not in {None, Decimal("0")} else item.position) != 0
        ]
        if not candidates:
            return None

        expected_pos_side = (
            self._resolve_filled_position_pos_side(
                credentials,
                config,
                trade_instrument=trade_instrument,
                side=position.side,
                pos_side=position.pos_side,
            )
            or ""
        ).strip().lower()
        if expected_pos_side:
            directional = [
                item
                for item in candidates
                if str(item.pos_side or "").strip().lower() == expected_pos_side
            ]
            if directional:
                directional.sort(
                    key=lambda item: abs(
                        item.avail_position if item.avail_position not in {None, Decimal("0")} else item.position
                    ),
                    reverse=True,
                )
                return directional[0]
            actual_sides = ", ".join(
                f"{(str(item.pos_side or '').strip().lower() or 'net')}:{format_decimal(abs(item.position))}"
                for item in candidates
            )
            if self._uses_long_short_position_mode(
                credentials,
                config,
                trade_instrument=trade_instrument,
            ):
                return None
            raise RuntimeError(
                "拒绝接管现有持仓：交易所持仓侧与策略预期不一致"
                f" | 标的={trade_instrument.inst_id}"
                f" | 预期posSide={expected_pos_side}"
                f" | 实际={actual_sides or '-'}"
            )

        for item in candidates:
            if config.position_mode == "net":
                if position.side == "buy" and item.position < 0:
                    continue
                if position.side == "sell" and item.position > 0:
                    continue
            return item
        return None

    def _uses_long_short_position_mode(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
    ) -> bool:
        if trade_instrument.inst_type not in {"SWAP", "FUTURES"}:
            return False
        if config.position_mode == "long_short":
            return True
        get_account_config_cached = getattr(self._client, "_get_account_config_cached", None)
        if not callable(get_account_config_cached):
            return False
        try:
            acct = get_account_config_cached(credentials, config)
        except Exception:
            return False
        acct_mode = (getattr(acct, "position_mode", "") or "").strip().lower()
        return acct_mode == "long_short_mode"

    def _lookup_recent_position_close_history(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        exit_price: Decimal | None = None,
        close_ms: int = 0,
        max_attempts: int = 3,
        delay_seconds: float = 1.0,
    ) -> OkxPositionHistoryItem | None:
        for attempt in range(max_attempts):
            items = self._get_positions_history_with_retry(
                credentials,
                config,
                inst_types=(trade_instrument.inst_type,),
                limit=30,
            )
            matched = self._match_recent_position_close_history(
                items,
                position=position,
                exit_price=exit_price,
                close_ms=close_ms,
            )
            if matched is not None:
                return matched
            if attempt + 1 < max_attempts:
                self._stop_event.wait(delay_seconds)
        return None

    @staticmethod
    def _match_recent_position_close_history(
        items: list[OkxPositionHistoryItem],
        *,
        position: FilledPosition,
        exit_price: Decimal | None = None,
        close_ms: int = 0,
    ) -> OkxPositionHistoryItem | None:
        expected_pos_side = (position.pos_side or "").strip().lower()
        expected_size = abs(position.size)
        expected_entry = position.entry_price if position.entry_price > 0 else None
        expected_exit = exit_price if exit_price is not None and exit_price > 0 else None
        now_ms = int(time.time() * 1000)
        best_item: OkxPositionHistoryItem | None = None
        best_score = -1
        best_time_gap: int | None = None
        for item in items:
            if item.inst_id != position.inst_id:
                continue

            score = 100
            item_pos_side = (item.pos_side or "").strip().lower()
            if expected_pos_side and item_pos_side:
                if item_pos_side != expected_pos_side:
                    continue
                score += 40

            if item.close_size is not None and expected_size > 0:
                close_size = abs(item.close_size)
                diff_ratio = abs(close_size - expected_size) / expected_size
                if diff_ratio <= Decimal("0.02"):
                    score += 40
                elif diff_ratio <= Decimal("0.10"):
                    score += 20
                elif close_size < expected_size * Decimal("0.5"):
                    continue

            if item.open_avg_price is not None and expected_entry is not None:
                diff_ratio = abs(item.open_avg_price - expected_entry) / expected_entry
                if diff_ratio <= Decimal("0.002"):
                    score += 30
                elif diff_ratio <= Decimal("0.02"):
                    score += 15
                elif diff_ratio > Decimal("0.08"):
                    score -= 20

            if item.close_avg_price is not None and expected_exit is not None:
                diff_ratio = abs(item.close_avg_price - expected_exit) / expected_exit
                if diff_ratio <= Decimal("0.002"):
                    score += 35
                elif diff_ratio <= Decimal("0.02"):
                    score += 20
                elif diff_ratio > Decimal("0.08"):
                    score -= 20

            update_time = item.update_time
            if close_ms > 0:
                if update_time is None:
                    # Some OKX history responses omit uTime; keep matching on
                    # symbol, side, size and prices instead of discarding a
                    # record that otherwise uniquely identifies this close.
                    time_gap = None
                else:
                    if update_time + 10 * 60 * 1000 < close_ms:
                        continue
                    if update_time - close_ms > 2 * 60 * 60 * 1000:
                        continue
                    time_gap = abs(update_time - close_ms)
                    if time_gap <= 2 * 60 * 1000:
                        score += 25
                    elif time_gap <= 15 * 60 * 1000:
                        score += 15
                    elif time_gap <= 2 * 60 * 60 * 1000:
                        score += 5
                    else:
                        score -= 10
            else:
                time_gap = None
                if update_time is not None:
                    age_ms = max(0, now_ms - update_time)
                    if age_ms <= 5 * 60 * 1000:
                        score += 20
                    elif age_ms <= 60 * 60 * 1000:
                        score += 10
                    elif age_ms > 3 * 24 * 60 * 60 * 1000:
                        score -= 30

            if item.realized_pnl is not None or item.pnl is not None:
                score += 5

            if score > best_score:
                best_item = item
                best_score = score
                best_time_gap = time_gap
                continue
            if score == best_score and score >= 100 and close_ms > 0:
                current_gap = time_gap if time_gap is not None else 1 << 30
                chosen_gap = best_time_gap if best_time_gap is not None else 1 << 30
                if current_gap < chosen_gap:
                    best_item = item
                    best_time_gap = time_gap
                elif current_gap == chosen_gap and (update_time or 0) > (best_item.update_time or 0):
                    best_item = item
                    best_time_gap = time_gap
        return best_item if best_score >= 100 else None

    @staticmethod
    def _position_history_close_pnl_text(item: OkxPositionHistoryItem | None) -> str:
        if item is None:
            return ""
        value = item.realized_pnl if item.realized_pnl is not None else item.pnl
        if value is None:
            return ""
        return StrategyEngine._signed_pnl_text(value)

    @staticmethod
    def _signed_pnl_text(value: Decimal | None, *, places: int | None = None) -> str:
        if value is None:
            return ""
        text = format_decimal_fixed(value, places) if places is not None else format_decimal(value)
        if value > 0:
            return f"+{text}"
        return text

    def _lookup_entry_fee_for_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        max_attempts: int = 3,
        delay_seconds: float = 1.0,
    ) -> Decimal | None:
        if not position.ord_id and not (position.cl_ord_id or "").strip():
            return None

        inst_types = (trade_instrument.inst_type,)
        entry_window_ms = max(position.entry_ts - 2 * 60 * 1000, 0)
        normalized_cl_ord_id = (position.cl_ord_id or "").strip()
        for attempt in range(max_attempts):
            fills = self._call_okx_read_with_retry(
                f"读取开仓成交手续费 {trade_instrument.inst_id}",
                lambda: self._client.get_fills_history(
                    credentials,
                    environment=config.environment,
                    inst_types=inst_types,
                    limit=100,
                ),
            )
            fill_fee_total = Decimal("0")
            fill_fee_seen = False
            for item in fills:
                if item.inst_id != trade_instrument.inst_id:
                    continue
                if (item.fill_time or 0) < entry_window_ms:
                    continue
                same_order = bool(position.ord_id and (item.order_id or "").strip() == position.ord_id)
                same_client_order = bool(
                    normalized_cl_ord_id and str(item.raw.get("clOrdId") or "").strip() == normalized_cl_ord_id
                )
                if not same_order and not same_client_order:
                    continue
                if item.fill_fee is None:
                    continue
                fill_fee_total += item.fill_fee
                fill_fee_seen = True
            if fill_fee_seen:
                return fill_fee_total

            orders = self._call_okx_read_with_retry(
                f"读取开仓委托手续费 {trade_instrument.inst_id}",
                lambda: self._client.get_order_history(
                    credentials,
                    environment=config.environment,
                    inst_types=inst_types,
                    limit=100,
                ),
            )
            for item in orders:
                if item.inst_id != trade_instrument.inst_id:
                    continue
                if (item.update_time or item.created_time or 0) < entry_window_ms:
                    continue
                same_order = bool(position.ord_id and (item.order_id or "").strip() == position.ord_id)
                same_client_order = bool(
                    normalized_cl_ord_id and (item.client_order_id or "").strip() == normalized_cl_ord_id
                )
                if not same_order and not same_client_order:
                    continue
                if item.fee is not None:
                    return item.fee
            if attempt + 1 < max_attempts:
                self._stop_event.wait(delay_seconds)
        return None

    def _position_history_total_net_pnl_text(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        history_item: OkxPositionHistoryItem | None,
    ) -> str:
        if history_item is None:
            return ""
        try:
            entry_fee = self._lookup_entry_fee_for_position(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
            )
        except Exception:
            entry_fee = None
        gross_pnl = history_item.pnl
        funding_fee = history_item.funding_fee
        close_fee = history_item.fee
        if history_item.realized_pnl is not None:
            value = history_item.realized_pnl
        elif gross_pnl is not None:
            value = (
                gross_pnl
                + (entry_fee or Decimal("0"))
                + (close_fee or Decimal("0"))
                + (funding_fee or Decimal("0"))
            )
        else:
            return ""
        detail_parts: list[str] = []
        if gross_pnl is not None:
            detail_parts.append(f"毛盈亏 {self._signed_pnl_text(gross_pnl, places=2)}")
        if entry_fee is not None or close_fee is not None:
            total_fee = (entry_fee or Decimal("0")) + (close_fee or Decimal("0"))
            detail_parts.append(f"手续费 {self._signed_pnl_text(total_fee, places=2)}")
        if funding_fee is not None:
            detail_parts.append(f"资金费 {self._signed_pnl_text(funding_fee, places=2)}")
        if entry_fee is None:
            detail_parts.append("开仓手续费待补齐")
        net_text = self._signed_pnl_text(value, places=2)
        if not detail_parts:
            return net_text
        return f"{net_text}（{' | '.join(detail_parts)}）"

    def _call_okx_read_with_retry(self, label: str, fn: Callable[[], T]) -> T:
        return self._retry_policy.call_okx_read_with_retry(label, fn)

    def _get_instrument_with_retry(self, inst_id: str) -> Instrument:
        return self._retry_policy.get_instrument(inst_id)

    def _get_candles_with_retry(self, inst_id: str, bar: str, *, limit: int) -> list:
        if self._market_data_hub is not None:
            return self._market_data_hub.get_candles(inst_id, bar, limit=limit)
        return self._retry_policy.get_candles(inst_id, bar, limit=limit)

    def _get_order_with_retry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        ord_id: str | None = None,
        cl_ord_id: str | None = None,
    ):
        return self._retry_policy.get_order(
            credentials,
            config,
            inst_id=inst_id,
            ord_id=ord_id,
            cl_ord_id=cl_ord_id,
        )

    def _get_trigger_price_with_retry(
        self,
        inst_id: str,
        price_type: str,
        *,
        environment: str | None = None,
        max_cached_age_seconds: float | None = None,
    ) -> Decimal:
        return self._retry_policy.get_trigger_price(
            inst_id,
            price_type,
            environment=environment,
            max_cached_age_seconds=max_cached_age_seconds,
        )

    def _get_pending_orders_with_retry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_types: tuple[str, ...],
        limit: int,
    ):
        return self._retry_policy.get_pending_orders(
            credentials,
            config,
            inst_types=inst_types,
            limit=limit,
        )

    def _get_positions_with_retry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_type: str | None = None,
    ) -> list[OkxPosition]:
        return self._retry_policy.get_positions(credentials, config, inst_type=inst_type)

    def _get_positions_history_with_retry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_types: tuple[str, ...],
        limit: int,
    ) -> list[OkxPositionHistoryItem]:
        return self._retry_policy.get_positions_history(
            credentials,
            config,
            inst_types=inst_types,
            limit=limit,
        )

    def _fetch_atr_snapshot_with_retry(
        self,
        inst_id: str,
        bar: str,
        atr_period: int,
    ) -> AtrSnapshot:
        return self._call_okx_read_with_retry(
            f"读取ATR快照 {inst_id} {bar}",
            lambda: fetch_atr_snapshot(self._client, inst_id, bar, atr_period),
        )

    def _estimate_trade_entry_price_with_retry(
        self,
        instrument: Instrument,
        side: Literal["buy", "sell"],
    ) -> Decimal:
        return self._call_okx_read_with_retry(
            f"Estimate entry price {instrument.inst_id} {side}",
            lambda: estimate_trade_entry_price(self._client, instrument, side),
        )

    def _fetch_hourly_debug_snapshot_with_retry(
        self,
        inst_id: str,
        *,
        ema_period: int,
        trend_ema_period: int = 0,
        big_ema_period: int = 0,
        entry_reference_ema_period: int = 0,
        ma_type: str = "ema",
    ) -> HourlyDebugSnapshot:
        return self._call_okx_read_with_retry(
            f"读取1小时调试值 {inst_id}",
            lambda: fetch_hourly_ema_debug(
                self._client,
                inst_id,
                ema_period=ema_period,
                trend_ema_period=trend_ema_period,
                big_ema_period=big_ema_period,
                entry_reference_ema_period=entry_reference_ema_period,
                ma_type=ma_type,
            ),
        )

    def _wait_for_write_reconcile(self, attempt: int) -> None:
        delay_seconds = min(
            OKX_WRITE_RECONCILE_BASE_DELAY_SECONDS * attempt,
            OKX_WRITE_RECONCILE_MAX_DELAY_SECONDS,
        )
        self._stop_event.wait(delay_seconds)

    def _try_get_order_status_for_write_recovery(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        label: str,
        ord_id: str | None = None,
        cl_ord_id: str | None = None,
    ) -> OkxOrderStatus | None:
        order_key = ord_id or cl_ord_id or "-"
        last_exc: OkxApiError | None = None
        for attempt in range(1, OKX_WRITE_RECONCILE_ATTEMPTS + 1):
            try:
                return self._client.get_order(
                    credentials,
                    config,
                    inst_id=inst_id,
                    ord_id=ord_id,
                    cl_ord_id=cl_ord_id,
                )
            except OkxApiError as exc:
                if _is_okx_order_not_found_error(exc):
                    return None
                last_exc = exc
                detail = str(exc).strip() or f"code={exc.code or '-'}"
                if _is_transient_okx_error(exc) and attempt < OKX_WRITE_RECONCILE_ATTEMPTS and not self._stop_event.is_set():
                    self._logger(
                        " | ".join(
                            [
                                "OKX 回查订单状态遇到读取异常，稍后重试",
                                f"操作={label}",
                                f"订单={order_key}",
                                f"第{attempt}/{OKX_WRITE_RECONCILE_ATTEMPTS}次",
                                detail,
                            ]
                        )
                    )
                    self._wait_for_write_reconcile(attempt)
                    continue
                raise
        if last_exc is not None:
            raise last_exc
        return None

    def _recover_submitted_order_result(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        cl_ord_id: str,
        label: str,
    ) -> OkxOrderResult | None:
        for attempt in range(1, OKX_WRITE_RECONCILE_ATTEMPTS + 1):
            status = self._try_get_order_status_for_write_recovery(
                credentials,
                config,
                inst_id=inst_id,
                label=label,
                cl_ord_id=cl_ord_id,
            )
            if status is not None and status.ord_id:
                return OkxOrderResult(
                    ord_id=status.ord_id,
                    cl_ord_id=cl_ord_id,
                    s_code="0",
                    s_msg="recovered via order lookup",
                    raw={
                        "recovered": True,
                        "state": status.state,
                        "order": status.raw,
                    },
                )
            if attempt < OKX_WRITE_RECONCILE_ATTEMPTS and not self._stop_event.is_set():
                self._logger(
                    " | ".join(
                        [
                            "OKX 写入异常后回查暂未命中",
                            f"操作={label}",
                            f"clOrdId={cl_ord_id}",
                            f"第{attempt}/{OKX_WRITE_RECONCILE_ATTEMPTS}次",
                        ]
                    )
                )
                self._wait_for_write_reconcile(attempt)
        return None

    @staticmethod
    def _build_okx_write_failure_message(
        *,
        label: str,
        inst_id: str,
        cl_ord_id: str,
        detail: str,
        code: str | None = None,
    ) -> str:
        normalized_detail = str(detail or "").strip() or "-"
        normalized_code = str(code or "").strip()
        code_text = f" | code={normalized_code}" if normalized_code else ""
        if normalized_code == "50101" or "current environment" in normalized_detail:
            return (
                f"OKX {label}失败 | 标的={inst_id} | clOrdId={cl_ord_id} | "
                f"原始返回={normalized_detail}{code_text} | "
                "直接原因：API Key 与当前交易环境不匹配。"
                "请检查所选 API 配置保存的是 demo 还是 live，并确保与策略 environment 一致。"
            )
        if "操作全部失败" in normalized_detail:
            return (
                f"OKX {label}被交易所拒绝 | 标的={inst_id} | clOrdId={cl_ord_id} | "
                f"原始返回={normalized_detail}{code_text} | 常见原因："
                "1) clOrdId 含非法字符；2) 保证金/可用余额不足（含模拟盘虚拟金）；"
                "3) 下单参数不合法（数量/张数步长、价格 tick、持仓模式 posSide）；"
                "4) 附带止损/止盈与主单价位或触发类型不满足 OKX 规则（可在网页端用同参试挂对照）。"
            )
        return (
            f"OKX {label}失败 | 标的={inst_id} | clOrdId={cl_ord_id} | "
            f"原始返回={normalized_detail}{code_text}"
        )

    def _submit_order_with_recovery(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        inst_id: str,
        cl_ord_id: str,
        label: str,
        submit_fn: Callable[[], OkxOrderResult],
    ) -> OkxOrderResult:
        return self._order_service.submit_order_with_recovery(
            credentials,
            config,
            inst_id=inst_id,
            cl_ord_id=cl_ord_id,
            label=label,
            submit_fn=submit_fn,
        )

    @staticmethod
    def _is_retryable_dynamic_limit_stop_attach_failure(detail: str) -> bool:
        normalized = str(detail or "").strip()
        if not normalized or "51051" not in normalized:
            return False
        lowered = normalized.lower()
        return "止损价格应低于开仓价格" in normalized or "stop loss price should be lower than" in lowered

    def _submit_dynamic_limit_entry_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        plan: OrderPlan,
        dynamic_stop_only: bool,
        trader_virtual_stop_loss_enabled: bool,
    ) -> tuple[str, OkxOrderResult, str | None] | None:
        cl_ord_id = self._next_client_order_id(role="entry")
        stop_loss_algo_cl_ord_id = (
            self._next_client_order_id(role="slg")
            if dynamic_stop_only and not trader_virtual_stop_loss_enabled
            else None
        )

        def _submit_limit_order(*, stop_loss_client_id: str | None, include_attached_protection: bool) -> OkxOrderResult:
            return self._submit_order_with_recovery(
                credentials,
                config,
                inst_id=plan.inst_id,
                cl_ord_id=cl_ord_id,
                label="动态限价挂单",
                submit_fn=lambda: self._client.place_limit_order(
                    credentials,
                    config,
                    plan,
                    cl_ord_id=cl_ord_id,
                    include_take_profit=not dynamic_stop_only,
                    stop_loss_algo_cl_ord_id=stop_loss_client_id,
                    include_attached_protection=include_attached_protection,
                ),
            )

        try:
            result = _submit_limit_order(
                stop_loss_client_id=stop_loss_algo_cl_ord_id,
                include_attached_protection=not trader_virtual_stop_loss_enabled,
            )
            return cl_ord_id, result, stop_loss_algo_cl_ord_id
        except RuntimeError as exc:
            detail = str(exc).strip()
            if not (
                dynamic_stop_only
                and not trader_virtual_stop_loss_enabled
                and self._is_retryable_dynamic_limit_stop_attach_failure(detail)
            ):
                raise

        self._logger(
            " | ".join(
                [
                    f"{_fmt_ts(plan.candle_ts)} | OKX 附带止损被拒，本次开仓已放弃",
                    f"标的={plan.inst_id}",
                    f"方向={plan.signal.upper()}",
                    f"计划开仓价={format_decimal(plan.entry_reference)}",
                    f"止损={format_decimal(plan.stop_loss)}",
                    f"clOrdId={cl_ord_id}",
                    detail,
                ]
            )
        )
        return None

    def _submit_post_fill_exchange_stop_loss(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        stop_loss: Decimal,
    ) -> tuple[str | None, str | None]:
        stop_loss_algo_cl_ord_id = self._next_client_order_id(role="slg")
        try:
            result = self._submit_order_with_recovery(
                credentials,
                config,
                inst_id=trade_instrument.inst_id,
                cl_ord_id=stop_loss_algo_cl_ord_id,
                label="初始OKX止损算法单",
                submit_fn=lambda: self._client.place_stop_loss_algo_order(
                    credentials,
                    config,
                    inst_id=trade_instrument.inst_id,
                    side=position.close_side,
                    size=position.size,
                    pos_side=position.pos_side,
                    stop_loss_trigger_price=stop_loss,
                    algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                ),
            )
        except RuntimeError as exc:
            raise RuntimeError(
                f"开仓已成交，但补挂 OKX 初始止损失败 | 标的={trade_instrument.inst_id} | {exc}"
            ) from exc
        algo_id = (result.ord_id or "").strip() or None
        algo_cl_ord_id = (result.cl_ord_id or stop_loss_algo_cl_ord_id or "").strip() or None
        return algo_id, algo_cl_ord_id

    def _ensure_exchange_stop_loss_algo(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        stop_loss: Decimal,
        stop_loss_algo_id: str | None,
        stop_loss_algo_cl_ord_id: str | None,
    ) -> tuple[str | None, str | None, bool]:
        algo_id = (stop_loss_algo_id or "").strip() or None
        algo_cl_ord_id = (stop_loss_algo_cl_ord_id or "").strip() or None
        created_after_fill = False
        if algo_id is None and algo_cl_ord_id is None:
            algo_id, algo_cl_ord_id = self._submit_post_fill_exchange_stop_loss(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                stop_loss=stop_loss,
            )
            created_after_fill = True
        return algo_id, algo_cl_ord_id, created_after_fill

    def _should_skip_startup_takeover_when_stop_crossed(
        self,
        gate_state: StartupSignalGateState,
        config: StrategyConfig,
        *,
        signal: Literal["long", "short"],
        candle_ts: int,
        trigger_inst_id: str,
        stop_loss: Decimal,
    ) -> tuple[bool, str | None]:
        current_price = self._get_trigger_price_with_retry(
            trigger_inst_id,
            config.tp_sl_trigger_type,
            environment=config.environment,
        )
        stop_crossed = current_price <= stop_loss if signal == "long" else current_price >= stop_loss
        if not stop_crossed:
            return False, None

        gate_state.blocked_signal = signal
        relation_text = "低于等于" if signal == "long" else "高于等于"
        return (
            True,
            f"{_fmt_ts(candle_ts)} | 启动追当前波段已放弃接管 | 方向={signal.upper()} | "
            f"触发价类型={config.tp_sl_trigger_type} | 当前价={format_decimal(current_price)} | "
            f"止损={format_decimal(stop_loss)} | 当前价已{relation_text}止损，等待当前波失效后再接管",
        )

    def _should_skip_dynamic_entry_when_stop_crossed(
        self,
        config: StrategyConfig,
        *,
        signal: Literal["long", "short"],
        candle_ts: int,
        trigger_inst_id: str,
        stop_loss: Decimal,
        gate_state: StartupSignalGateState | None = None,
    ) -> tuple[bool, str | None]:
        if gate_state is not None:
            return self._should_skip_startup_takeover_when_stop_crossed(
                gate_state,
                config,
                signal=signal,
                candle_ts=candle_ts,
                trigger_inst_id=trigger_inst_id,
                stop_loss=stop_loss,
            )

        current_price = self._get_trigger_price_with_retry(
            trigger_inst_id,
            config.tp_sl_trigger_type,
            environment=config.environment,
        )
        stop_crossed = current_price <= stop_loss if signal == "long" else current_price >= stop_loss
        if not stop_crossed:
            return False, None

        relation_text = "低于等于" if signal == "long" else "高于等于"
        return (
            True,
            f"{_fmt_ts(candle_ts)} | 当前动态挂单已跳过 | 方向={signal.upper()} | "
            f"触发价类型={config.tp_sl_trigger_type} | 当前价={format_decimal(current_price)} | "
            f"止损={format_decimal(stop_loss)} | 当前价已{relation_text}止损，等待当前波失效后再接管",
        )

    def _does_pending_algo_stop_loss_match(
        self,
        order: OkxTradeOrderItem | None,
        *,
        stop_loss: Decimal,
        trigger_price_type: str,
    ) -> bool:
        if order is None or order.stop_loss_trigger_price != stop_loss:
            return False
        current_type = (order.stop_loss_trigger_price_type or "").strip().lower()
        expected_type = trigger_price_type.strip().lower()
        return not current_type or current_type == expected_type

    def _amend_algo_order_with_recovery(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        algo_id: str | None,
        algo_cl_ord_id: str | None,
        req_id: str,
        new_stop_loss_trigger_price: Decimal,
        new_stop_loss_trigger_price_type: str,
        recover_algo_id: str | None = None,
        recover_algo_cl_ord_id: str | None = None,
    ) -> None:
        if not (algo_id or "").strip() and not (algo_cl_ord_id or "").strip():
            raise ValueError("amend_algo_order 需要 algo_id 或 algo_cl_ord_id")

        def _submit() -> OkxOrderResult:
            return self._client.amend_algo_order(
                credentials,
                environment=config.environment,
                inst_id=trade_instrument.inst_id,
                algo_id=(algo_id or "").strip() or None,
                algo_cl_ord_id=(algo_cl_ord_id or "").strip() or None,
                req_id=req_id,
                new_stop_loss_trigger_price=new_stop_loss_trigger_price,
                new_stop_loss_trigger_price_type=new_stop_loss_trigger_price_type,
            )

        rid = (recover_algo_id or "").strip() or (algo_id or "").strip() or None
        rcid = (recover_algo_cl_ord_id or "").strip() or (algo_cl_ord_id or "").strip() or None
        ref_log = f"algoClOrdId={rcid}" if rcid else f"algoId={rid or '-'}"

        try:
            _submit()
            return
        except OkxApiError as exc:
            if not _is_transient_okx_error(exc):
                raise
            detail = str(exc).strip() or f"code={exc.code or '-'}"
            self._logger(
                " | ".join(
                    [
                        "OKX 动态止损改单响应异常，开始回查算法单状态",
                        f"标的={trade_instrument.inst_id}",
                        ref_log,
                        f"候选止损={format_decimal(new_stop_loss_trigger_price)}",
                        detail,
                    ]
                )
            )
            recovered_order = self._find_pending_algo_order_for_dynamic_stop(
                credentials,
                config,
                trade_instrument=trade_instrument,
                algo_cl_ord_id=rcid,
                algo_id=rid,
            )
            if self._does_pending_algo_stop_loss_match(
                recovered_order,
                stop_loss=new_stop_loss_trigger_price,
                trigger_price_type=new_stop_loss_trigger_price_type,
            ):
                self._logger(
                    " | ".join(
                        [
                            "OKX 动态止损改单响应丢失，但回查显示已生效",
                            f"标的={trade_instrument.inst_id}",
                            ref_log,
                            f"新止损={format_decimal(new_stop_loss_trigger_price)}",
                        ]
                    )
                )
                return

            if self._stop_event.is_set():
                raise RuntimeError(
                    f"OKX 动态止损改单中断，且回查未确认结果 | {ref_log}"
                ) from exc

            self._logger(
                " | ".join(
                    [
                        "OKX 动态止损改单回查未确认，准备使用同一 reqId 补发一次",
                        f"标的={trade_instrument.inst_id}",
                        ref_log,
                        f"reqId={req_id}",
                    ]
                )
            )
            try:
                _submit()
                return
            except OkxApiError as retry_exc:
                recovered_order = self._find_pending_algo_order_for_dynamic_stop(
                    credentials,
                    config,
                    trade_instrument=trade_instrument,
                    algo_cl_ord_id=rcid,
                    algo_id=rid,
                )
                if self._does_pending_algo_stop_loss_match(
                    recovered_order,
                    stop_loss=new_stop_loss_trigger_price,
                    trigger_price_type=new_stop_loss_trigger_price_type,
                ):
                    self._logger(
                        " | ".join(
                            [
                                "OKX 动态止损改单补发响应异常，但回查显示已生效",
                                f"标的={trade_instrument.inst_id}",
                                ref_log,
                                f"新止损={format_decimal(new_stop_loss_trigger_price)}",
                            ]
                        )
                    )
                    return
                raise retry_exc

    def _place_entry_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        trade_instrument: Instrument,
        side: Literal["buy", "sell"],
        size: Decimal,
        pos_side: Literal["long", "short"] | None,
        *,
        cl_ord_id: str | None = None,
        label: str = "开仓报单",
    ) -> OkxOrderResult:
        return self._order_service.place_entry_order(
            credentials,
            config,
            trade_instrument,
            side,
            size,
            pos_side,
            cl_ord_id=cl_ord_id,
            label=label,
        )

    def _place_exit_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        side: Literal["buy", "sell"],
        size: Decimal,
        pos_side: Literal["long", "short"] | None,
    ) -> OkxOrderResult:
        return self._order_service.place_exit_order(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=side,
            size=size,
            pos_side=pos_side,
        )

    def _wait_for_order_fill(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        side: Literal["buy", "sell"],
        pos_side: Literal["long", "short"] | None,
        result: OkxOrderResult,
        estimated_entry: Decimal,
    ) -> FilledPosition:
        if not result.ord_id:
            raise RuntimeError("OKX 未返回 ordId，无法确认订单成交情况")

        latest_state = ""
        price_delta_multiplier = _instrument_price_delta_multiplier(trade_instrument)
        effective_pos_side = self._resolve_filled_position_pos_side(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=side,
            pos_side=pos_side,
        )
        for _ in range(12):
            status = self._get_order_with_retry(
                credentials,
                config,
                inst_id=trade_instrument.inst_id,
                ord_id=result.ord_id,
            )
            latest_state = status.state.lower()
            filled_size = status.filled_size or Decimal("0")
            if latest_state == "filled":
                return FilledPosition(
                    ord_id=result.ord_id,
                    cl_ord_id=result.cl_ord_id,
                    inst_id=trade_instrument.inst_id,
                    side=side,
                    close_side="sell" if side == "buy" else "buy",
                    pos_side=effective_pos_side,
                    size=filled_size if filled_size > 0 else status.size or Decimal("0"),
                    entry_price=status.avg_price or status.price or estimated_entry,
                    entry_ts=int(time.time() * 1000),
                    price_delta_multiplier=price_delta_multiplier,
                )
            if latest_state == "partially_filled" and filled_size > 0:
                return FilledPosition(
                    ord_id=result.ord_id,
                    cl_ord_id=result.cl_ord_id,
                    inst_id=trade_instrument.inst_id,
                    side=side,
                    close_side="sell" if side == "buy" else "buy",
                    pos_side=effective_pos_side,
                    size=filled_size,
                    entry_price=status.avg_price or status.price or estimated_entry,
                    entry_ts=int(time.time() * 1000),
                    price_delta_multiplier=price_delta_multiplier,
                )
            if latest_state in {"canceled", "order_failed"}:
                break
            self._stop_event.wait(max(config.poll_seconds / 2, 0.5))

        raise RuntimeError(f"订单未成交，ordId={result.ord_id}，状态={latest_state or 'unknown'}")

    def _resolve_filled_position_pos_side(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        side: Literal["buy", "sell"],
        pos_side: Literal["long", "short"] | None,
    ) -> Literal["long", "short"] | None:
        if pos_side in {"long", "short"}:
            return pos_side
        if trade_instrument.inst_type not in {"SWAP", "FUTURES"}:
            return pos_side
        if config.position_mode == "long_short":
            return "long" if side == "buy" else "short"
        get_account_config_cached = getattr(self._client, "_get_account_config_cached", None)
        if callable(get_account_config_cached):
            try:
                acct = get_account_config_cached(credentials, config)
            except Exception:
                acct = None
            acct_mode = (getattr(acct, "position_mode", "") or "").strip().lower()
            if acct_mode == "long_short_mode":
                return "long" if side == "buy" else "short"
            if acct_mode == "net_mode":
                return None
        return pos_side

    def _next_client_order_id(self, *, role: str) -> str:
        return self._order_service.next_client_order_id(role=role)

    def _cancel_active_order(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        active_order: ManagedEntryOrder,
        newest_ts: int,
    ) -> CancelActiveOrderResult:
        try:
            result = self._client.cancel_order(
                credentials,
                config,
                inst_id=config.inst_id,
                ord_id=active_order.ord_id,
            )
            self._logger(
                f"{_fmt_ts(newest_ts)} | 新 K 线已确认，撤掉旧挂单 | ordId={result.ord_id or active_order.ord_id}"
            )
            return CancelActiveOrderResult("canceled")
        except OkxApiError as exc:
            detail = str(exc).strip() or f"code={exc.code or '-'}"
            latest_status: OkxOrderStatus | None = None
            recover_message = "OKX 撤单请求响应异常，开始回查订单状态" if _is_transient_okx_error(exc) else "OKX 撤单失败，开始回查订单状态"
            self._logger(
                " | ".join(
                    [
                        recover_message,
                        f"ordId={active_order.ord_id}",
                        detail,
                    ]
                )
            )
            latest_status = self._try_get_order_status_for_write_recovery(
                credentials,
                config,
                inst_id=config.inst_id,
                label="撤单回查",
                ord_id=active_order.ord_id,
            )
            if latest_status is not None and latest_status.state.lower() == "canceled":
                self._logger(f"{_fmt_ts(newest_ts)} | 旧挂单已确认撤单，继续按最新 EMA 重挂。")
                return CancelActiveOrderResult("canceled", latest_status)
            if latest_status is not None and latest_status.state.lower() == "filled":
                return CancelActiveOrderResult("filled", latest_status)
            if latest_status is not None and latest_status.state.lower() == "partially_filled":
                return CancelActiveOrderResult("partially_filled", latest_status)

            if not self._stop_event.is_set() and (
                latest_status is None or latest_status.state.lower() == "live"
            ):
                self._logger(
                    " | ".join(
                        [
                            "OKX 撤单回查未确认完成，准备补发一次撤单",
                            f"ordId={active_order.ord_id}",
                        ]
                    )
                )
                try:
                    result = self._client.cancel_order(
                        credentials,
                        config,
                        inst_id=config.inst_id,
                        ord_id=active_order.ord_id,
                    )
                    self._logger(
                        f"{_fmt_ts(newest_ts)} | 新 K 线已确认，撤掉旧挂单 | ordId={result.ord_id or active_order.ord_id}"
                    )
                    return CancelActiveOrderResult("canceled")
                except OkxApiError as retry_exc:
                    detail = str(retry_exc).strip() or f"code={retry_exc.code or '-'}"
                    latest_status = self._try_get_order_status_for_write_recovery(
                        credentials,
                        config,
                        inst_id=config.inst_id,
                        label="撤单回查",
                        ord_id=active_order.ord_id,
                    )
                    if latest_status is not None and latest_status.state.lower() == "canceled":
                        self._logger(f"{_fmt_ts(newest_ts)} | 旧挂单已确认撤单，继续按最新 EMA 重挂。")
                        return CancelActiveOrderResult("canceled", latest_status)
                    if latest_status is not None and latest_status.state.lower() == "filled":
                        return CancelActiveOrderResult("filled", latest_status)
                    if latest_status is not None and latest_status.state.lower() == "partially_filled":
                        return CancelActiveOrderResult("partially_filled", latest_status)

            if latest_status is not None:
                state = latest_status.state.lower()
                if state == "live":
                    self._logger(
                        " | ".join(
                            [
                                "撤单暂未完成，保留旧挂单继续回查",
                                f"ordId={active_order.ord_id}",
                                f"状态={latest_status.state}",
                                detail,
                            ]
                        )
                    )
                    return CancelActiveOrderResult("pending", latest_status)
                self._logger(
                    f"{_fmt_ts(newest_ts)} | 旧挂单状态已变更为 {latest_status.state}，继续按最新 EMA 重挂。"
                )
                return CancelActiveOrderResult("canceled", latest_status)

            try:
                pending_order = self._find_pending_entry_order(
                    credentials,
                    config,
                    inst_id=config.inst_id,
                    ord_id=active_order.ord_id,
                    cl_ord_id=active_order.cl_ord_id,
                )
            except Exception as pending_exc:
                pending_detail = str(pending_exc).strip() or pending_exc.__class__.__name__
                self._logger(
                    " | ".join(
                        [
                            "撤单结果暂未确认，挂单列表回查失败，保留旧挂单继续回查",
                            f"ordId={active_order.ord_id}",
                            pending_detail,
                        ]
                    )
                )
                return CancelActiveOrderResult("pending")

            if pending_order is not None:
                pending_state = (pending_order.state or "live").strip() or "live"
                self._logger(
                    " | ".join(
                        [
                            "撤单结果暂未确认，旧挂单仍在待成交列表，保留继续回查",
                            f"ordId={active_order.ord_id}",
                            f"状态={pending_state}",
                            detail,
                        ]
                    )
                )
                return CancelActiveOrderResult("pending")

            self._logger(
                " | ".join(
                    [
                        "撤单结果暂未确认，挂单列表已找不到旧单，先等待下一轮状态同步",
                        f"ordId={active_order.ord_id}",
                        detail,
                    ]
                )
            )
            return CancelActiveOrderResult("pending")

    def _manage_filled_dynamic_entry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        active_order: ManagedEntryOrder,
        status: OkxOrderStatus,
        newest_ts: int,
        dynamic_stop_only: bool,
    ) -> None:
        filled_price = status.avg_price or status.price or active_order.entry_reference
        filled_size = status.filled_size or status.size or active_order.size
        ord_id = status.ord_id or active_order.ord_id
        price_delta_multiplier = _instrument_price_delta_multiplier(trade_instrument)
        recovered_pos_side = self._resolve_filled_position_pos_side(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=active_order.side,
            pos_side=resolve_open_pos_side(config, active_order.side),
        )
        if config.trader_virtual_stop_loss:
            self._logger(
                f"{_fmt_ts(newest_ts)} | 挂单已成交 | ordId={ord_id} | "
                f"开仓价={_format_notify_price_by_tick_size(filled_price, trade_instrument.tick_size)} | "
                f"数量={_format_size_with_contract_equivalent(trade_instrument, filled_size)}"
            )
            self._notify_trade_fill(
                config,
                title="开仓委托成交",
                symbol=config.inst_id,
                side=active_order.side,
                size=filled_size,
                size_text=_format_notify_size_with_unit(trade_instrument, filled_size),
                price=filled_price,
                tick_size=trade_instrument.tick_size,
                reason="交易员模式已开仓：止损价仅作触发参考，不向 OKX 挂真实止损。",
            )
            position = FilledPosition(
                ord_id=ord_id,
                cl_ord_id=active_order.cl_ord_id,
                inst_id=trade_instrument.inst_id,
                side=active_order.side,
                close_side="sell" if active_order.side == "buy" else "buy",
                pos_side=recovered_pos_side,
                size=filled_size,
                entry_price=filled_price,
                entry_ts=int(time.time() * 1000),
                price_delta_multiplier=price_delta_multiplier,
            )
            self._monitor_trader_virtual_position(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                initial_stop_loss=active_order.stop_loss,
                take_profit=active_order.take_profit,
                dynamic_take_profit_enabled=dynamic_stop_only,
            )
            return
        self._logger(
            f"{_fmt_ts(newest_ts)} | 挂单已成交 | ordId={ord_id} | "
            f"开仓价={_format_notify_price_by_tick_size(filled_price, trade_instrument.tick_size)} | "
            f"数量={_format_size_with_contract_equivalent(trade_instrument, filled_size)}"
        )
        fill_reason = (
            "EMA 动态委托已成交，初始止损已交给 OKX 托管，后续将动态上移"
            if dynamic_stop_only
            else "EMA 动态委托已成交，止盈止损已交给 OKX 托管"
        )
        self._notify_trade_fill(
            config,
            title="开仓委托成交",
            symbol=config.inst_id,
            side=active_order.side,
            size=filled_size,
            size_text=_format_notify_size_with_unit(trade_instrument, filled_size),
            price=filled_price,
            tick_size=trade_instrument.tick_size,
            reason=fill_reason,
        )
        position = FilledPosition(
            ord_id=ord_id,
            cl_ord_id=active_order.cl_ord_id,
            inst_id=trade_instrument.inst_id,
            side=active_order.side,
            close_side="sell" if active_order.side == "buy" else "buy",
            pos_side=recovered_pos_side,
            size=filled_size,
            entry_price=filled_price,
            entry_ts=int(time.time() * 1000),
            price_delta_multiplier=price_delta_multiplier,
        )
        if dynamic_stop_only:
            stop_loss_algo_id, stop_loss_algo_cl_ord_id, created_after_fill = self._ensure_exchange_stop_loss_algo(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                stop_loss=active_order.stop_loss,
                stop_loss_algo_id=active_order.stop_loss_algo_id,
                stop_loss_algo_cl_ord_id=active_order.stop_loss_algo_cl_ord_id,
            )
            self._logger(
                f"{'初始 OKX 止损已补挂' if created_after_fill else '初始 OKX 止损已提交'} | "
                f"algoClOrdId={stop_loss_algo_cl_ord_id or '-'} | algoId={stop_loss_algo_id or '-'} | "
                f"止损={format_decimal(active_order.stop_loss)} | 启动动态上移监控"
            )
            self._monitor_exchange_dynamic_stop(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                initial_stop_loss=active_order.stop_loss,
                stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                stop_loss_algo_id=stop_loss_algo_id,
            )
        else:
            self._logger("止盈止损已附加到 OKX 主单，开始监控持仓是否结束。")
            self._monitor_exchange_managed_position_until_closed(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
            )

    def _monitor_trader_virtual_position(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        initial_stop_loss: Decimal,
        take_profit: Decimal,
        dynamic_take_profit_enabled: bool,
    ) -> None:
        direction: Literal["long", "short"] = "long" if position.side == "buy" else "short"
        current_stop_loss = initial_stop_loss
        current_take_profit = take_profit
        next_trigger_r = _live_dynamic_initial_trigger_r(config)
        risk_per_unit = abs(position.entry_price - initial_stop_loss)
        next_trigger_price_text = _dynamic_next_trigger_price_text(
            direction=direction,
            entry_price=position.entry_price,
            risk_per_unit=risk_per_unit,
            next_trigger_r=next_trigger_r,
            tick_size=trade_instrument.tick_size,
            dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
        )
        virtual_loss_logged = False
        trend_ema_close_exit_enabled = (
            direction == "long"
            and dynamic_take_profit_enabled
            and _live_trend_ema_close_exit_after_trigger_r_enabled(config)
        )
        trend_ema_close_exit_armed = False
        trend_ema_close_exit_last_candle_ts: int | None = None
        signal_inst_id = (config.inst_id or trade_instrument.inst_id).strip().upper() or trade_instrument.inst_id
        monitor_parts = [
            f"交易员虚拟止损监控启动 | 标的={trade_instrument.inst_id}",
            f"触发价格类型={config.tp_sl_trigger_type}",
            f"策略止损={format_decimal(initial_stop_loss)}",
        ]
        if dynamic_take_profit_enabled:
            monitor_parts.extend(
                [
                    "止盈方式=动态",
                    _live_dynamic_break_even_summary(config),
                    f"下一次上移阶段={next_trigger_r}R",
                    f"下一次上移触发价={next_trigger_price_text}",
                    f"手续费偏移={config.dynamic_fee_offset_enabled_label()}",
                    f"时间保本={config.time_stop_break_even_enabled_label()}/{config.resolved_time_stop_break_even_bars()}根",
                ]
            )
        else:
            monitor_parts.append(f"固定止盈={format_decimal(take_profit)}")
        self._logger(" | ".join(monitor_parts))

        while not self._stop_event.is_set():
            live_position = self._find_managed_position(credentials, config, trade_instrument, position)
            if live_position is None:
                self._logger("未检测到策略持仓，交易员虚拟止损监控结束。")
                return

            current_price = self._get_trigger_price_with_retry(
                trade_instrument.inst_id,
                config.tp_sl_trigger_type,
                environment=config.environment,
            )
            if dynamic_take_profit_enabled:
                holding_bars = _holding_bars_live(position.entry_ts, int(time.time() * 1000), config.bar)
                updated_stop_loss, next_trigger_price, updated_trigger_r, moved = _advance_dynamic_stop_live(
                    direction=direction,
                    current_price=current_price,
                    entry_price=position.entry_price,
                    risk_per_unit=risk_per_unit,
                    current_stop_loss=current_stop_loss,
                    next_trigger_r=next_trigger_r,
                    tick_size=trade_instrument.tick_size,
                    two_r_break_even=_live_ema55_slope_dynamic_two_r_break_even_enabled(config),
                    break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
                    trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
                    first_lock_r=_live_dynamic_first_lock_r(config),
                    trailing_step_r=_live_dynamic_trailing_step_r(config),
                    separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
                    dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
                    dynamic_protection_rules=_live_dynamic_protection_rules(config),
                    holding_bars=holding_bars,
                    time_stop_break_even_enabled=config.time_stop_break_even_enabled,
                    time_stop_break_even_bars=config.resolved_time_stop_break_even_bars(),
                )
                if moved:
                    current_stop_loss = updated_stop_loss
                    current_take_profit = next_trigger_price
                    next_trigger_r = updated_trigger_r
                    self._logger(
                        f"交易员动态止盈保护价已上移 | 当前价={format_decimal(current_price)} | "
                        f"新保护价={format_decimal(current_stop_loss)} | 下一阶段={next_trigger_r}R | "
                        f"下一次上移触发价={_dynamic_next_trigger_price_text(direction=direction, entry_price=position.entry_price, risk_per_unit=risk_per_unit, next_trigger_r=next_trigger_r, tick_size=trade_instrument.tick_size, dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config))} | "
                        f"holding_bars={holding_bars}"
                    )
                if trend_ema_close_exit_enabled:
                    trend_ema_close_exit_armed = trend_ema_close_exit_armed or _live_dynamic_trigger_r_reached(
                        direction=direction,
                        current_price=current_price,
                        entry_price=position.entry_price,
                        risk_per_unit=risk_per_unit,
                        next_trigger_r=next_trigger_r,
                        trigger_r=_live_trend_ema_close_exit_trigger_r(config),
                        tick_size=trade_instrument.tick_size,
                        dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
                    )
            else:
                _, take_hit = evaluate_local_exit(
                    direction=direction,
                    current_price=current_price,
                    stop_loss=current_stop_loss,
                    take_profit=current_take_profit,
                )
                if take_hit:
                    self._logger(
                        f"交易员固定止盈已触发 | 当前价={format_decimal(current_price)} | "
                        f"止盈={format_decimal(current_take_profit)} | 开始平仓释放额度"
                    )
                    self._close_position(credentials, config, trade_instrument, position, "止盈")
                    return

            if trend_ema_close_exit_enabled and trend_ema_close_exit_armed:
                exit_ready, trend_ema_close_exit_last_candle_ts, exit_candle, trend_ema_value = (
                    self._poll_trend_ema_close_exit_snapshot(
                        config,
                        signal_inst_id=signal_inst_id,
                        direction=direction,
                        last_checked_candle_ts=trend_ema_close_exit_last_candle_ts,
                    )
                )
                if exit_ready and exit_candle is not None and trend_ema_value is not None:
                    trend_label = config.trend_ema_label()
                    self._logger(
                        f"{_fmt_ts(exit_candle.ts)} | 达到 {_live_trend_ema_close_exit_trigger_r(config)}R 后收盘跌破 {trend_label} 平仓 | "
                        f"收盘={format_decimal(exit_candle.close)} | {trend_label}={format_decimal(trend_ema_value)}"
                    )
                    self._close_position(credentials, config, trade_instrument, position, f"跌破{trend_label}")
                    return

            stop_hit = current_price <= current_stop_loss if direction == "long" else current_price >= current_stop_loss
            if stop_hit:
                if _is_profit_protecting_stop(
                    direction=direction,
                    entry_price=position.entry_price,
                    stop_loss=current_stop_loss,
                ):
                    self._logger(
                        f"交易员动态止盈保护价触发 | 当前价={format_decimal(current_price)} | "
                        f"保护价={format_decimal(current_stop_loss)} | 开始平仓释放额度"
                    )
                    self._close_position(credentials, config, trade_instrument, position, "动态止盈")
                    return
                if not virtual_loss_logged:
                    self._logger(
                        f"交易员虚拟止损已触发（不平仓） | 当前价={format_decimal(current_price)} | "
                        f"策略止损={format_decimal(current_stop_loss)} | 保留仓位等待后续止盈/人工处理"
                    )
                    virtual_loss_logged = True

            self._stop_event.wait(config.poll_seconds)

    def _handle_partial_dynamic_entry(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        active_order: ManagedEntryOrder,
        status: OkxOrderStatus,
        newest_ts: int,
        dynamic_stop_only: bool,
    ) -> bool:
        ord_id = status.ord_id or active_order.ord_id
        cancel_result = self._cancel_active_order(credentials, config, active_order, newest_ts)
        if cancel_result.action == "pending":
            self._logger(
                f"{_fmt_ts(newest_ts)} | 挂单部分成交 | ordId={ord_id} | "
                "剩余委托撤单尚未确认，策略状态=部分成交管理中，继续等待撤单回查。"
            )
            return False
        latest_status = cancel_result.status
        if cancel_result.action == "filled":
            if latest_status is None:
                raise RuntimeError(f"部分成交后撤单回查缺少订单状态，ordId={active_order.ord_id}")
            self._logger(
                f"{_fmt_ts(newest_ts)} | 挂单部分成交后已全部成交 | ordId={latest_status.ord_id or active_order.ord_id} | "
                "剩余委托已在撤单前全部成交，转为完整持仓管理。"
            )
            self._manage_filled_dynamic_entry(
                credentials,
                config,
                trade_instrument=trade_instrument,
                active_order=active_order,
                status=latest_status,
                newest_ts=newest_ts,
                dynamic_stop_only=dynamic_stop_only,
            )
            return True

        pending_entry = self._find_pending_entry_order(
            credentials,
            config,
            inst_id=config.inst_id,
            ord_id=active_order.ord_id,
            cl_ord_id=active_order.cl_ord_id,
        )
        if pending_entry is not None:
            self._logger(
                f"{_fmt_ts(newest_ts)} | 挂单部分成交 | ordId={ord_id} | "
                "检测到剩余委托仍在挂单，策略状态=部分成交管理中，继续等待撤单完成后再接管已成交仓位。"
            )
            return False

        if latest_status is None:
            latest_status = self._try_get_order_status_for_write_recovery(
                credentials,
                config,
                inst_id=config.inst_id,
                label="部分成交回查",
                ord_id=active_order.ord_id,
                cl_ord_id=active_order.cl_ord_id,
            )
        latest_status = latest_status or status
        if latest_status.state.lower() == "live":
            self._logger(
                f"{_fmt_ts(newest_ts)} | 挂单部分成交 | ordId={ord_id} | "
                "订单状态仍为 live，策略状态=部分成交管理中，继续等待交易所完成撤单同步。"
            )
            return False

        filled_price = latest_status.avg_price or latest_status.price or active_order.entry_reference
        filled_size = latest_status.filled_size or latest_status.size or active_order.size
        recovered_pos_side = self._resolve_filled_position_pos_side(
            credentials,
            config,
            trade_instrument=trade_instrument,
            side=active_order.side,
            pos_side=resolve_open_pos_side(config, active_order.side),
        )
        position = FilledPosition(
            ord_id=latest_status.ord_id or ord_id,
            cl_ord_id=active_order.cl_ord_id,
            inst_id=trade_instrument.inst_id,
            side=active_order.side,
            close_side="sell" if active_order.side == "buy" else "buy",
            pos_side=recovered_pos_side,
            size=filled_size,
            entry_price=filled_price,
            entry_ts=int(time.time() * 1000),
            price_delta_multiplier=_instrument_price_delta_multiplier(trade_instrument),
        )
        self._logger(
            f"{_fmt_ts(newest_ts)} | 挂单部分成交 | ordId={position.ord_id} | "
            f"开仓价={_format_notify_price_by_tick_size(filled_price, trade_instrument.tick_size)} | "
            f"数量={_format_size_with_contract_equivalent(trade_instrument, filled_size)} | "
            "策略状态=部分成交管理中 | 剩余委托已收口，开始仅管理已成交仓位。"
        )
        self._notify_trade_fill(
            config,
            title="开仓委托部分成交",
            symbol=config.inst_id,
            side=active_order.side,
            size=filled_size,
            size_text=_format_notify_size_with_unit(trade_instrument, filled_size),
            price=filled_price,
            tick_size=trade_instrument.tick_size,
            reason=(
                "开仓委托部分成交，剩余委托已撤销，开始仅管理已成交仓位；交易员虚拟止损仅作触发参考，不向 OKX 挂真实止损。"
                if config.trader_virtual_stop_loss
                else (
                    "开仓委托部分成交，剩余委托已撤销，开始仅管理已成交仓位；初始止损已交给 OKX 托管，后续将动态上移。"
                    if dynamic_stop_only
                    else "开仓委托部分成交，剩余委托已撤销，开始仅管理已成交仓位；止盈止损已交给 OKX 托管。"
                )
            ),
        )
        if config.trader_virtual_stop_loss:
            self._monitor_trader_virtual_position(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                initial_stop_loss=active_order.stop_loss,
                take_profit=active_order.take_profit,
                dynamic_take_profit_enabled=dynamic_stop_only,
            )
            return True
        if dynamic_stop_only:
            stop_loss_algo_id, stop_loss_algo_cl_ord_id, created_after_fill = self._ensure_exchange_stop_loss_algo(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                stop_loss=active_order.stop_loss,
                stop_loss_algo_id=active_order.stop_loss_algo_id,
                stop_loss_algo_cl_ord_id=active_order.stop_loss_algo_cl_ord_id,
            )
            stop_loss_label = "初始 OKX 止损已补挂" if created_after_fill else "初始 OKX 止损已提交"
            self._logger(
                f"{stop_loss_label} | algoClOrdId={stop_loss_algo_cl_ord_id or '-'} | "
                f"algoId={stop_loss_algo_id or '-'} | 止损={format_decimal(active_order.stop_loss)} | 启动动态上移监控"
            )
            self._monitor_exchange_dynamic_stop(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                initial_stop_loss=active_order.stop_loss,
                stop_loss_algo_cl_ord_id=stop_loss_algo_cl_ord_id,
                stop_loss_algo_id=stop_loss_algo_id,
            )
            return True

        self._logger("止盈止损已附加到 OKX 主单，开始监控持仓是否结束。")
        self._monitor_exchange_managed_position_until_closed(
            credentials,
            config,
            trade_instrument=trade_instrument,
            position=position,
        )
        return True

    def _log_strategy_start(
        self,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        message = (
            f"启动策略 | 信号标的={signal_instrument.inst_id} | 下单标的={trade_instrument.inst_id} | "
            f"K线周期={config.bar} | 快线均线={config.ema_label()} | ATR={config.atr_period}"
        )
        if get_strategy_runtime_profile(config.strategy_id).family in {"dynamic_order", "cross_breakout_long", "cross_breakdown_short", "cross_legacy"}:
            message = (
                f"{message} | 趋势均线={config.trend_ema_label()} | 挂单参考线={config.entry_reference_line_label()}"
            )
        if config.uses_daily_filter():
            message = f"{message} | {config.daily_filter_summary()}"
        self._logger(message)

    def _log_local_mode_summary(
        self,
        config: StrategyConfig,
        signal_instrument: Instrument,
        trade_instrument: Instrument,
    ) -> None:
        tp_sl_inst = resolve_tp_sl_inst_id(config, signal_instrument.inst_id, trade_instrument.inst_id)
        self._logger(
            f"运行模式：本地下单 / 本地止盈止损 | 信号标的={signal_instrument.inst_id} | "
            f"下单标的={trade_instrument.inst_id} | 止盈止损触发标的={tp_sl_inst}"
        )
        self._logger(
            f"下单方向模式={format_entry_side_mode(config.entry_side_mode)} | "
            f"止盈止损触发价类型={config.tp_sl_trigger_type}"
        )

    def _log_hourly_debug(
        self,
        inst_id: str,
        ema_period: int,
        *,
        current_bar: str = "",
        trend_ema_period: int = 0,
        big_ema_period: int = 0,
        entry_reference_ema_period: int = 0,
        ma_type: str = "ema",
    ) -> None:
        normalized_bar = str(current_bar or "").strip()
        if normalized_bar and normalized_bar.upper() != "1H":
            return
        try:
            hourly_snapshot = self._fetch_hourly_debug_snapshot_with_retry(
                inst_id,
                ema_period=ema_period,
                trend_ema_period=trend_ema_period,
                big_ema_period=big_ema_period,
                entry_reference_ema_period=entry_reference_ema_period,
                ma_type=ma_type,
            )
            self._logger(format_hourly_debug(inst_id, hourly_snapshot, trading_bar=current_bar))
        except Exception as exc:
            if normalized_bar and normalized_bar.upper() != "1H":
                self._logger(f"1H参考调试值获取失败（当前交易周期={normalized_bar}）：{exc}")
            else:
                self._logger(f"1H调试值获取失败：{exc}")

    def _notify_signal(
        self,
        config: StrategyConfig,
        *,
        signal: Literal["long", "short"],
        trigger_symbol: str,
        entry_reference: Decimal,
        tick_size: Decimal | None = None,
        reason: str,
    ) -> None:
        if self._notifier is None:
            self._logger(f"邮件未发送 | 类型=信号 | 会话={self._session_id or '-'} | 原因=邮件通知器未创建")
            return
        entry_reference_text = _format_notify_price_by_tick_size(entry_reference, tick_size)
        reason_for_email = reason
        if config.run_mode == "signal_only":
            reason_for_email = f"{reason}\n{_take_profit_mode_description_for_signal_email(config)}"
        self._notifier.send_signal(
            strategy_name=self._strategy_name,
            config=config,
            signal=signal,
            trigger_symbol=trigger_symbol,
            entry_reference=entry_reference_text,
            reason=reason_for_email,
            api_name=self._api_name,
            session_id=self._session_id,
            trader_id=self._trader_id,
            direction_label=self._direction_label,
            run_mode_label=self._run_mode_label,
        )

    def _notify_trade_fill(
        self,
        config: StrategyConfig,
        *,
        title: str,
        symbol: str,
        side: str,
        size: Decimal,
        size_text: str = "",
        price: Decimal,
        tick_size: Decimal | None = None,
        reason: str,
        trade_pnl: str = "",
    ) -> None:
        if self._notifier is None:
            self._logger(f"邮件未发送 | 类型=成交 | 会话={self._session_id or '-'} | 原因=邮件通知器未创建")
            return
        self._notifier.send_trade_fill(
            strategy_name=self._strategy_name,
            config=config,
            title=title,
            symbol=symbol,
            side=side,
            size=size_text or format_decimal(size),
            price=_format_notify_price_by_tick_size(price, tick_size),
            reason=reason,
            trade_pnl=trade_pnl,
            api_name=self._api_name,
            session_id=self._session_id,
            trader_id=self._trader_id,
            direction_label=self._direction_label,
            run_mode_label=self._run_mode_label,
        )

    def _notify_trade_close(
        self,
        config: StrategyConfig,
        *,
        symbol: str,
        side: str,
        size: Decimal,
        entry_price: Decimal,
        trigger_reason: str,
        detail: str,
        exit_price: Decimal | None = None,
        tick_size: Decimal | None = None,
        trade_pnl: str = "",
        price_label: str = "平仓价格",
        size_text: str = "",
        stop_execution_status: str = "",
        stop_execution_summary: str = "",
    ) -> None:
        if self._notifier is None:
            self._logger(f"邮件未发送 | 类型=平仓 | 会话={self._session_id or '-'} | 原因=邮件通知器未创建")
            return
        self._notifier.send_trade_close(
            strategy_name=self._strategy_name,
            config=config,
            symbol=symbol,
            side=side,
            size=size_text or format_decimal(size),
            entry_price=_format_notify_price_by_tick_size(entry_price, tick_size),
            exit_price=_format_notify_price_by_tick_size(exit_price, tick_size) if exit_price is not None else "",
            trigger_reason=trigger_reason,
            detail=detail,
            trade_pnl=trade_pnl,
            api_name=self._api_name,
            session_id=self._session_id,
            trader_id=self._trader_id,
            direction_label=self._direction_label,
            run_mode_label=self._run_mode_label,
            price_label=price_label,
            stop_execution_status=stop_execution_status,
            stop_execution_summary=stop_execution_summary,
        )

    def _notify_exchange_dynamic_stop_close(
        self,
        credentials: Credentials,
        config: StrategyConfig,
        *,
        trade_instrument: Instrument,
        position: FilledPosition,
        initial_stop_loss: Decimal,
        current_stop_loss: Decimal,
        risk_per_unit: Decimal,
        next_trigger_r: int,
        detail: str,
    ) -> None:
        direction: Literal["long", "short"] = "long" if position.side == "buy" else "short"
        trigger_reason = _classify_live_dynamic_close_reason(
            direction=direction,
            entry_price=position.entry_price,
            initial_stop_loss=initial_stop_loss,
            current_stop_loss=current_stop_loss,
            risk_per_unit=risk_per_unit,
            next_trigger_r=next_trigger_r,
            tick_size=trade_instrument.tick_size,
            two_r_break_even=_live_ema55_slope_dynamic_two_r_break_even_enabled(config),
            dynamic_fee_offset_enabled=_live_ema55_slope_dynamic_fee_offset_enabled(config),
            time_stop_break_even_enabled=config.time_stop_break_even_enabled,
            break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
            trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
            first_lock_r=_live_dynamic_first_lock_r(config),
            trailing_step_r=_live_dynamic_trailing_step_r(config),
            separate_break_even_enabled=_live_dynamic_separate_break_even_enabled(config),
            dynamic_protection_rules=_live_dynamic_protection_rules(config),
        )
        history_item = self._lookup_recent_position_close_history(
            credentials,
            config,
            trade_instrument=trade_instrument,
            position=position,
            exit_price=current_stop_loss,
            close_ms=int(time.time() * 1000),
        )
        assessment = None
        actual_exit_price = history_item.close_avg_price if history_item is not None else None
        if "止损" in trigger_reason and actual_exit_price is not None:
            assessment = assess_stop_execution(
                direction=direction,
                entry_price=position.entry_price,
                initial_stop_price=initial_stop_loss,
                effective_stop_price=current_stop_loss,
                actual_exit_price=actual_exit_price,
                size=position.size,
                price_delta_multiplier=self._resolve_trade_fill_price_delta_multiplier(
                    position,
                    trade_instrument=trade_instrument,
                ),
                actual_price_loss_usdt=history_item.pnl,
            )
        execution_summary = format_stop_execution_summary(assessment) if assessment is not None else ""
        if execution_summary:
            self._logger(execution_summary)
        self._notify_trade_close(
            config,
            symbol=trade_instrument.inst_id,
            side=position.close_side,
            size=position.size,
            size_text=_format_notify_size_with_unit(trade_instrument, position.size),
            entry_price=position.entry_price,
            exit_price=actual_exit_price or current_stop_loss,
            tick_size=trade_instrument.tick_size,
            trigger_reason=trigger_reason,
            detail=detail,
            trade_pnl=self._position_history_total_net_pnl_text(
                credentials,
                config,
                trade_instrument=trade_instrument,
                position=position,
                history_item=history_item,
            ),
            price_label="实际平仓均价" if actual_exit_price is not None else "触发止损价",
            stop_execution_status=assessment.status if assessment is not None else "",
            stop_execution_summary=execution_summary,
        )

    @staticmethod
    def _trade_fill_pnl_text_for_close(
        position: FilledPosition,
        *,
        fill_size: Decimal,
        fill_price: Decimal,
        trade_instrument: Instrument | None = None,
    ) -> str:
        matched_size = min(abs(fill_size), abs(position.size))
        if matched_size <= 0:
            return ""
        price_delta_multiplier = StrategyEngine._resolve_trade_fill_price_delta_multiplier(
            position,
            trade_instrument=trade_instrument,
        )
        if position.side == "buy":
            pnl = (fill_price - position.entry_price) * matched_size * price_delta_multiplier
        else:
            pnl = (position.entry_price - fill_price) * matched_size * price_delta_multiplier
        return format_decimal(pnl)

    @staticmethod
    def _resolve_trade_fill_price_delta_multiplier(
        position: FilledPosition,
        trade_instrument: Instrument | None = None,
    ) -> Decimal:
        if trade_instrument is not None:
            instrument_multiplier = _instrument_price_delta_multiplier(trade_instrument)
            if trade_instrument.inst_type not in {"SWAP", "FUTURES", "OPTION"}:
                return instrument_multiplier if instrument_multiplier > 0 else Decimal("1")
            if trade_instrument.ct_val is not None and trade_instrument.ct_val > 0 and instrument_multiplier > 0:
                return instrument_multiplier
        if position.price_delta_multiplier > 0:
            return position.price_delta_multiplier
        return Decimal("1")

    def _notify_error(self, config: StrategyConfig | None, message: str) -> None:
        if self._notifier is None:
            self._logger(f"邮件未发送 | 类型=异常 | 会话={self._session_id or '-'} | 原因=邮件通知器未创建")
            return
        self._notifier.send_error(
            strategy_name=self._strategy_name,
            config=config,
            message=message,
            api_name=self._api_name,
            session_id=self._session_id,
            trader_id=self._trader_id,
            direction_label=self._direction_label,
            run_mode_label=self._run_mode_label,
        )


def can_use_exchange_managed_orders(
    config: StrategyConfig,
    signal_instrument: Instrument,
    trade_instrument: Instrument,
) -> bool:
    return (
        config.tp_sl_mode == "exchange"
        and signal_instrument.inst_id == trade_instrument.inst_id
        and trade_instrument.inst_type == "SWAP"
    )


def supports_fixed_entry_side_mode(strategy_id: str, run_mode: str, tp_sl_mode: str) -> bool:
    normalized_run_mode = str(run_mode or "").strip().lower()
    normalized_tp_sl_mode = str(tp_sl_mode or "").strip().lower()
    return (
        normalized_run_mode == "trade"
        and not strategy_forces_follow_signal(strategy_id)
        and normalized_tp_sl_mode == "local_trade"
    )


def fixed_entry_side_mode_support_reason(strategy_id: str, run_mode: str, tp_sl_mode: str) -> str | None:
    if supports_fixed_entry_side_mode(strategy_id, run_mode, tp_sl_mode):
        return None
    normalized_run_mode = str(run_mode or "").strip().lower()
    normalized_tp_sl_mode = str(tp_sl_mode or "").strip().lower()
    if normalized_run_mode != "trade":
        return "只发信号邮件模式不下单，下单方向模式已固定为跟随信号。"
    if strategy_forces_follow_signal(strategy_id):
        return "当前策略只支持跟随信号。"
    if normalized_tp_sl_mode == "exchange":
        return "OKX 托管模式当前只支持跟随信号；如需固定买入/固定卖出，请切到按交易标的价格（本地）。"
    if normalized_tp_sl_mode == "local_signal":
        return "按信号标的价格（本地）当前只支持跟随信号；如需固定买入/固定卖出，请切到按交易标的价格（本地）。"
    if normalized_tp_sl_mode == "local_custom":
        return "按自定义标的价格（本地）当前只支持跟随信号；如需固定买入/固定卖出，请切到按交易标的价格（本地）。"
    return "当前模式仅支持跟随信号。"


def validate_entry_side_mode_support(config: StrategyConfig) -> None:
    if config.entry_side_mode == "follow_signal":
        return
    reason = fixed_entry_side_mode_support_reason(config.strategy_id, config.run_mode, config.tp_sl_mode)
    if reason:
        raise RuntimeError(reason)


def resolve_trade_inst_id(config: StrategyConfig) -> str:
    return (config.trade_inst_id or config.inst_id).strip().upper()


def resolve_tp_sl_inst_id(config: StrategyConfig, signal_inst_id: str, trade_inst_id: str) -> str:
    if config.tp_sl_mode in {"exchange", "local_trade"}:
        return trade_inst_id
    if config.tp_sl_mode == "local_signal":
        return signal_inst_id
    trigger_inst_id = (config.local_tp_sl_inst_id or "").strip().upper()
    if not trigger_inst_id:
        raise RuntimeError("已选择自定义本地止盈止损，但没有填写触发标的")
    return trigger_inst_id


def resolve_entry_side(signal: str, entry_side_mode: str) -> Literal["buy", "sell"]:
    if entry_side_mode == "follow_signal":
        return "buy" if signal == "long" else "sell"
    if entry_side_mode == "fixed_buy":
        return "buy"
    if entry_side_mode == "fixed_sell":
        return "sell"
    raise RuntimeError(f"不支持的下单方向模式：{entry_side_mode}")


def resolve_open_pos_side(
    config: StrategyConfig,
    trade_side: Literal["buy", "sell"],
) -> Literal["long", "short"] | None:
    if config.position_mode != "long_short":
        return None
    return "long" if trade_side == "buy" else "short"


def local_entry_trigger_hit(signal: str, current_price: Decimal, target_price: Decimal) -> bool:
    return current_price <= target_price if signal == "long" else current_price >= target_price


def evaluate_local_exit(
    *,
    direction: Literal["long", "short"],
    current_price: Decimal,
    stop_loss: Decimal,
    take_profit: Decimal,
) -> tuple[bool, bool]:
    if direction == "long":
        return current_price <= stop_loss, current_price >= take_profit
    return current_price >= stop_loss, current_price <= take_profit


def _dynamic_two_taker_fee_offset_live(
    entry_price: Decimal,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    *,
    enabled: bool = True,
) -> Decimal:
    if not enabled or taker_fee_rate <= 0:
        return Decimal("0")
    return abs(entry_price) * taker_fee_rate * Decimal("2")


def _bar_to_milliseconds_live(bar: str) -> int:
    normalized = str(bar or "").strip().lower()
    if normalized.endswith("m") and normalized[:-1].isdigit():
        return int(normalized[:-1]) * 60 * 1000
    if normalized.endswith("h") and normalized[:-1].isdigit():
        return int(normalized[:-1]) * 60 * 60 * 1000
    if normalized.endswith("d") and normalized[:-1].isdigit():
        return int(normalized[:-1]) * 24 * 60 * 60 * 1000
    raise ValueError(f"不支持的 K 线周期：{bar}")


def _signal_confirmation_ts_ms(candle_ts: int, bar: str) -> int:
    return candle_ts + _bar_to_milliseconds_live(bar)


def _holding_bars_live(entry_ts: int, reference_ts: int, bar: str) -> int:
    if reference_ts <= entry_ts:
        return 0
    return int((reference_ts - entry_ts) // _bar_to_milliseconds_live(bar))


def _time_stop_break_even_price_live(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    tick_size: Decimal,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
) -> Decimal:
    fee_offset = _dynamic_two_taker_fee_offset_live(
        entry_price,
        taker_fee_rate,
        enabled=dynamic_fee_offset_enabled,
    )
    raw = entry_price + fee_offset if direction == "long" else entry_price - fee_offset
    rounding = "up" if direction == "long" else "down"
    return snap_to_increment(raw, tick_size, rounding)


def _dynamic_trigger_price_live(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    risk_per_unit: Decimal,
    trigger_r: int,
    tick_size: Decimal,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
) -> Decimal:
    distance = (risk_per_unit * Decimal(trigger_r)) + _dynamic_two_taker_fee_offset_live(
        entry_price,
        taker_fee_rate,
        enabled=dynamic_fee_offset_enabled,
    )
    raw = entry_price + distance if direction == "long" else entry_price - distance
    rounding = "up" if direction == "long" else "down"
    return snap_to_increment(raw, tick_size, rounding)


def _dynamic_next_trigger_price_text(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    risk_per_unit: Decimal,
    next_trigger_r: int,
    tick_size: Decimal,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
) -> str:
    if next_trigger_r <= 0:
        return "-"
    return format_decimal(
        _dynamic_trigger_price_live(
            direction=direction,
            entry_price=entry_price,
            risk_per_unit=risk_per_unit,
            trigger_r=next_trigger_r,
            tick_size=tick_size,
            taker_fee_rate=taker_fee_rate,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
    )


def _dynamic_stop_price_live(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    risk_per_unit: Decimal,
    trigger_r: int,
    tick_size: Decimal,
    two_r_break_even: bool = False,
    break_even_trigger_r: int = 2,
    trailing_start_r: int = 2,
    first_lock_r: int = 0,
    trailing_step_r: int = 1,
    separate_break_even_enabled: bool = True,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
) -> Decimal:
    step_r = max(int(trailing_step_r), 1)
    trailing_start_multiple = max(int(trailing_start_r), 2)
    first_lock_multiple = max(int(first_lock_r), 0)
    if first_lock_multiple <= 0:
        first_lock_multiple = max(trailing_start_multiple - step_r, 0)
    lock_multiple = first_lock_multiple
    if two_r_break_even:
        break_even_lock_trigger_r = max(int(break_even_trigger_r), 1) if separate_break_even_enabled else 2
        if trigger_r == break_even_lock_trigger_r:
            lock_multiple = Decimal("0")
    elif trigger_r > trailing_start_multiple:
        trigger_offset = max(int(trigger_r) - trailing_start_multiple, 0)
        step_count = trigger_offset // step_r
        lock_multiple = first_lock_multiple + step_count * step_r
    lock_multiple = Decimal(str(lock_multiple))
    fee_offset = _dynamic_two_taker_fee_offset_live(
        entry_price,
        taker_fee_rate,
        enabled=dynamic_fee_offset_enabled,
    )
    raw = (
        entry_price + (risk_per_unit * lock_multiple) + fee_offset
        if direction == "long"
        else entry_price - (risk_per_unit * lock_multiple) - fee_offset
    )
    rounding = "up" if direction == "long" else "down"
    return snap_to_increment(raw, tick_size, rounding)


def _dynamic_stop_price_live_for_lock_r(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    risk_per_unit: Decimal,
    lock_r: int,
    tick_size: Decimal,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
) -> Decimal:
    lock_multiple = Decimal(str(max(int(lock_r), 0)))
    fee_offset = _dynamic_two_taker_fee_offset_live(
        entry_price,
        taker_fee_rate,
        enabled=dynamic_fee_offset_enabled,
    )
    raw = (
        entry_price + (risk_per_unit * lock_multiple) + fee_offset
        if direction == "long"
        else entry_price - (risk_per_unit * lock_multiple) - fee_offset
    )
    rounding = "up" if direction == "long" else "down"
    return snap_to_increment(raw, tick_size, rounding)


def _live_dynamic_rule_base_lock_r(rule: DynamicProtectionRule) -> int:
    return 0 if rule.resolved_action() == "break_even" else rule.resolved_lock_r()


def _live_dynamic_rule_lock_r(rule: DynamicProtectionRule, trigger_r: int) -> int:
    lock_r = _live_dynamic_rule_base_lock_r(rule)
    if not rule.trailing_enabled():
        return lock_r
    if trigger_r <= rule.resolved_trigger_r():
        return lock_r
    step_count = max(trigger_r - rule.resolved_trigger_r(), 0) // rule.resolved_trail_every_r()
    return max(lock_r + step_count * rule.resolved_trail_add_r(), 0)


def _live_resolved_dynamic_rules(
    *,
    dynamic_protection_rules: tuple[DynamicProtectionRule, ...] | tuple[dict, ...] | list[DynamicProtectionRule] | list[dict] | None,
    two_r_break_even: bool,
    break_even_trigger_r: int,
    trailing_start_r: int,
    first_lock_r: int,
    trailing_step_r: int,
) -> tuple[DynamicProtectionRule, ...]:
    normalized = normalize_dynamic_protection_rules(dynamic_protection_rules)
    if normalized:
        return normalized
    return build_legacy_dynamic_protection_rules(
        break_even_enabled=bool(two_r_break_even),
        break_even_trigger_r=max(int(break_even_trigger_r), 1),
        trailing_start_r=max(int(trailing_start_r), 2),
        first_lock_r=max(int(first_lock_r), 0),
        trailing_step_r=max(int(trailing_step_r), 1),
    )


def _live_dynamic_initial_trigger_r(
    config: StrategyConfig,
    *,
    fallback: int = 2,
) -> int:
    resolved_rules = _live_resolved_dynamic_rules(
        dynamic_protection_rules=_live_dynamic_protection_rules(config),
        two_r_break_even=_live_ema55_slope_dynamic_two_r_break_even_enabled(config),
        break_even_trigger_r=_live_dynamic_break_even_trigger_r(config),
        trailing_start_r=_live_ema55_slope_lock_profit_trigger_r(config),
        first_lock_r=_live_dynamic_first_lock_r(config),
        trailing_step_r=_live_dynamic_trailing_step_r(config),
    )
    if resolved_rules:
        return max(int(resolved_rules[0].resolved_trigger_r()), 1)
    if _live_ema55_slope_dynamic_two_r_break_even_enabled(config):
        return max(_live_dynamic_break_even_trigger_r(config), 1)
    return max(int(fallback), 1)


def _live_dynamic_next_rule_index(rules: tuple[DynamicProtectionRule, ...], next_trigger_r: int) -> int:
    for index, rule in enumerate(rules):
        if rule.resolved_trigger_r() >= next_trigger_r:
            return index
    return len(rules)


def _live_dynamic_next_event_after_rule(rules: tuple[DynamicProtectionRule, ...], rule_index: int) -> int:
    rule = rules[rule_index]
    next_explicit_r = rules[rule_index + 1].resolved_trigger_r() if rule_index + 1 < len(rules) else 0
    next_trailing_r = rule.resolved_trigger_r() + rule.resolved_trail_every_r() if rule.trailing_enabled() else 0
    candidates = [value for value in (next_explicit_r, next_trailing_r) if value > 0]
    return min(candidates) if candidates else 0


def _live_dynamic_next_event_after_trailing(
    rules: tuple[DynamicProtectionRule, ...],
    *,
    active_rule_index: int,
    current_trigger_r: int,
) -> int:
    next_rule_index = _live_dynamic_next_rule_index(rules, current_trigger_r + 1)
    next_explicit_r = rules[next_rule_index].resolved_trigger_r() if next_rule_index < len(rules) else 0
    active_rule = rules[active_rule_index]
    next_trailing_r = current_trigger_r + active_rule.resolved_trail_every_r() if active_rule.trailing_enabled() else 0
    candidates = [value for value in (next_explicit_r, next_trailing_r) if value > 0]
    return min(candidates) if candidates else 0


def _advance_dynamic_stop_live(
    *,
    direction: Literal["long", "short"],
    current_price: Decimal,
    entry_price: Decimal,
    risk_per_unit: Decimal,
    current_stop_loss: Decimal,
    next_trigger_r: int,
    tick_size: Decimal,
    two_r_break_even: bool = False,
    break_even_trigger_r: int = 2,
    trailing_start_r: int = 2,
    first_lock_r: int = 0,
    trailing_step_r: int = 1,
    separate_break_even_enabled: bool = True,
    taker_fee_rate: Decimal = LIVE_DYNAMIC_TAKER_FEE_RATE,
    dynamic_fee_offset_enabled: bool = True,
    dynamic_protection_rules: tuple[DynamicProtectionRule, ...] | tuple[dict, ...] | list[DynamicProtectionRule] | list[dict] | None = None,
    holding_bars: int = 0,
    time_stop_break_even_enabled: bool = False,
    time_stop_break_even_bars: int = 0,
) -> tuple[Decimal, Decimal, int, bool]:
    resolved_rules = _live_resolved_dynamic_rules(
        dynamic_protection_rules=dynamic_protection_rules,
        two_r_break_even=two_r_break_even,
        break_even_trigger_r=break_even_trigger_r,
        trailing_start_r=trailing_start_r,
        first_lock_r=first_lock_r,
        trailing_step_r=trailing_step_r,
    )
    if risk_per_unit <= 0:
        next_take_profit = current_price
        if next_trigger_r > 0:
            next_take_profit = _dynamic_trigger_price_live(
                direction=direction,
                entry_price=entry_price,
                risk_per_unit=Decimal("0"),
                trigger_r=next_trigger_r,
                tick_size=tick_size,
                taker_fee_rate=taker_fee_rate,
                dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
            )
        updated_stop = current_stop_loss
        moved = False
        if time_stop_break_even_enabled and time_stop_break_even_bars > 0 and holding_bars >= time_stop_break_even_bars:
            candidate = _time_stop_break_even_price_live(
                direction=direction,
                entry_price=entry_price,
                tick_size=tick_size,
                taker_fee_rate=taker_fee_rate,
                dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
            )
            if direction == "long":
                if current_price >= candidate and candidate > updated_stop:
                    updated_stop = candidate
                    moved = True
            elif current_price <= candidate and candidate < updated_stop:
                updated_stop = candidate
                moved = True
        return updated_stop, next_take_profit, next_trigger_r, moved

    moved = False
    updated_stop = current_stop_loss
    trigger_r = next_trigger_r
    if time_stop_break_even_enabled and time_stop_break_even_bars > 0 and holding_bars >= time_stop_break_even_bars:
        candidate = _time_stop_break_even_price_live(
            direction=direction,
            entry_price=entry_price,
            tick_size=tick_size,
            taker_fee_rate=taker_fee_rate,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
        if direction == "long":
            if current_price >= candidate and candidate > updated_stop:
                updated_stop = candidate
                moved = True
        elif current_price <= candidate and candidate < updated_stop:
            updated_stop = candidate
            moved = True
    if resolved_rules:
        while trigger_r > 0:
            trigger_price = _dynamic_trigger_price_live(
                direction=direction,
                entry_price=entry_price,
                risk_per_unit=risk_per_unit,
                trigger_r=trigger_r,
                tick_size=tick_size,
                taker_fee_rate=taker_fee_rate,
                dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
            )
            reached = current_price >= trigger_price if direction == "long" else current_price <= trigger_price
            if not reached:
                return updated_stop, trigger_price, trigger_r, moved

            next_rule_index = _live_dynamic_next_rule_index(resolved_rules, trigger_r)
            is_explicit_rule_event = (
                next_rule_index < len(resolved_rules)
                and resolved_rules[next_rule_index].resolved_trigger_r() == trigger_r
            )
            if is_explicit_rule_event:
                rule = resolved_rules[next_rule_index]
                lock_r = _live_dynamic_rule_lock_r(rule, trigger_r)
                candidate = _dynamic_stop_price_live_for_lock_r(
                    direction=direction,
                    entry_price=entry_price,
                    risk_per_unit=risk_per_unit,
                    lock_r=lock_r,
                    tick_size=tick_size,
                    taker_fee_rate=taker_fee_rate,
                    dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                )
                updated_stop = max(updated_stop, candidate) if direction == "long" else min(updated_stop, candidate)
                trigger_r = _live_dynamic_next_event_after_rule(resolved_rules, next_rule_index)
            elif next_rule_index > 0:
                active_rule_index = next_rule_index - 1
                active_rule = resolved_rules[active_rule_index]
                lock_r = _live_dynamic_rule_lock_r(active_rule, trigger_r)
                candidate = _dynamic_stop_price_live_for_lock_r(
                    direction=direction,
                    entry_price=entry_price,
                    risk_per_unit=risk_per_unit,
                    lock_r=lock_r,
                    tick_size=tick_size,
                    taker_fee_rate=taker_fee_rate,
                    dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                )
                updated_stop = max(updated_stop, candidate) if direction == "long" else min(updated_stop, candidate)
                trigger_r = _live_dynamic_next_event_after_trailing(
                    resolved_rules,
                    active_rule_index=active_rule_index,
                    current_trigger_r=trigger_r,
                )
            else:
                break
            moved = True
        return updated_stop, current_price, trigger_r, moved
    if two_r_break_even and separate_break_even_enabled:
        be_trigger_r = max(int(break_even_trigger_r), 1)
        be_trigger_price = _dynamic_trigger_price_live(
            direction=direction,
            entry_price=entry_price,
            risk_per_unit=risk_per_unit,
            trigger_r=be_trigger_r,
            tick_size=tick_size,
            taker_fee_rate=taker_fee_rate,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
        be_reached = current_price >= be_trigger_price if direction == "long" else current_price <= be_trigger_price
        if be_reached:
            candidate = _time_stop_break_even_price_live(
                direction=direction,
                entry_price=entry_price,
                tick_size=tick_size,
                taker_fee_rate=taker_fee_rate,
                dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
            )
            if direction == "long":
                if candidate > updated_stop:
                    updated_stop = candidate
                    moved = True
            elif candidate < updated_stop:
                updated_stop = candidate
                moved = True
    while True:
        trigger_price = _dynamic_trigger_price_live(
            direction=direction,
            entry_price=entry_price,
            risk_per_unit=risk_per_unit,
            trigger_r=trigger_r,
            tick_size=tick_size,
            taker_fee_rate=taker_fee_rate,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
        reached = current_price >= trigger_price if direction == "long" else current_price <= trigger_price
        if not reached:
            return updated_stop, trigger_price, trigger_r, moved

        candidate = _dynamic_stop_price_live(
            direction=direction,
            entry_price=entry_price,
            risk_per_unit=risk_per_unit,
            trigger_r=trigger_r,
            tick_size=tick_size,
            two_r_break_even=two_r_break_even,
            break_even_trigger_r=break_even_trigger_r,
            trailing_start_r=trailing_start_r,
            first_lock_r=first_lock_r,
            trailing_step_r=trailing_step_r,
            separate_break_even_enabled=separate_break_even_enabled,
            taker_fee_rate=taker_fee_rate,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
        updated_stop = max(updated_stop, candidate) if direction == "long" else min(updated_stop, candidate)
        trigger_r += max(int(trailing_step_r), 1)
        moved = True


def _is_exchange_dynamic_stop_candidate_valid(
    *,
    direction: Literal["long", "short"],
    current_price: Decimal,
    candidate_stop_loss: Decimal,
) -> bool:
    if direction == "long":
        return current_price > candidate_stop_loss
    return current_price < candidate_stop_loss


def _is_profit_protecting_stop(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    stop_loss: Decimal,
) -> bool:
    if direction == "long":
        return stop_loss >= entry_price
    return stop_loss <= entry_price


def _classify_live_dynamic_close_reason(
    *,
    direction: Literal["long", "short"],
    entry_price: Decimal,
    initial_stop_loss: Decimal,
    current_stop_loss: Decimal,
    risk_per_unit: Decimal,
    next_trigger_r: int,
    tick_size: Decimal,
    two_r_break_even: bool,
    dynamic_fee_offset_enabled: bool,
    time_stop_break_even_enabled: bool,
    break_even_trigger_r: int = 2,
    trailing_start_r: int = 2,
    first_lock_r: int = 0,
    trailing_step_r: int = 1,
    separate_break_even_enabled: bool = True,
    dynamic_protection_rules: tuple[DynamicProtectionRule, ...] | tuple[dict, ...] | list[DynamicProtectionRule] | list[dict] | None = None,
) -> str:
    resolved_rules = _live_resolved_dynamic_rules(
        dynamic_protection_rules=dynamic_protection_rules,
        two_r_break_even=two_r_break_even,
        break_even_trigger_r=break_even_trigger_r,
        trailing_start_r=trailing_start_r,
        first_lock_r=first_lock_r,
        trailing_step_r=trailing_step_r,
    )
    if current_stop_loss == initial_stop_loss:
        return "止损"
    if time_stop_break_even_enabled and current_stop_loss == _time_stop_break_even_price_live(
        direction=direction,
        entry_price=entry_price,
        tick_size=tick_size,
        dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
    ):
        return "保本"
    if two_r_break_even and current_stop_loss == _time_stop_break_even_price_live(
        direction=direction,
        entry_price=entry_price,
        tick_size=tick_size,
        dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
    ):
        return "保本"
    if resolved_rules:
        active_next_trigger_r = next_trigger_r
        if active_next_trigger_r <= 0:
            last_rule = resolved_rules[-1]
            active_next_trigger_r = (
                last_rule.resolved_trigger_r() + last_rule.resolved_trail_every_r()
                if last_rule.trailing_enabled()
                else last_rule.resolved_trigger_r() + 1
            )
        next_rule_index = _live_dynamic_next_rule_index(resolved_rules, active_next_trigger_r)
        for index in range(min(next_rule_index, len(resolved_rules))):
            rule = resolved_rules[index]
            lock_r = _live_dynamic_rule_lock_r(rule, rule.resolved_trigger_r())
            candidate = _dynamic_stop_price_live_for_lock_r(
                direction=direction,
                entry_price=entry_price,
                risk_per_unit=risk_per_unit,
                lock_r=lock_r,
                tick_size=tick_size,
                dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
            )
            if candidate == current_stop_loss:
                return "保本" if lock_r <= 0 else f"{lock_r}R"
        if next_rule_index > 0:
            active_rule = resolved_rules[next_rule_index - 1]
            if active_rule.trailing_enabled():
                trail_trigger_r = active_rule.resolved_trigger_r() + active_rule.resolved_trail_every_r()
                while trail_trigger_r < active_next_trigger_r:
                    lock_r = _live_dynamic_rule_lock_r(active_rule, trail_trigger_r)
                    candidate = _dynamic_stop_price_live_for_lock_r(
                        direction=direction,
                        entry_price=entry_price,
                        risk_per_unit=risk_per_unit,
                        lock_r=lock_r,
                        tick_size=tick_size,
                        dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
                    )
                    if candidate == current_stop_loss:
                        return "保本" if lock_r <= 0 else f"{lock_r}R"
                    trail_trigger_r += active_rule.resolved_trail_every_r()
        return "保本" if _is_profit_protecting_stop(direction=direction, entry_price=entry_price, stop_loss=current_stop_loss) else "止损"
    for trigger_r in range(2, next_trigger_r):
        candidate = _dynamic_stop_price_live(
            direction=direction,
            entry_price=entry_price,
            risk_per_unit=risk_per_unit,
            trigger_r=trigger_r,
            tick_size=tick_size,
            two_r_break_even=two_r_break_even,
            break_even_trigger_r=break_even_trigger_r,
            trailing_start_r=trailing_start_r,
            first_lock_r=first_lock_r,
            trailing_step_r=trailing_step_r,
            separate_break_even_enabled=separate_break_even_enabled,
            dynamic_fee_offset_enabled=dynamic_fee_offset_enabled,
        )
        if candidate != current_stop_loss:
            continue
        break_even_lock_trigger_r = max(int(break_even_trigger_r), 1) if separate_break_even_enabled else 2
        if two_r_break_even and trigger_r == break_even_lock_trigger_r:
            locked_r = 0
        else:
            trailing_start_multiple = max(int(trailing_start_r), 2)
            trailing_step_multiple = max(int(trailing_step_r), 1)
            first_lock_multiple = max(int(first_lock_r), 0)
            if first_lock_multiple <= 0:
                first_lock_multiple = max(trailing_start_multiple - trailing_step_multiple, 0)
            if trigger_r <= trailing_start_multiple:
                locked_r = first_lock_multiple
            else:
                trigger_offset = max(int(trigger_r) - trailing_start_multiple, 0)
                step_count = trigger_offset // trailing_step_multiple
                locked_r = max(first_lock_multiple + step_count * trailing_step_multiple, 0)
        return "保本" if locked_r <= 0 else f"{locked_r}R"
    return "止损"

def _reset_startup_signal_gate(gate_state: StartupSignalGateState) -> None:
    gate_state.blocked_signal = None


def _should_skip_startup_signal(
    gate_state: StartupSignalGateState,
    *,
    signal: Literal["long", "short"],
    candle_ts: int,
    bar: str,
) -> tuple[bool, str | None]:
    if gate_state.blocked_signal is not None and gate_state.blocked_signal != signal:
        gate_state.blocked_signal = None

    if gate_state.blocked_signal == signal:
        return True, None

    confirmation_ts = _signal_confirmation_ts_ms(candle_ts, bar)
    if confirmation_ts > gate_state.started_at_ms:
        return False, None

    signal_age_seconds = max((gate_state.started_at_ms - confirmation_ts) // 1000, 0)
    if gate_state.chase_current_signal:
        return (
            False,
            f"{_fmt_ts(candle_ts)} | 启动追当前信号，本次接管当前波段 | 方向={signal.upper()} | "
            f"信号年龄={signal_age_seconds}秒",
        )
    window_seconds = max(int(gate_state.chase_window_seconds), 0)
    if window_seconds > 0 and signal_age_seconds <= window_seconds:
        return (
            False,
            f"{_fmt_ts(candle_ts)} | 启动追单窗口内接管当前波段 | 方向={signal.upper()} | "
            f"信号年龄={signal_age_seconds}秒 | 窗口={window_seconds}秒",
        )

    gate_state.blocked_signal = signal
    if window_seconds > 0:
        return (
            True,
            f"{_fmt_ts(candle_ts)} | 启动追单窗口已过期，当前不追单 | 方向={signal.upper()} | "
            f"信号年龄={signal_age_seconds}秒 | 窗口={window_seconds}秒 | "
            "这是重启前已确认的老信号，按设置跳过本波，等待下一波新信号",
        )
    return (
        True,
        f"{_fmt_ts(candle_ts)} | 启动默认不追老信号 | 方向={signal.upper()} | "
        "这是重启前已确认的老信号，按设置跳过本波，等待下一波新信号",
    )


def _coerce_okx_read_exception(exc: Exception) -> OkxApiError | None:
    if isinstance(exc, OkxApiError):
        return exc
    detail = str(exc).strip()
    lowered = detail.lower()
    transient_markers = (
        "timeout",
        "timed out",
        "handshake",
        "connection reset",
        "connection aborted",
        "connection refused",
        "eof occurred",
        "remote end closed connection without response",
        "remotedisconnected",
    )
    if any(marker in lowered for marker in transient_markers) and (
        isinstance(exc, OSError)
        or "remote end closed connection without response" in lowered
        or "remotedisconnected" in lowered
    ):
        return OkxApiError(f"网络错误：{detail or exc.__class__.__name__}")
    return None


def _is_transient_okx_error(exc: OkxApiError) -> bool:
    if exc.status is not None:
        return exc.status in {408, 409, 425, 429} or exc.status >= 500
    detail = str(exc).strip().lower()
    transient_markers = (
        "网络错误",
        "timeout",
        "timed out",
        "temporarily unavailable",
        "connection reset",
        "connection aborted",
        "connection refused",
        "handshake",
        "eof occurred",
        "remote end closed connection without response",
        "remotedisconnected",
    )
    return any(marker in detail for marker in transient_markers)

def _is_okx_order_not_found_error(exc: OkxApiError) -> bool:
    detail = str(exc).strip()
    if not detail:
        return False
    normalized = detail.lower()
    return (
        "未返回订单状态" in detail
        or "订单不存在" in detail
        or "order does not exist" in normalized
        or "order not exist" in normalized
    )


def _instrument_price_delta_multiplier(instrument: Instrument) -> Decimal:
    if instrument.inst_type not in {"SWAP", "FUTURES"}:
        return Decimal("1")
    settle_ccy = (instrument.settle_ccy or "").strip().upper()
    if settle_ccy not in {"USDT", "USDC"}:
        return Decimal("1")
    ct_val = instrument.ct_val if instrument.ct_val is not None and instrument.ct_val > 0 else None
    if ct_val is None:
        return Decimal("1")
    ct_mult = instrument.ct_mult if instrument.ct_mult is not None and instrument.ct_mult > 0 else Decimal("1")
    multiplier = ct_val * ct_mult
    return multiplier if multiplier > 0 else Decimal("1")


def _instrument_contract_base_currency(instrument: Instrument) -> str | None:
    candidate = (instrument.ct_val_ccy or "").strip().upper()
    if candidate:
        return candidate
    normalized_inst_id = instrument.inst_id.strip().upper()
    if "-" in normalized_inst_id:
        return normalized_inst_id.split("-", 1)[0]
    return None


def _format_size_with_contract_equivalent(instrument: Instrument, size: Decimal) -> str:
    contract_multiplier = _instrument_price_delta_multiplier(instrument)
    contract_ccy = _instrument_contract_base_currency(instrument)
    if instrument.inst_type in {"SWAP", "FUTURES", "OPTION"} and contract_multiplier > 0 and contract_ccy:
        amount = abs(size) * contract_multiplier
        amount_text = format_decimal(amount)
        if size < 0:
            amount_text = f"-{amount_text}"
        return f"{format_decimal(size)}张（折合{amount_text} {contract_ccy}）"
    return format_decimal(size)


def _format_notify_size_with_unit(instrument: Instrument, size: Decimal) -> str:
    contract_multiplier = _instrument_price_delta_multiplier(instrument)
    contract_ccy = _instrument_contract_base_currency(instrument)
    if instrument.inst_type in {"SWAP", "FUTURES", "OPTION"} and contract_multiplier > 0 and contract_ccy:
        amount = abs(size) * contract_multiplier
        amount_text = format_decimal(amount)
        if size < 0:
            amount_text = f"-{amount_text}"
        return f"{amount_text} {contract_ccy}"
    return format_decimal(size)


def _minimum_order_size_message(
    instrument: Instrument,
    *,
    size: Decimal,
    raw_size: Decimal | None = None,
    risk_per_unit: Decimal | None = None,
) -> str:
    lot_text = _format_size_with_contract_equivalent(instrument, instrument.lot_size)
    min_text = _format_size_with_contract_equivalent(instrument, instrument.min_size)
    snapped_text = _format_size_with_contract_equivalent(instrument, size)
    parts: list[str] = []
    if raw_size is not None:
        parts.append(
            f"按风险金计算原始数量={format_decimal(raw_size)}张，按步长 {lot_text} 向下取整后={snapped_text}"
        )
        if risk_per_unit is not None and risk_per_unit > 0:
            minimum_risk_amount = risk_per_unit * instrument.min_size
            parts.append(f"当前至少需要风险金 {format_decimal(minimum_risk_amount)} 才能下最小一笔")
    else:
        parts.append(f"下单数量 {snapped_text}")
    parts.append(f"小于最小下单量 {min_text}")
    return " | ".join(parts)


def determine_order_size(
    *,
    instrument: Instrument,
    config: StrategyConfig,
    entry_price: Decimal,
    stop_loss: Decimal,
    risk_price_compatible: bool,
) -> Decimal:
    size_raw: Decimal | None = None
    risk_per_unit: Decimal | None = None
    if config.risk_amount is not None and config.risk_amount > 0 and risk_price_compatible:
        risk_per_unit = abs(entry_price - stop_loss) * _instrument_price_delta_multiplier(instrument)
        if risk_per_unit <= 0:
            raise RuntimeError("开仓价与止损价过于接近，无法根据风险金计算数量")
        size_raw = config.risk_amount / risk_per_unit
        size = snap_to_increment(size_raw, instrument.lot_size, "down")
    else:
        if config.order_size <= 0:
            if config.risk_amount is not None and config.risk_amount > 0 and not risk_price_compatible:
                raise RuntimeError("当前止盈止损触发标的与下单标的不同，风险金无法自动换算，请填写固定下单数量")
            raise RuntimeError("固定下单数量必须大于 0")
        size = snap_to_increment(config.order_size, instrument.lot_size, "down")

    if size < instrument.min_size:
        raise OrderSizeTooSmallError(
            _minimum_order_size_message(
                instrument,
                size=size,
                raw_size=size_raw,
                risk_per_unit=risk_per_unit,
            )
        )
    return size


def estimate_trade_entry_price(
    client: OkxRestClient,
    instrument: Instrument,
    side: Literal["buy", "sell"],
) -> Decimal:
    ticker = client.get_ticker(instrument.inst_id)
    if side == "buy":
        candidate = ticker.ask or ticker.last or ticker.bid
    else:
        candidate = ticker.bid or ticker.last or ticker.ask
    if candidate is None or candidate <= 0:
        raise RuntimeError(f"{instrument.inst_id} 当前没有可用盘口价格，无法估算下单价")
    return snap_to_increment(candidate, instrument.tick_size, "nearest")


def fetch_atr_snapshot(
    client: OkxRestClient,
    inst_id: str,
    bar: str,
    atr_period: int,
) -> AtrSnapshot:
    lookback = recommended_indicator_lookback(atr_period)
    candles = client.get_candles(inst_id, bar, limit=lookback)
    confirmed = [candle for candle in candles if candle.confirmed]
    if len(confirmed) < atr_period:
        raise RuntimeError(f"{inst_id} 已收盘 K 线不足，无法计算 ATR{atr_period}")

    atr_values = atr(confirmed, atr_period)
    last_closed_candle = confirmed[-1]
    last_closed_atr = atr_values[-1]
    if last_closed_atr is None:
        raise RuntimeError(f"{inst_id} 的 ATR{atr_period} 尚未准备好")

    return AtrSnapshot(
        candle_ts=last_closed_candle.ts,
        candle_close=last_closed_candle.close,
        atr_value=last_closed_atr,
        lookback_used=lookback,
        confirmed_count=len(confirmed),
    )


def build_protection_plan(
    *,
    instrument: Instrument,
    config: StrategyConfig,
    direction: Literal["long", "short"],
    entry_reference: Decimal,
    atr_value: Decimal,
    candle_ts: int,
    trigger_inst_id: str,
    use_signal_extrema: bool = False,
    signal_candle_high: Decimal | None = None,
    signal_candle_low: Decimal | None = None,
) -> ProtectionPlan:
    if atr_value <= 0:
        raise RuntimeError("ATR 必须大于 0 才能计算止盈止损")

    reference_price = snap_to_increment(entry_reference, instrument.tick_size, "nearest")

    if direction == "long":
        take_profit_raw = reference_price + (atr_value * config.atr_take_multiplier)
        if use_signal_extrema:
            if signal_candle_low is None:
                raise RuntimeError("缺少信号 K 线最低价，无法计算做多止损")
            stop_loss_raw = signal_candle_low - atr_value
        else:
            stop_loss_raw = reference_price - (atr_value * config.atr_stop_multiplier)
        take_profit = snap_to_increment(take_profit_raw, instrument.tick_size, "down")
        stop_loss = snap_to_increment(stop_loss_raw, instrument.tick_size, "up")
    else:
        take_profit_raw = reference_price - (atr_value * config.atr_take_multiplier)
        if use_signal_extrema:
            if signal_candle_high is None:
                raise RuntimeError("缺少信号 K 线最高价，无法计算做空止损")
            stop_loss_raw = signal_candle_high + atr_value
        else:
            stop_loss_raw = reference_price + (atr_value * config.atr_stop_multiplier)
        take_profit = snap_to_increment(take_profit_raw, instrument.tick_size, "up")
        stop_loss = snap_to_increment(stop_loss_raw, instrument.tick_size, "down")

    validate_protection_prices(
        direction=direction,
        entry_reference=reference_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
    )

    return ProtectionPlan(
        trigger_inst_id=trigger_inst_id,
        trigger_price_type=config.tp_sl_trigger_type,
        take_profit=take_profit,
        stop_loss=stop_loss,
        entry_reference=reference_price,
        atr_value=atr_value,
        direction=direction,
        candle_ts=candle_ts,
    )


def recommended_indicator_lookback(*periods: int) -> int:
    valid_periods = [period for period in periods if period > 0]
    if not valid_periods:
        raise ValueError("周期参数必须大于 0")
    requested = max(max(valid_periods) * 4, 120)
    return min(requested, OKX_SINGLE_REQUEST_MAX_CANDLES)


def _dynamic_entry_reference_ema_text(config: StrategyConfig) -> str:
    return config.entry_reference_line_label()


def _dynamic_reentry_confirmation_block_reason(
    config: StrategyConfig,
    confirmed: list[Candle],
    *,
    signal: str,
    wave_entry_sequence: int,
) -> str | None:
    if not config.uses_reentry_confirmation():
        return None
    if wave_entry_sequence < config.resolved_reentry_confirmation_min_sequence():
        return None
    period = config.resolved_reentry_confirmation_ma_period()
    if len(confirmed) < period:
        return f"再开仓确认需要至少 {period} 根已收K线"
    closes = [candle.close for candle in confirmed]
    values = moving_average(closes, period, config.resolved_reentry_confirmation_ma_type())
    confirmation_value = values[-1] if values else None
    if confirmation_value is None:
        return f"再开仓确认 {config.reentry_confirmation_line_label()} 尚未准备好"
    close = confirmed[-1].close
    if signal == "long" and close <= confirmation_value:
        return (
            f"本波第{wave_entry_sequence}次开仓未通过再开仓确认："
            f"上一根已收K收盘={format_decimal(close)} <= {config.reentry_confirmation_line_label()}={format_decimal(confirmation_value)}"
        )
    if signal == "short" and close >= confirmation_value:
        return (
            f"本波第{wave_entry_sequence}次开仓未通过再开仓确认："
            f"上一根已收K收盘={format_decimal(close)} >= {config.reentry_confirmation_line_label()}={format_decimal(confirmation_value)}"
        )
    return None


def _decimal_places_for_tick_size(tick_size: Decimal) -> int:
    normalized = tick_size.normalize()
    exponent = normalized.as_tuple().exponent
    return max(-exponent, 0)


def _format_notify_price_by_tick_size(entry_reference: Decimal, tick_size: Decimal | None) -> str:
    if tick_size is None or tick_size <= 0:
        return format_decimal(entry_reference)
    snapped = snap_to_increment(entry_reference, tick_size, "nearest")
    return format_decimal_fixed(snapped, _decimal_places_for_tick_size(tick_size))


def fetch_hourly_ema_debug(
    client: OkxRestClient,
    inst_id: str,
    ema_period: int,
    atr_period: int = DEFAULT_DEBUG_ATR_PERIOD,
    trend_ema_period: int = 0,
    big_ema_period: int = 0,
    entry_reference_ema_period: int = 0,
    ma_type: str = "ema",
) -> HourlyDebugSnapshot:
    lookback = recommended_indicator_lookback(
        ema_period,
        atr_period,
        trend_ema_period,
        big_ema_period,
        entry_reference_ema_period,
    )
    candles = client.get_candles(inst_id, "1H", limit=lookback)
    confirmed = [candle for candle in candles if candle.confirmed]
    minimum = max(ema_period, atr_period, trend_ema_period, big_ema_period, entry_reference_ema_period)
    if len(confirmed) < minimum:
        line_label = f"{str(ma_type or 'ema').strip().upper()}{ema_period}"
        raise RuntimeError(f"已收盘 1 小时 K 线不足，无法计算 {line_label} / ATR{atr_period}")

    closes = [candle.close for candle in confirmed]
    ema_values = moving_average(closes, ema_period, ma_type)
    atr_values = atr(confirmed, atr_period)
    last_closed_candle = confirmed[-1]
    last_closed_ema = ema_values[-1]
    last_closed_atr = atr_values[-1]
    if last_closed_atr is None:
        raise RuntimeError(f"ATR{atr_period} 尚未准备好")

    return HourlyDebugSnapshot(
        candle_ts=last_closed_candle.ts,
        candle_close=last_closed_candle.close,
        ema_value=last_closed_ema,
        ema_period=ema_period,
        atr_value=last_closed_atr,
        atr_period=atr_period,
        lookback_used=lookback,
        confirmed_count=len(confirmed),
        ma_type=str(ma_type or "ema").strip().lower(),
    )


def format_hourly_debug(
    inst_id: str,
    snapshot: HourlyDebugSnapshot,
    *,
    trading_bar: str = "",
) -> str:
    normalized_bar = str(trading_bar or "").strip()
    if normalized_bar and normalized_bar.upper() != "1H":
        prefix = f"1H参考调试（当前交易周期={normalized_bar}）"
    else:
        prefix = "1H调试"
    return (
        f"{prefix} | {inst_id} | K线时间={_fmt_ts(snapshot.candle_ts)} | "
        f"上一根收盘价={format_decimal_fixed(snapshot.candle_close, 2)} | "
        f"上一根{snapshot.ma_type.upper()}{snapshot.ema_period}={format_decimal_fixed(snapshot.ema_value, 2)} | "
        f"上一根ATR{snapshot.atr_period}={format_decimal_fixed(snapshot.atr_value, 2)} | "
        f"回看K线数={snapshot.lookback_used} | 已收盘根数={snapshot.confirmed_count}"
    )


def build_order_plan(
    *,
    instrument: Instrument,
    config: StrategyConfig,
    order_size: Decimal | None,
    signal: str,
    entry_reference: Decimal,
    atr_value: Decimal,
    candle_ts: int,
    signal_candle_high: Decimal | None = None,
    signal_candle_low: Decimal | None = None,
) -> OrderPlan:
    protection = build_protection_plan(
        instrument=instrument,
        config=config,
        direction=signal,
        entry_reference=entry_reference,
        atr_value=atr_value,
        candle_ts=candle_ts,
        trigger_inst_id=instrument.inst_id,
        use_signal_extrema=strategy_uses_signal_extrema(config.strategy_id),
        signal_candle_high=signal_candle_high,
        signal_candle_low=signal_candle_low,
    )

    side = "buy" if signal == "long" else "sell"
    pos_side = None
    if config.position_mode == "long_short":
        pos_side = "long" if side == "buy" else "short"

    if config.risk_amount is not None and config.risk_amount > 0:
        size = determine_order_size(
            instrument=instrument,
            config=config,
            entry_price=protection.entry_reference,
            stop_loss=protection.stop_loss,
            risk_price_compatible=True,
        )
    else:
        if order_size is None:
            raise RuntimeError("缺少下单数量，且未设置风险金")
        manual_config = replace(config, order_size=order_size, risk_amount=None)
        size = determine_order_size(
            instrument=instrument,
            config=manual_config,
            entry_price=protection.entry_reference,
            stop_loss=protection.stop_loss,
            risk_price_compatible=False,
        )

    return OrderPlan(
        inst_id=instrument.inst_id,
        side=side,
        pos_side=pos_side,
        size=size,
        take_profit=protection.take_profit,
        stop_loss=protection.stop_loss,
        entry_reference=protection.entry_reference,
        atr_value=protection.atr_value,
        signal=signal,
        candle_ts=candle_ts,
        tp_sl_inst_id=instrument.inst_id,
        tp_sl_mode="exchange",
    )


def format_entry_side_mode(entry_side_mode: str) -> str:
    if entry_side_mode == "follow_signal":
        return "跟随信号"
    if entry_side_mode == "fixed_buy":
        return "固定买入"
    if entry_side_mode == "fixed_sell":
        return "固定卖出"
    return entry_side_mode


def _format_signal_mode(signal_mode: str) -> str:
    if signal_mode == "long_only":
        return "只做多"
    if signal_mode == "short_only":
        return "只做空"
    if signal_mode == "both":
        return "双向"
    return signal_mode


def _bar_interval_seconds(bar: str) -> int:
    normalized = bar.strip()
    if len(normalized) < 2:
        raise ValueError(f"不支持的K线周期：{bar}")
    unit = normalized[-1].lower()
    value = int(normalized[:-1])
    if value <= 0:
        raise ValueError(f"不支持的K线周期：{bar}")
    if unit == "m":
        return value * 60
    if unit == "h":
        return value * 60 * 60
    if unit == "d":
        return value * 60 * 60 * 24
    raise ValueError(f"不支持的K线周期：{bar}")


def _seconds_until_next_bar_close(bar: str, buffer_seconds: float, *, now_ts: float | None = None) -> float:
    current_ts = time.time() if now_ts is None else now_ts
    interval_seconds = _bar_interval_seconds(bar)
    next_close_ts = ((int(current_ts) // interval_seconds) + 1) * interval_seconds
    wait_seconds = (next_close_ts + float(buffer_seconds)) - current_ts
    return max(wait_seconds, 1.0)


def _idle_signal_wait_seconds(
    bar: str,
    poll_seconds: float,
    *,
    max_wait_seconds: float = IDLE_SIGNAL_MAX_WAIT_SECONDS,
    now_ts: float | None = None,
) -> float:
    base_wait_seconds = max(float(poll_seconds), 1.0)
    try:
        next_check_seconds = _seconds_until_next_bar_close(bar, base_wait_seconds, now_ts=now_ts)
    except ValueError:
        return base_wait_seconds
    return max(base_wait_seconds, min(float(max_wait_seconds), next_check_seconds))


def _fmt_ts(timestamp_ms: int) -> str:
    dt = datetime.fromtimestamp(timestamp_ms / 1000)
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _coerce_okx_read_exception(exc: Exception) -> OkxApiError | None:
    if isinstance(exc, OkxApiError):
        return exc
    detail = str(exc).strip()
    lowered = detail.lower()
    transient_markers = (
        "network error",
        "timeout",
        "timed out",
        "handshake",
        "ssl",
        "connection reset",
        "connection aborted",
        "connection refused",
        "temporarily unavailable",
        "temporary failure",
        "read timed out",
        "connect timeout",
        "proxy error",
        "bad gateway",
        "service unavailable",
        "gateway timeout",
        "eof occurred",
        "remote end closed connection without response",
        "remotedisconnected",
        "超时",
        "握手",
    )
    if any(marker in lowered for marker in transient_markers):
        return OkxApiError(f"网络错误：{detail or exc.__class__.__name__}")
    return None


def _is_transient_okx_error(exc: OkxApiError) -> bool:
    if exc.status is not None:
        return exc.status in {408, 409, 425, 429} or exc.status >= 500
    detail = str(exc).strip().lower()
    transient_markers = (
        "网络错误",
        "network error",
        "timeout",
        "timed out",
        "temporarily unavailable",
        "temporary failure",
        "connection reset",
        "connection aborted",
        "connection refused",
        "handshake",
        "ssl",
        "eof occurred",
        "remote end closed connection without response",
        "remotedisconnected",
        "read timed out",
        "connect timeout",
        "proxy error",
        "bad gateway",
        "service unavailable",
        "gateway timeout",
        "未返回有效触发价",
        "缺少标记价格",
        "缺少最新成交价",
        "缺少指数价格",
        "无法触发",
        "握手",
        "超时",
    )
    return any(marker in detail for marker in transient_markers)
